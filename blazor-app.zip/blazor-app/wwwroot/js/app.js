/* Custom JavaScript for Aacharya Kindergarten Blazor App */

window.kindergartenApp = {
    // Initialize application
    init: function() {
        console.log('Aacharya Kindergarten App Initialized');
        this.setupSmoothScrolling();
        this.setupImageLazyLoading();
        this.setupAccessibility();
    },

    // Smooth scrolling for anchor links
    setupSmoothScrolling: function() {
        document.addEventListener('click', function(e) {
            const target = e.target.closest('a[href^="#"]');
            if (target) {
                e.preventDefault();
                const targetElement = document.querySelector(target.getAttribute('href'));
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    },

    // Lazy loading for images
    setupImageLazyLoading: function() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });

            const lazyImages = document.querySelectorAll('img[data-src]');
            lazyImages.forEach(img => imageObserver.observe(img));
        }
    },

    // Accessibility enhancements
    setupAccessibility: function() {
        // Add skip to main content link
        if (!document.querySelector('.skip-link')) {
            const skipLink = document.createElement('a');
            skipLink.href = '#main-content';
            skipLink.className = 'skip-link sr-only sr-only-focusable';
            skipLink.textContent = 'Skip to main content';
            skipLink.style.cssText = `
                position: absolute;
                top: -40px;
                left: 6px;
                width: auto;
                height: auto;
                padding: 8px 16px;
                background: #007bff;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                z-index: 9999;
                transition: top 0.3s;
            `;
            
            skipLink.addEventListener('focus', function() {
                this.style.top = '6px';
            });
            
            skipLink.addEventListener('blur', function() {
                this.style.top = '-40px';
            });
            
            document.body.insertBefore(skipLink, document.body.firstChild);
        }

        // Announce page changes to screen readers
        this.announcePageChange();
    },

    // Announce page changes for screen readers
    announcePageChange: function() {
        const pageTitle = document.title;
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only';
        announcement.textContent = `Page changed to ${pageTitle}`;
        
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    },

    // Form validation helpers
    validation: {
        // Validate email format
        isValidEmail: function(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },

        // Validate phone number
        isValidPhone: function(phone) {
            const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
            return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 10;
        },

        // Add validation class to form field
        setFieldValidation: function(fieldId, isValid, message) {
            const field = document.getElementById(fieldId);
            if (field) {
                field.classList.remove('is-valid', 'is-invalid');
                field.classList.add(isValid ? 'is-valid' : 'is-invalid');
                
                // Update validation message
                let feedback = field.parentElement.querySelector('.invalid-feedback, .valid-feedback');
                if (!feedback) {
                    feedback = document.createElement('div');
                    feedback.className = isValid ? 'valid-feedback' : 'invalid-feedback';
                    field.parentElement.appendChild(feedback);
                } else {
                    feedback.className = isValid ? 'valid-feedback' : 'invalid-feedback';
                }
                feedback.textContent = message;
            }
        }
    },

    // UI utilities
    ui: {
        // Show loading spinner
        showLoading: function(element) {
            if (typeof element === 'string') {
                element = document.querySelector(element);
            }
            if (element) {
                element.innerHTML = `
                    <div class="d-flex justify-content-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                `;
            }
        },

        // Hide loading spinner
        hideLoading: function(element) {
            if (typeof element === 'string') {
                element = document.querySelector(element);
            }
            if (element) {
                const spinner = element.querySelector('.spinner-border');
                if (spinner) {
                    spinner.parentElement.remove();
                }
            }
        },

        // Smooth scroll to element
        scrollToElement: function(elementId, offset = 0) {
            const element = document.getElementById(elementId);
            if (element) {
                const elementPosition = element.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - offset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        },

        // Toggle mobile menu
        toggleMobileMenu: function() {
            const navbarToggler = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');
            
            if (navbarToggler && navbarCollapse) {
                navbarToggler.click();
            }
        }
    },

    // Analytics helpers
    analytics: {
        // Track page view
        trackPageView: function(pageName) {
            console.log(`Page view: ${pageName}`);
            // Add your analytics tracking code here
        },

        // Track event
        trackEvent: function(category, action, label, value) {
            console.log(`Event: ${category} - ${action} - ${label} - ${value}`);
            // Add your analytics tracking code here
        },

        // Track form submission
        trackFormSubmission: function(formName) {
            this.trackEvent('Form', 'Submit', formName);
        }
    },

    // Performance monitoring
    performance: {
        // Measure page load time
        measurePageLoad: function() {
            window.addEventListener('load', function() {
                const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart;
                console.log(`Page load time: ${loadTime}ms`);
            });
        },

        // Lazy load images when they enter viewport
        lazyLoadImages: function() {
            const images = document.querySelectorAll('img[data-src]');
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        imageObserver.unobserve(img);
                    }
                });
            });

            images.forEach(img => imageObserver.observe(img));
        }
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.kindergartenApp.init();
    window.kindergartenApp.performance.measurePageLoad();
});

// Re-initialize after Blazor navigation
document.addEventListener('enhancedload', function() {
    window.kindergartenApp.setupImageLazyLoading();
    window.kindergartenApp.setupAccessibility();
});

// Export for Blazor interop
window.blazorInterop = {
    showAlert: function(message) {
        alert(message);
    },
    
    confirmAction: function(message) {
        return confirm(message);
    },
    
    scrollToTop: function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    
    copyToClipboard: function(text) {
        navigator.clipboard.writeText(text).then(function() {
            console.log('Text copied to clipboard');
            return true;
        }).catch(function(err) {
            console.error('Failed to copy text: ', err);
            return false;
        });
    },
    
    downloadFile: function(filename, content, contentType) {
        const blob = new Blob([content], { type: contentType });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    }
};