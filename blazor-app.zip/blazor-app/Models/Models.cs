using System.ComponentModel.DataAnnotations;

namespace AacharyaKindergarten.Models
{
    public class EmailData
    {
        [Required(ErrorMessage = "Name is required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be between 2 and 50 characters")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        [StringLength(100, ErrorMessage = "Email cannot exceed 100 characters")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Subject is required")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Subject must be between 5 and 100 characters")]
        public string Subject { get; set; } = string.Empty;

        [Required(ErrorMessage = "Message is required")]
        [StringLength(1000, MinimumLength = 10, ErrorMessage = "Message must be between 10 and 1000 characters")]
        public string Message { get; set; } = string.Empty;
    }

    public class ContactFormModel
    {
        [Required(ErrorMessage = "Name is required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be between 2 and 50 characters")]
        [RegularExpression(@"^[a-zA-Z\s.'''-]+$", ErrorMessage = "Please enter a valid name (letters and spaces only)")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        [StringLength(100, ErrorMessage = "Email cannot exceed 100 characters")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Subject is required")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Subject must be between 5 and 100 characters")]
        public string Subject { get; set; } = string.Empty;

        [Required(ErrorMessage = "Message is required")]
        [StringLength(1000, MinimumLength = 10, ErrorMessage = "Message must be between 10 and 1000 characters")]
        public string Message { get; set; } = string.Empty;
    }

    public class EmailResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public DateTime? Timestamp { get; set; }
        public string Method { get; set; } = string.Empty;
        public string? ErrorType { get; set; }
    }

    public class EmailConfiguration
    {
        public FormspreeConfig? Formspree { get; set; }
        public EmailJSConfig? EmailJS { get; set; }
    }

    public class FormspreeConfig
    {
        public bool Enabled { get; set; }
        public string FormId { get; set; } = string.Empty;
        public string Endpoint { get; set; } = string.Empty;
    }

    public class EmailJSConfig
    {
        public bool Enabled { get; set; }
        public string ServiceId { get; set; } = string.Empty;
        public string TemplateId { get; set; } = string.Empty;
        public string PublicKey { get; set; } = string.Empty;
    }

    public class GalleryItem
    {
        public string Id { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string ImageUrl { get; set; } = string.Empty;
        public string ThumbnailUrl { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime DateAdded { get; set; }
        public string FileName { get; set; } = string.Empty;
        public long FileSize { get; set; }
    }

    public class GalleryManifest
    {
        public List<GalleryItem> Items { get; set; } = new List<GalleryItem>();
        public DateTime LastUpdated { get; set; }
        public int TotalCount { get; set; }
        public List<string> Categories { get; set; } = new List<string>();
    }

    public class UploadImageRequest
    {
        [Required(ErrorMessage = "Image file is required")]
        public IFormFile Image { get; set; } = null!;

        [Required(ErrorMessage = "Title is required")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Title must be between 3 and 100 characters")]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Category is required")]
        public string Category { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string Description { get; set; } = string.Empty;
    }

    public class NotificationMessage
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Message { get; set; } = string.Empty;
        public NotificationType Type { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public int Duration { get; set; } = 5000; // Default 5 seconds
        public bool IsVisible { get; set; } = true;
    }

    public enum NotificationType
    {
        Success,
        Error,
        Warning,
        Info
    }
}