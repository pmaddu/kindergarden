using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using AacharyaKindergarten.Models;
using AacharyaKindergarten.Services;

namespace AacharyaKindergarten.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GalleryController : ControllerBase
    {
        private readonly IGalleryService _galleryService;
        private readonly ILogger<GalleryController> _logger;

        public GalleryController(IGalleryService galleryService, ILogger<GalleryController> logger)
        {
            _galleryService = galleryService;
            _logger = logger;
        }

        /// <summary>
        /// Get all gallery items or filter by category
        /// </summary>
        /// <param name="category">Optional category filter</param>
        /// <returns>List of gallery items</returns>
        [HttpGet]
        public async Task<ActionResult<List<GalleryItem>>> GetGalleryItems([FromQuery] string? category = null)
        {
            try
            {
                var items = await _galleryService.GetGalleryItemsAsync(category);
                return Ok(items);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get gallery items");
                return StatusCode(500, new { error = "Internal server error", message = "Failed to retrieve gallery items" });
            }
        }

        /// <summary>
        /// Get gallery manifest with metadata
        /// </summary>
        /// <returns>Gallery manifest</returns>
        [HttpGet("manifest")]
        public async Task<ActionResult<GalleryManifest>> GetGalleryManifest()
        {
            try
            {
                var manifest = await _galleryService.GetGalleryManifestAsync();
                return Ok(manifest);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get gallery manifest");
                return StatusCode(500, new { error = "Internal server error", message = "Failed to retrieve gallery manifest" });
            }
        }

        /// <summary>
        /// Get available categories
        /// </summary>
        /// <returns>List of categories</returns>
        [HttpGet("categories")]
        public async Task<ActionResult<List<string>>> GetCategories()
        {
            try
            {
                var categories = await _galleryService.GetCategoriesAsync();
                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get categories");
                return StatusCode(500, new { error = "Internal server error", message = "Failed to retrieve categories" });
            }
        }

        /// <summary>
        /// Upload a new image to the gallery
        /// </summary>
        /// <param name="request">Upload request with image and metadata</param>
        /// <returns>Upload result</returns>
        [HttpPost("upload")]
        [EnableRateLimiting("UploadPolicy")]
        [RequestSizeLimit(10 * 1024 * 1024)] // 10MB limit
        public async Task<ActionResult> UploadImage([FromForm] UploadImageRequest request)
        {
            try
            {
                // Validate request
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                // Additional validation
                if (request.Image == null || request.Image.Length == 0)
                {
                    return BadRequest(new { error = "No file provided", message = "Please select an image file to upload" });
                }

                var allowedFormats = new[] { "image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif" };
                if (!allowedFormats.Contains(request.Image.ContentType))
                {
                    return BadRequest(new { error = "Invalid file format", message = "Only JPEG, PNG, WebP, and GIF files are allowed" });
                }

                var imageId = await _galleryService.UploadImageAsync(request);

                _logger.LogInformation("Image uploaded successfully with ID: {ImageId}", imageId);

                return Ok(new
                {
                    success = true,
                    message = "Image uploaded successfully",
                    imageId = imageId,
                    timestamp = DateTime.Now
                });
            }
            catch (ArgumentException ex)
            {
                _logger.LogWarning(ex, "Invalid upload request");
                return BadRequest(new { error = "Invalid request", message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to upload image");
                return StatusCode(500, new { error = "Upload failed", message = "Failed to upload image. Please try again." });
            }
        }

        /// <summary>
        /// Delete an image from the gallery
        /// </summary>
        /// <param name="imageId">Image ID to delete</param>
        /// <returns>Delete result</returns>
        [HttpDelete("{imageId}")]
        [EnableRateLimiting("UploadPolicy")]
        public async Task<ActionResult> DeleteImage(string imageId)
        {
            try
            {
                if (string.IsNullOrEmpty(imageId))
                {
                    return BadRequest(new { error = "Invalid request", message = "Image ID is required" });
                }

                var success = await _galleryService.DeleteImageAsync(imageId);

                if (!success)
                {
                    return NotFound(new { error = "Image not found", message = "The specified image could not be found" });
                }

                _logger.LogInformation("Image deleted successfully: {ImageId}", imageId);

                return Ok(new
                {
                    success = true,
                    message = "Image deleted successfully",
                    timestamp = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to delete image: {ImageId}", imageId);
                return StatusCode(500, new { error = "Delete failed", message = "Failed to delete image. Please try again." });
            }
        }

        /// <summary>
        /// Update image metadata
        /// </summary>
        /// <param name="imageId">Image ID to update</param>
        /// <param name="updatedItem">Updated image data</param>
        /// <returns>Update result</returns>
        [HttpPut("{imageId}")]
        public async Task<ActionResult> UpdateImage(string imageId, [FromBody] GalleryItem updatedItem)
        {
            try
            {
                if (string.IsNullOrEmpty(imageId))
                {
                    return BadRequest(new { error = "Invalid request", message = "Image ID is required" });
                }

                if (updatedItem == null)
                {
                    return BadRequest(new { error = "Invalid request", message = "Updated image data is required" });
                }

                var success = await _galleryService.UpdateImageAsync(imageId, updatedItem);

                if (!success)
                {
                    return NotFound(new { error = "Image not found", message = "The specified image could not be found" });
                }

                _logger.LogInformation("Image updated successfully: {ImageId}", imageId);

                return Ok(new
                {
                    success = true,
                    message = "Image updated successfully",
                    timestamp = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update image: {ImageId}", imageId);
                return StatusCode(500, new { error = "Update failed", message = "Failed to update image. Please try again." });
            }
        }

        /// <summary>
        /// Health check endpoint
        /// </summary>
        /// <returns>Service health status</returns>
        [HttpGet("health")]
        public ActionResult GetHealth()
        {
            return Ok(new
            {
                status = "healthy",
                service = "Gallery API",
                timestamp = DateTime.Now,
                version = "1.0.0"
            });
        }
    }
}