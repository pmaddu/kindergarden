using AacharyaKindergarten.Models;

namespace AacharyaKindergarten.Services
{
    public interface IEmailService
    {
        Task<EmailResponse> SendEmailAsync(EmailData emailData);
        Task<EmailResponse> SendEmailViaFormspreeAsync(EmailData emailData);
        Task<bool> TestEmailConfigurationAsync();
        string GetPrimaryMethod();
        List<string> GetAvailableMethods();
    }

    public class EmailService : IEmailService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IEmailConfigService _configService;
        private readonly ILogger<EmailService> _logger;
        private readonly string _recipientEmail = "pradeep.maddu496@gmail.com";

        public EmailService(
            IHttpClientFactory httpClientFactory,
            IEmailConfigService configService,
            ILogger<EmailService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _configService = configService;
            _logger = logger;
        }

        public async Task<EmailResponse> SendEmailAsync(EmailData emailData)
        {
            try
            {
                var config = _configService.GetConfiguration();
                
                // Sanitize input data
                var sanitizedData = SanitizeEmailData(emailData);

                // Try primary method first
                if (config.Formspree?.Enabled == true)
                {
                    return await SendEmailViaFormspreeAsync(sanitizedData);
                }
                else
                {
                    return new EmailResponse
                    {
                        Success = false,
                        Message = "No email service is configured. Please contact us directly at " + _recipientEmail,
                        Timestamp = DateTime.Now,
                        Method = "none",
                        ErrorType = "config"
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to send email");
                return new EmailResponse
                {
                    Success = false,
                    Message = "An unexpected error occurred. Please try again later.",
                    Timestamp = DateTime.Now,
                    Method = "unknown",
                    ErrorType = "unknown"
                };
            }
        }

        public async Task<EmailResponse> SendEmailViaFormspreeAsync(EmailData emailData)
        {
            try
            {
                var config = _configService.GetConfiguration();
                if (config.Formspree?.Enabled != true || string.IsNullOrEmpty(config.Formspree.Endpoint))
                {
                    return new EmailResponse
                    {
                        Success = false,
                        Message = "Formspree service is not configured.",
                        Timestamp = DateTime.Now,
                        Method = "formspree",
                        ErrorType = "config"
                    };
                }

                var httpClient = _httpClientFactory.CreateClient();
                httpClient.Timeout = TimeSpan.FromSeconds(30);

                var payload = new
                {
                    name = emailData.Name,
                    email = emailData.Email,
                    subject = emailData.Subject,
                    message = emailData.Message,
                    _replyto = emailData.Email,
                    _subject = $"New message from {emailData.Name} - {emailData.Subject}"
                };

                var jsonContent = new StringContent(
                    System.Text.Json.JsonSerializer.Serialize(payload),
                    System.Text.Encoding.UTF8,
                    "application/json"
                );

                var response = await httpClient.PostAsync(config.Formspree.Endpoint, jsonContent);

                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Email sent successfully via Formspree for {Name}", emailData.Name);
                    return new EmailResponse
                    {
                        Success = true,
                        Message = "Email sent successfully! We will get back to you soon.",
                        Timestamp = DateTime.Now,
                        Method = "formspree"
                    };
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogWarning("Formspree email failed with status {StatusCode}: {Error}", 
                        response.StatusCode, errorContent);

                    string errorMessage = response.StatusCode switch
                    {
                        System.Net.HttpStatusCode.TooManyRequests => "Too many requests. Please wait a moment before trying again.",
                        System.Net.HttpStatusCode.BadRequest => "Invalid email data. Please check your information and try again.",
                        _ => "Failed to send email. Please try again later."
                    };

                    return new EmailResponse
                    {
                        Success = false,
                        Message = errorMessage,
                        Timestamp = DateTime.Now,
                        Method = "formspree",
                        ErrorType = response.StatusCode == System.Net.HttpStatusCode.TooManyRequests ? "rate-limit" : "unknown"
                    };
                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Network error sending email via Formspree");
                return new EmailResponse
                {
                    Success = false,
                    Message = "Network error. Please check your internet connection and try again.",
                    Timestamp = DateTime.Now,
                    Method = "formspree",
                    ErrorType = "network"
                };
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "Timeout sending email via Formspree");
                return new EmailResponse
                {
                    Success = false,
                    Message = "Request timeout. Please try again.",
                    Timestamp = DateTime.Now,
                    Method = "formspree",
                    ErrorType = "network"
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error sending email via Formspree");
                return new EmailResponse
                {
                    Success = false,
                    Message = "An unexpected error occurred. Please try again later.",
                    Timestamp = DateTime.Now,
                    Method = "formspree",
                    ErrorType = "unknown"
                };
            }
        }

        public async Task<bool> TestEmailConfigurationAsync()
        {
            try
            {
                var config = _configService.GetConfiguration();
                
                if (config.Formspree?.Enabled == true && !string.IsNullOrEmpty(config.Formspree.Endpoint))
                {
                    // Test Formspree configuration by making a simple request
                    var httpClient = _httpClientFactory.CreateClient();
                    httpClient.Timeout = TimeSpan.FromSeconds(10);
                    
                    try
                    {
                        var response = await httpClient.GetAsync(config.Formspree.Endpoint);
                        return response.StatusCode != System.Net.HttpStatusCode.NotFound;
                    }
                    catch
                    {
                        return false;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error testing email configuration");
                return false;
            }
        }

        public string GetPrimaryMethod()
        {
            return _configService.GetPrimaryMethod();
        }

        public List<string> GetAvailableMethods()
        {
            return _configService.GetAvailableMethods();
        }

        private EmailData SanitizeEmailData(EmailData data)
        {
            return new EmailData
            {
                Name = SanitizeString(data.Name),
                Email = SanitizeString(data.Email).ToLowerInvariant(),
                Subject = SanitizeString(data.Subject),
                Message = SanitizeString(data.Message)
            };
        }

        private string SanitizeString(string input)
        {
            if (string.IsNullOrEmpty(input))
                return string.Empty;

            return input.Trim()
                       .Replace("<script", "&lt;script", StringComparison.OrdinalIgnoreCase)
                       .Replace("</script>", "&lt;/script&gt;", StringComparison.OrdinalIgnoreCase)
                       .Replace("<", "&lt;")
                       .Replace(">", "&gt;")
                       .Substring(0, Math.Min(input.Length, 1000));
        }
    }
}