using AacharyaKindergarten.Models;
using System.Text.Json;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using SixLabors.ImageSharp.Formats.Jpeg;

namespace AacharyaKindergarten.Services
{
    public interface IGalleryService
    {
        Task<GalleryManifest> GetGalleryManifestAsync();
        Task<List<GalleryItem>> GetGalleryItemsAsync(string? category = null);
        Task<List<string>> GetCategoriesAsync();
        Task<string> UploadImageAsync(UploadImageRequest request);
        Task<bool> DeleteImageAsync(string imageId);
        Task<bool> UpdateImageAsync(string imageId, GalleryItem updatedItem);
    }

    public class GalleryService : IGalleryService
    {
        private readonly ILogger<GalleryService> _logger;
        private readonly IWebHostEnvironment _environment;
        private readonly string _uploadPath;
        private readonly string _assetsPath;
        private readonly string _manifestPath;
        private readonly List<string> _allowedFormats = new() { "jpg", "jpeg", "png", "webp", "gif" };
        private readonly List<string> _categories = new() { "Playing", "Drawing", "Reading", "Learning", "Activities" };
        private const int MaxFileSize = 10 * 1024 * 1024; // 10MB
        private const int ThumbnailWidth = 400;
        private const int ThumbnailHeight = 300;
        private const int ImageQuality = 85;

        public GalleryService(ILogger<GalleryService> logger, IWebHostEnvironment environment)
        {
            _logger = logger;
            _environment = environment;
            _uploadPath = Path.Combine(_environment.WebRootPath, "uploads", "gallery");
            _assetsPath = Path.Combine(_environment.WebRootPath, "assets", "img");
            _manifestPath = Path.Combine(_environment.WebRootPath, "assets", "gallery-manifest.json");

            InitializeDirectories();
        }

        private void InitializeDirectories()
        {
            try
            {
                // Create main upload directory
                Directory.CreateDirectory(_uploadPath);

                // Create category-specific directories
                foreach (var category in _categories)
                {
                    var categoryPath = Path.Combine(_uploadPath, category.ToLower());
                    Directory.CreateDirectory(categoryPath);
                    _logger.LogInformation("Created/verified directory: {CategoryPath}", categoryPath);
                }

                // Create thumbnails directory
                Directory.CreateDirectory(Path.Combine(_uploadPath, "thumbnails"));

                // Ensure assets directory exists
                Directory.CreateDirectory(Path.GetDirectoryName(_assetsPath) ?? _assetsPath);

                _logger.LogInformation("Gallery directories initialized successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize gallery directories");
            }
        }

        public async Task<GalleryManifest> GetGalleryManifestAsync()
        {
            try
            {
                if (File.Exists(_manifestPath))
                {
                    var jsonContent = await File.ReadAllTextAsync(_manifestPath);
                    var manifest = JsonSerializer.Deserialize<GalleryManifest>(jsonContent, new JsonSerializerOptions
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                    });
                    return manifest ?? new GalleryManifest();
                }

                return new GalleryManifest
                {
                    Items = new List<GalleryItem>(),
                    Categories = _categories,
                    LastUpdated = DateTime.Now,
                    TotalCount = 0
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to read gallery manifest");
                return new GalleryManifest
                {
                    Items = new List<GalleryItem>(),
                    Categories = _categories,
                    LastUpdated = DateTime.Now,
                    TotalCount = 0
                };
            }
        }

        public async Task<List<GalleryItem>> GetGalleryItemsAsync(string? category = null)
        {
            try
            {
                var manifest = await GetGalleryManifestAsync();
                var items = manifest.Items;

                if (!string.IsNullOrEmpty(category))
                {
                    items = items.Where(item => 
                        string.Equals(item.Category, category, StringComparison.OrdinalIgnoreCase))
                        .ToList();
                }

                return items.OrderByDescending(item => item.DateAdded).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get gallery items");
                return new List<GalleryItem>();
            }
        }

        public async Task<List<string>> GetCategoriesAsync()
        {
            try
            {
                var manifest = await GetGalleryManifestAsync();
                return manifest.Categories.Any() ? manifest.Categories : _categories;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get categories");
                return _categories;
            }
        }

        public async Task<string> UploadImageAsync(UploadImageRequest request)
        {
            try
            {
                // Validate file
                if (request.Image == null || request.Image.Length == 0)
                {
                    throw new ArgumentException("No file provided");
                }

                if (request.Image.Length > MaxFileSize)
                {
                    throw new ArgumentException($"File size exceeds maximum allowed size of {MaxFileSize / (1024 * 1024)}MB");
                }

                var fileExtension = Path.GetExtension(request.Image.FileName).ToLower().TrimStart('.');
                if (!_allowedFormats.Contains(fileExtension))
                {
                    throw new ArgumentException($"File format not supported. Allowed formats: {string.Join(", ", _allowedFormats)}");
                }

                // Generate unique filename
                var uniqueId = Guid.NewGuid().ToString();
                var fileName = $"{uniqueId}.{fileExtension}";
                var thumbnailFileName = $"{uniqueId}_thumb.jpg";

                // Determine category path
                var categoryPath = Path.Combine(_uploadPath, request.Category.ToLower());
                var fullImagePath = Path.Combine(categoryPath, fileName);
                var thumbnailPath = Path.Combine(_uploadPath, "thumbnails", thumbnailFileName);

                // Save original image
                using (var stream = new FileStream(fullImagePath, FileMode.Create))
                {
                    await request.Image.CopyToAsync(stream);
                }

                // Create thumbnail
                await CreateThumbnailAsync(fullImagePath, thumbnailPath);

                // Create gallery item
                var galleryItem = new GalleryItem
                {
                    Id = uniqueId,
                    Title = request.Title,
                    Category = request.Category,
                    Description = request.Description,
                    ImageUrl = $"/uploads/gallery/{request.Category.ToLower()}/{fileName}",
                    ThumbnailUrl = $"/uploads/gallery/thumbnails/{thumbnailFileName}",
                    FileName = fileName,
                    FileSize = request.Image.Length,
                    DateAdded = DateTime.Now
                };

                // Update manifest
                await AddToManifestAsync(galleryItem);

                _logger.LogInformation("Image uploaded successfully: {FileName}", fileName);
                return uniqueId;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to upload image");
                throw;
            }
        }

        public async Task<bool> DeleteImageAsync(string imageId)
        {
            try
            {
                var manifest = await GetGalleryManifestAsync();
                var item = manifest.Items.FirstOrDefault(i => i.Id == imageId);
                
                if (item == null)
                {
                    return false;
                }

                // Delete files
                var imagePath = Path.Combine(_environment.WebRootPath, item.ImageUrl.TrimStart('/'));
                var thumbnailPath = Path.Combine(_environment.WebRootPath, item.ThumbnailUrl.TrimStart('/'));

                if (File.Exists(imagePath))
                {
                    File.Delete(imagePath);
                }

                if (File.Exists(thumbnailPath))
                {
                    File.Delete(thumbnailPath);
                }

                // Update manifest
                manifest.Items.RemoveAll(i => i.Id == imageId);
                manifest.TotalCount = manifest.Items.Count;
                manifest.LastUpdated = DateTime.Now;

                await SaveManifestAsync(manifest);

                _logger.LogInformation("Image deleted successfully: {ImageId}", imageId);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to delete image: {ImageId}", imageId);
                return false;
            }
        }

        public async Task<bool> UpdateImageAsync(string imageId, GalleryItem updatedItem)
        {
            try
            {
                var manifest = await GetGalleryManifestAsync();
                var existingItem = manifest.Items.FirstOrDefault(i => i.Id == imageId);
                
                if (existingItem == null)
                {
                    return false;
                }

                // Update properties
                existingItem.Title = updatedItem.Title;
                existingItem.Description = updatedItem.Description;
                existingItem.Category = updatedItem.Category;

                manifest.LastUpdated = DateTime.Now;
                await SaveManifestAsync(manifest);

                _logger.LogInformation("Image updated successfully: {ImageId}", imageId);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update image: {ImageId}", imageId);
                return false;
            }
        }

        private async Task CreateThumbnailAsync(string sourcePath, string thumbnailPath)
        {
            try
            {
                using var image = await Image.LoadAsync(sourcePath);
                
                image.Mutate(x => x.Resize(new ResizeOptions
                {
                    Size = new Size(ThumbnailWidth, ThumbnailHeight),
                    Mode = ResizeMode.Crop,
                    Position = AnchorPositionMode.Center
                }));

                var encoder = new JpegEncoder
                {
                    Quality = ImageQuality
                };

                await image.SaveAsync(thumbnailPath, encoder);
                _logger.LogDebug("Thumbnail created: {ThumbnailPath}", thumbnailPath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create thumbnail for: {SourcePath}", sourcePath);
                throw;
            }
        }

        private async Task AddToManifestAsync(GalleryItem item)
        {
            var manifest = await GetGalleryManifestAsync();
            manifest.Items.Add(item);
            manifest.TotalCount = manifest.Items.Count;
            manifest.LastUpdated = DateTime.Now;

            // Update categories if needed
            if (!manifest.Categories.Contains(item.Category))
            {
                manifest.Categories.Add(item.Category);
            }

            await SaveManifestAsync(manifest);
        }

        private async Task SaveManifestAsync(GalleryManifest manifest)
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                    WriteIndented = true
                };

                var jsonContent = JsonSerializer.Serialize(manifest, options);
                await File.WriteAllTextAsync(_manifestPath, jsonContent);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to save gallery manifest");
                throw;
            }
        }
    }
}