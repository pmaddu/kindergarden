using AacharyaKindergarten.Models;

namespace AacharyaKindergarten.Services
{
    public interface IEmailConfigService
    {
        EmailConfiguration GetConfiguration();
        void SetFormspreeConfig(FormspreeConfig config);
        string GetPrimaryMethod();
        List<string> GetAvailableMethods();
        bool HasConfiguredService();
        Dictionary<string, object> GetSetupInstructions();
    }

    public class EmailConfigService : IEmailConfigService
    {
        private readonly EmailConfiguration _configuration;

        public EmailConfigService()
        {
            _configuration = new EmailConfiguration
            {
                // Formspree configuration (replace with your actual form ID)
                Formspree = new FormspreeConfig
                {
                    Enabled = true, // Set to true when you have a Formspree form
                    FormId = "your-formspree-form-id", // Replace with your actual form ID
                    Endpoint = "https://formspree.io/f/your-formspree-form-id" // Replace with your actual endpoint
                },

                // EmailJS configuration (currently disabled as we're using server-side)
                EmailJS = new EmailJSConfig
                {
                    Enabled = false, // Disabled for server-side Blazor
                    ServiceId = "",
                    TemplateId = "",
                    PublicKey = ""
                }
            };
        }

        public EmailConfiguration GetConfiguration()
        {
            return new EmailConfiguration
            {
                Formspree = _configuration.Formspree != null ? new FormspreeConfig
                {
                    Enabled = _configuration.Formspree.Enabled,
                    FormId = _configuration.Formspree.FormId,
                    Endpoint = _configuration.Formspree.Endpoint
                } : null,
                EmailJS = _configuration.EmailJS != null ? new EmailJSConfig
                {
                    Enabled = _configuration.EmailJS.Enabled,
                    ServiceId = _configuration.EmailJS.ServiceId,
                    TemplateId = _configuration.EmailJS.TemplateId,
                    PublicKey = _configuration.EmailJS.PublicKey
                } : null
            };
        }

        public void SetFormspreeConfig(FormspreeConfig config)
        {
            if (config != null && _configuration.Formspree != null)
            {
                _configuration.Formspree.Enabled = config.Enabled;
                _configuration.Formspree.FormId = config.FormId;
                _configuration.Formspree.Endpoint = config.Endpoint;
            }
        }

        public string GetPrimaryMethod()
        {
            if (_configuration.Formspree?.Enabled == true)
            {
                return "formspree";
            }
            else if (_configuration.EmailJS?.Enabled == true)
            {
                return "emailjs";
            }
            else
            {
                return "formspree"; // Default to formspree even if not configured
            }
        }

        public List<string> GetAvailableMethods()
        {
            var methods = new List<string>();

            if (_configuration.Formspree?.Enabled == true)
                methods.Add("formspree");

            if (_configuration.EmailJS?.Enabled == true)
                methods.Add("emailjs");

            return methods;
        }

        public bool HasConfiguredService()
        {
            return (_configuration.Formspree?.Enabled == true) ||
                   (_configuration.EmailJS?.Enabled == true);
        }

        public Dictionary<string, object> GetSetupInstructions()
        {
            return new Dictionary<string, object>
            {
                ["formspree"] = new
                {
                    title = "Formspree Setup (Recommended for Server-Side)",
                    steps = new[]
                    {
                        "1. Go to https://formspree.io and create an account",
                        "2. Create a new form and get your form ID",
                        "3. Update the formId in EmailConfigService",
                        "4. Set formspree.enabled to true in the configuration",
                        "5. Test the contact form"
                    },
                    example = new
                    {
                        formId = "your-actual-form-id",
                        endpoint = "https://formspree.io/f/your-actual-form-id"
                    }
                },
                ["emailjs"] = new
                {
                    title = "EmailJS Setup (Client-Side Alternative)",
                    steps = new[]
                    {
                        "1. Go to https://www.emailjs.com and create an account",
                        "2. Create an email service (Gmail, Outlook, Yahoo, etc.)",
                        "3. Create an email template with these variables:",
                        "   - {{from_name}} - Sender name",
                        "   - {{from_email}} - Sender email",
                        "   - {{subject}} - Email subject",
                        "   - {{message}} - Email message",
                        "   - {{to_email}} - Recipient email",
                        "4. Get your Service ID, Template ID, and Public Key",
                        "5. Update the EmailJS configuration in this service",
                        "6. Test the contact form"
                    },
                    example = new
                    {
                        serviceId = "service_aacharya",
                        templateId = "template_contact",
                        publicKey = "your-public-key-here"
                    }
                }
            };
        }
    }
}