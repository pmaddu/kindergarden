using AacharyaKindergarten.Models;

namespace AacharyaKindergarten.Services
{
    public interface INotificationService
    {
        event Action<NotificationMessage>? OnNotificationAdded;
        event Action<string>? OnNotificationRemoved;
        Task ShowSuccessAsync(string message, int duration = 5000);
        Task ShowErrorAsync(string message, int duration = 8000);
        Task ShowWarningAsync(string message, int duration = 6000);
        Task ShowInfoAsync(string message, int duration = 5000);
        void RemoveNotification(string id);
        void ClearAllNotifications();
    }

    public class NotificationService : INotificationService
    {
        public event Action<NotificationMessage>? OnNotificationAdded;
        public event Action<string>? OnNotificationRemoved;

        public async Task ShowSuccessAsync(string message, int duration = 5000)
        {
            await Task.Run(() =>
            {
                var notification = new NotificationMessage
                {
                    Message = message,
                    Type = NotificationType.Success,
                    Duration = duration
                };

                OnNotificationAdded?.Invoke(notification);

                // Auto-remove after duration
                if (duration > 0)
                {
                    Task.Delay(duration).ContinueWith(_ =>
                    {
                        OnNotificationRemoved?.Invoke(notification.Id);
                    });
                }
            });
        }

        public async Task ShowErrorAsync(string message, int duration = 8000)
        {
            await Task.Run(() =>
            {
                var notification = new NotificationMessage
                {
                    Message = message,
                    Type = NotificationType.Error,
                    Duration = duration
                };

                OnNotificationAdded?.Invoke(notification);

                // Auto-remove after duration
                if (duration > 0)
                {
                    Task.Delay(duration).ContinueWith(_ =>
                    {
                        OnNotificationRemoved?.Invoke(notification.Id);
                    });
                }
            });
        }

        public async Task ShowWarningAsync(string message, int duration = 6000)
        {
            await Task.Run(() =>
            {
                var notification = new NotificationMessage
                {
                    Message = message,
                    Type = NotificationType.Warning,
                    Duration = duration
                };

                OnNotificationAdded?.Invoke(notification);

                // Auto-remove after duration
                if (duration > 0)
                {
                    Task.Delay(duration).ContinueWith(_ =>
                    {
                        OnNotificationRemoved?.Invoke(notification.Id);
                    });
                }
            });
        }

        public async Task ShowInfoAsync(string message, int duration = 5000)
        {
            await Task.Run(() =>
            {
                var notification = new NotificationMessage
                {
                    Message = message,
                    Type = NotificationType.Info,
                    Duration = duration
                };

                OnNotificationAdded?.Invoke(notification);

                // Auto-remove after duration
                if (duration > 0)
                {
                    Task.Delay(duration).ContinueWith(_ =>
                    {
                        OnNotificationRemoved?.Invoke(notification.Id);
                    });
                }
            });
        }

        public void RemoveNotification(string id)
        {
            OnNotificationRemoved?.Invoke(id);
        }

        public void ClearAllNotifications()
        {
            // This would need to be implemented with a list of active notifications
            // For now, we'll just trigger a general clear event
        }
    }
}