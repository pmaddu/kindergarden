# Aacharya Kindergarten - Blazor Server Application

This is the **Blazor Server** version of the Aacharya Kindergarten website, converted from the original Angular application with enhanced server-side functionality.

## ?? Features

### **? Modern Blazor Server Architecture**
- **Server-Side Rendering**: Fast initial page loads and SEO-friendly
- **Real-Time Updates**: SignalR integration for live updates
- **Component-Based**: Reusable Razor components with code-behind
- **Type-Safe**: Full C# type safety throughout the application

### **?? Mobile-First Responsive Design**
- **Touch-Friendly**: 44px minimum touch targets following accessibility guidelines
- **Responsive Typography**: Fluid font sizes using CSS clamp() for optimal readability
- **Progressive Enhancement**: Works on all devices from mobile to desktop
- **Performance Optimized**: Lazy loading and optimized resource delivery

### **?? Server-Side Features**
- **C# Email Service**: Server-side email handling with Formspree integration
- **Image Upload API**: Complete gallery management with image processing
- **Rate Limiting**: Built-in protection against abuse
- **Error Handling**: Comprehensive error pages and logging

### **?? Enhanced UI Components**
- **Interactive Gallery**: Dynamic image gallery with category filtering
- **Toast Notifications**: Real-time user feedback system
- **Form Validation**: Client and server-side validation
- **Accessibility**: WCAG compliant with keyboard navigation and screen reader support

## ?? Project Structure

```
blazor-app/
??? Components/
?   ??? Layout/
?   ?   ??? MainLayout.razor          # Main application layout
?   ??? Pages/
?   ?   ??? Home.razor               # ?? Landing page with hero section
?   ?   ??? About.razor              # ?? School information and mission
?   ?   ??? Classes.razor            # ?? Program offerings and schedules
?   ?   ??? Gallery.razor            # ??? Photo gallery with filtering
?   ?   ??? Contact.razor            # ?? Contact form and information
?   ?   ??? Error.razor              # ? Error handling page
?   ??? Shared/
?   ?   ??? HeaderComponent.razor    # ?? Navigation header
?   ?   ??? FooterComponent.razor    # ?? Footer with links and info
?   ?   ??? BreadcrumbComponent.razor # ?? Navigation breadcrumbs
?   ?   ??? FeaturesComponent.razor  # ? Feature highlights
?   ?   ??? NotificationComponent.razor # ?? Toast notifications
?   ??? App.razor                    # ?? Main app component
?   ??? Routes.razor                 # ??? Route configuration
?   ??? _Imports.razor               # ?? Global using statements
??? Controllers/
?   ??? GalleryController.cs         # ??? Gallery API endpoints
??? Models/
?   ??? Models.cs                    # ?? Data models and DTOs
??? Services/
?   ??? EmailService.cs              # ?? Email service implementation
?   ??? EmailConfigService.cs        # ?? Email configuration
?   ??? NotificationService.cs       # ?? Notification service
?   ??? GalleryService.cs           # ??? Gallery service with image processing
??? wwwroot/
?   ??? css/
?   ?   ??? app.css                  # ?? Custom styles
?   ??? js/
?   ?   ??? app.js                   # ? Custom JavaScript
?   ??? uploads/                     # ?? Upload directory
??? Program.cs                       # ?? Application startup
??? appsettings.json                # ?? Configuration
??? AacharyaKindergarten.csproj     # ?? Project file
```

## ??? Technology Stack

- **Framework**: Blazor Server (.NET 8)
- **UI**: Bootstrap 5.3.2 + Custom CSS
- **Icons**: Font Awesome 6.4.0
- **Fonts**: Google Fonts (Poppins)
- **Image Processing**: SixLabors.ImageSharp
- **Validation**: FluentValidation
- **Email**: Formspree integration
- **Rate Limiting**: ASP.NET Core Rate Limiting

## ?? Getting Started

### Prerequisites
- .NET 8 SDK or later
- Visual Studio 2022 or VS Code
- Git

### Installation

1. **Clone the repository:**
   ```bash
   cd blazor-app
   ```

2. **Restore packages:**
   ```bash
   dotnet restore
   ```

3. **Update configuration:**
   - Edit `appsettings.json`
   - Configure Formspree endpoint (see Email Configuration section)

4. **Run the application:**
   ```bash
   dotnet run
   ```

5. **Open browser:**
   - Navigate to `https://localhost:5001` or `http://localhost:5000`

### Development Commands

```bash
# Run in development mode
dotnet run

# Run with file watching (auto-reload)
dotnet watch run

# Build for production
dotnet build --configuration Release

# Publish for deployment
dotnet publish --configuration Release
```

## ?? Email Service Configuration

### Formspree Setup (Recommended)

1. **Create Formspree account:**
   - Go to [Formspree.io](https://formspree.io)
   - Create a free account

2. **Create a form:**
   - Create a new form
   - Get your Form ID (e.g., `xvgprkgl`)

3. **Update configuration:**
   ```json
   {
     "EmailConfiguration": {
       "Formspree": {
         "Enabled": true,
         "FormId": "your-actual-form-id",
         "Endpoint": "https://formspree.io/f/your-actual-form-id"
       }
     }
   }
   ```

4. **Test the contact form**

## ??? Gallery Management

### Image Upload Features
- **Supported Formats**: JPG, PNG, WebP, GIF
- **Max File Size**: 10MB per image
- **Automatic Thumbnails**: Generated using ImageSharp
- **Categories**: Playing, Drawing, Reading, Learning, Activities
- **Rate Limiting**: 10 uploads per 15 minutes

### Gallery API Endpoints
- `GET /api/gallery` - Get all images
- `GET /api/gallery?category=Playing` - Filter by category
- `POST /api/gallery/upload` - Upload new image
- `DELETE /api/gallery/{id}` - Delete image
- `PUT /api/gallery/{id}` - Update image metadata

## ?? Configuration Options

### Email Settings
```json
{
  "EmailConfiguration": {
    "Formspree": {
      "Enabled": true,
      "FormId": "your-form-id",
      "Endpoint": "https://formspree.io/f/your-form-id"
    }
  }
}
```

### Gallery Settings
```json
{
  "GalleryConfiguration": {
    "MaxFileSize": 10485760,
    "AllowedFormats": ["jpg", "jpeg", "png", "webp", "gif"],
    "ThumbnailSize": { "Width": 400, "Height": 300 },
    "Categories": ["Playing", "Drawing", "Reading", "Learning", "Activities"]
  }
}
```

### Security Settings
```json
{
  "Security": {
    "EnableCors": true,
    "AllowedOrigins": ["http://localhost:5000"],
    "EnableRateLimiting": true,
    "MaxRequestBodySize": 10485760
  }
}
```

## ?? Security Features

- **CORS Protection**: Configurable allowed origins
- **Rate Limiting**: Prevents abuse of upload endpoints
- **Input Validation**: Server-side validation with FluentValidation
- **File Type Validation**: Only allows safe image formats
- **Request Size Limits**: Prevents large file uploads
- **Error Handling**: Secure error messages without information disclosure

## ?? Mobile Optimization

### Responsive Breakpoints
- **Small Mobile**: 320px - 575px
- **Large Mobile**: 576px - 767px  
- **Tablet**: 768px - 991px
- **Desktop**: 992px+

### Mobile Features
- **Touch Targets**: Minimum 44px for accessibility
- **Optimized Images**: Responsive images with lazy loading
- **Mobile Navigation**: Collapsible navigation menu
- **Gesture Support**: Touch-friendly interactions

## ?? Customization

### Styling
- Edit `wwwroot/css/app.css` for global styles
- Component-specific styles in individual `.razor` files
- CSS custom properties for consistent theming

### Components
- All components are in `Components/` directory
- Shared components in `Components/Shared/`
- Page components in `Components/Pages/`

### Services
- Business logic in `Services/` directory
- Dependency injection configured in `Program.cs`
- Interface-based design for testability

## ?? Deployment

### Development Deployment
```bash
dotnet publish --configuration Release
```

### Production Considerations
- Configure HTTPS in production
- Set up proper logging
- Configure rate limiting for production load
- Set up monitoring and health checks
- Configure proper CORS origins

### Hosting Options
- **Azure App Service**: Easy deployment with CI/CD
- **IIS**: Traditional Windows hosting
- **Docker**: Containerized deployment
- **Linux**: Cross-platform hosting

## ?? Troubleshooting

### Common Issues

1. **Email not sending:**
   - Verify Formspree configuration
   - Check network connectivity
   - Review application logs

2. **Image upload failing:**
   - Check file size limits
   - Verify file format is supported
   - Ensure upload directory permissions

3. **Styles not loading:**
   - Verify CSS file paths
   - Check for build errors
   - Clear browser cache

### Logging
- Application logs available in console
- Configure logging levels in `appsettings.json`
- Add structured logging for production

## ?? Contact Information

- **School Phone**: [+91 77384 64396](tel:+917738464396)
- **Email**: [contact@aacharyaprimaryschool.org](mailto:contact@aacharyaprimaryschool.org)
- **Address**: Bhavanipuram, Vijayawada, Andhra Pradesh 520012, India

## ?? License

This project is created for educational purposes for Aacharya Kindergarten.

---

**Built with ?? using Blazor Server | ?? Mobile-First Design | ?? Performance Optimized**