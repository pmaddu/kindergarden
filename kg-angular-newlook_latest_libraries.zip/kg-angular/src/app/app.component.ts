import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { AosService } from './services/aos.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {
  title = 'Aacharya - Kindergarten';

  constructor(
    private router: Router,
    private aosService: AosService
  ) {}

  ngOnInit(): void {
    // Refresh AOS on route change
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        setTimeout(() => {
          this.aosService.refresh();
        }, 100);
      }
    });
  }

  ngAfterViewInit(): void {
    // Initialize AOS after view initialization
    this.aosService.init();
  }
}