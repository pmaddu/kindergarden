import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AosService } from '../../services/aos.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit, AfterViewInit {
  aboutFeatures = [
    {
      icon: 'fa-solid fa-graduation-cap',
      title: 'Play Ground',
      description: 'Safe and well-equipped playground for children to develop physical skills and social interaction...',
      animation: 'fade-down-right'
    },
    {
      icon: 'fa-solid fa-music',
      title: 'Music and Dance',
      description: 'Creative expression through music and dance helps develop rhythm, coordination, and confidence...',
      animation: 'fade-down'
    },
    {
      icon: 'fa-solid fa-palette',
      title: 'Arts and Crafts',
      description: 'Hands-on creative activities that foster imagination, fine motor skills, and artistic expression...',
      animation: 'fade-down-left'
    },
    {
      icon: 'fa-solid fa-bus',
      title: 'Safe Transportation',
      description: 'Reliable and secure transportation service with trained staff to ensure children\'s safety...',
      animation: 'fade-up-right'
    },
    {
      icon: 'fa-solid fa-apple-alt',
      title: 'Healthy Food',
      description: 'Nutritious meals and snacks prepared with care to support children\'s healthy growth and development...',
      animation: 'fade-up'
    },
    {
      icon: 'fa-solid fa-map-marked-alt',
      title: 'Educational Tours',
      description: 'Learning adventures outside the classroom to broaden horizons and create memorable experiences...',
      animation: 'fade-up-left'
    }
  ];

  teachers = [
    {
      name: 'Sarah Johnson',
      role: 'Principal',
      image: 'assets/img/team-1.jpg'
    },
    {
      name: 'Emily Davis',
      role: 'Lead Teacher',
      image: 'assets/img/team-2.jpg'
    },
    {
      name: 'Jessica Wilson',
      role: 'Art Teacher',
      image: 'assets/img/team-3.jpg'
    },
    {
      name: 'Michael Brown',
      role: 'Physical Education',
      image: 'assets/img/team-4.jpg'
    }
  ];

  constructor(private aosService: AosService) {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    // Refresh AOS animations after view is loaded
    setTimeout(() => {
      this.aosService.refresh();
    }, 100);
  }
}