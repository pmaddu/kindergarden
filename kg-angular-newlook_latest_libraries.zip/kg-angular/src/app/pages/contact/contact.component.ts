import { Component, OnInit, AfterViewInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AosService } from '../../services/aos.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit, AfterViewInit {
  isSubmitting = false;
  
  formData = {
    name: '',
    email: '',
    subject: '',
    message: ''
  };

  constructor(private aosService: AosService) {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    // Refresh AOS animations after view is loaded
    setTimeout(() => {
      this.aosService.refresh();
    }, 100);
  }

  onSubmit(form: NgForm) {
    if (form.valid) {
      this.isSubmitting = true;
      
      // Simulate form submission
      setTimeout(() => {
        alert(`Thank you ${this.formData.name}! Your message has been sent. We'll get back to you soon.`);
        this.formData = { name: '', email: '', subject: '', message: '' };
        form.resetForm();
        this.isSubmitting = false;
      }, 2000);
    }
  }
}