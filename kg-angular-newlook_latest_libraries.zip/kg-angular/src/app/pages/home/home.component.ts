import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AosService } from '../../services/aos.service';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit {

    constructor(private aosService: AosService) { }

    ngOnInit(): void { }

    ngAfterViewInit(): void {
        // Refresh AOS animations after view is loaded with longer delay
        this.aosService.refreshAfterDelay(200);
    }
}