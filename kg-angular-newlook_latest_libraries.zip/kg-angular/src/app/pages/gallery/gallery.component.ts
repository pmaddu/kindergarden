import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AosService } from '../../services/aos.service';

interface GalleryItem {
  id: number;
  image: string;
  category: string;
  alt: string;
}

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.scss']
})
export class GalleryComponent implements OnInit, AfterViewInit {
  activeCategory = 'All';
  isModalOpen = false;
  modalImageSrc = '';
  modalImageAlt = '';

  categories = ['All', 'Playing', 'Drawing', 'Reading'];
  galleryItems: GalleryItem[] = [
    { id: 1, image: 'assets/img/portfolio-1.jpg', category: 'Playing', alt: 'Kids Playing' },
    { id: 2, image: 'assets/img/portfolio-2.jpg', category: 'Drawing', alt: 'Art Class' },
    { id: 3, image: 'assets/img/portfolio-3.jpg', category: 'Reading', alt: 'Story Time' },
    { id: 4, image: 'assets/img/portfolio-4.jpg', category: 'Playing', alt: 'Outdoor Activities' },
    { id: 5, image: 'assets/img/portfolio-5.jpg', category: 'Drawing', alt: 'Creative Art' },
    { id: 6, image: 'assets/img/portfolio-6.jpg', category: 'Reading', alt: 'Learning Together' }
  ];
  filteredItems: GalleryItem[] = [...this.galleryItems];

  constructor(private aosService: AosService) {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    // Refresh AOS animations after view is loaded
    setTimeout(() => {
      this.aosService.refresh();
    }, 100);
  }

  filterGallery(category: string) {
    this.activeCategory = category;
    if (category === 'All') {
      this.filteredItems = [...this.galleryItems];
    } else {
      this.filteredItems = this.galleryItems.filter(item => item.category === category);
    }

    // Refresh AOS after filtering to animate new items
    setTimeout(() => {
      this.aosService.refresh();
    }, 50);
  }

  openModal(imageSrc: string, imageAlt: string) {
    this.modalImageSrc = imageSrc;
    this.modalImageAlt = imageAlt;
    this.isModalOpen = true;
    document.body.style.overflow = 'hidden';
  }

  closeModal() {
    this.isModalOpen = false;
    document.body.style.overflow = 'auto';
  }
}
