import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AosService } from '../../services/aos.service';

interface ClassInfo {
  name: string;
  image: string;
  description: string;
  ageRange: string;
  seats: number;
  time: string;
  fee: string;
}

@Component({
  selector: 'app-classes',
  templateUrl: './classes.component.html',
  styleUrls: ['./classes.component.scss']
})
export class ClassesComponent implements OnInit, AfterViewInit {
  booking = {
    name: '',
    email: '',
    selectedClass: ''
  };

  classes: ClassInfo[] = [
    {
      name: 'Drawing Class',
      image: 'assets/img/class-1.jpg',
      description: 'Creative art classes that help develop fine motor skills, creativity, and self-expression through various drawing techniques and mediums.',
      ageRange: '3 - 6 Years',
      seats: 40,
      time: '08:00 - 10:00',
      fee: '?2900 / Month'
    },
    {
      name: 'Language Learning',
      image: 'assets/img/class-2.jpg',
      description: 'Interactive language sessions focusing on vocabulary building, communication skills, and early literacy development through fun activities.',
      ageRange: '3 - 6 Years',
      seats: 35,
      time: '10:30 - 12:30',
      fee: '?3200 / Month'
    },
    {
      name: 'Basic Science',
      image: 'assets/img/class-3.jpg',
      description: 'Hands-on science exploration introducing basic concepts through experiments, observation, and discovery-based learning.',
      ageRange: '4 - 6 Years',
      seats: 30,
      time: '14:00 - 16:00',
      fee: '?3500 / Month'
    }
  ];

  constructor(private aosService: AosService) {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    // Refresh AOS animations after view is loaded
    setTimeout(() => {
      this.aosService.refresh();
    }, 100);
  }

  onSubmit() {
    if (this.booking.name && this.booking.email && this.booking.selectedClass) {
      alert(`Thank you ${this.booking.name}! We'll contact you soon regarding the ${this.booking.selectedClass} enrollment.`);
      this.booking = { name: '', email: '', selectedClass: '' };
    }
  }
}