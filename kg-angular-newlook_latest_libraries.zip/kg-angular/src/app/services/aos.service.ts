import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

declare var AOS: any;

@Injectable({
  providedIn: 'root'
})
export class AosService {

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  init(): void {
    if (isPlatformBrowser(this.platformId)) {
      // Ensure DOM is ready and AOS is available
      if (typeof document !== 'undefined') {
        // Add a small delay to ensure AOS script is loaded
        setTimeout(() => {
          this.initializeAOS();
        }, 50);
      }
    }
  }

  private initializeAOS(): void {
    // Check if AOS is loaded
    if (typeof AOS !== 'undefined') {
      try {
        AOS.init({
          duration: 1000,           // Animation duration
          delay: 0,                 // Delay before animation starts
          easing: 'ease-in-out',    // Easing function
          once: true,               // Animation runs only once
          mirror: false,            // Elements animate when scrolling past them
          offset: 120,              // Offset from the original trigger point
          anchorPlacement: 'top-bottom', // Defines which position of the element regarding to window should trigger the animation
          startEvent: 'DOMContentLoaded', // Name of the event dispatched on the document
          animatedClassName: 'aos-animate', // Class applied on animation
          initClassName: 'aos-init', // Class applied after initialization
          useClassNames: false,     // If true, will add content of `data-aos` as classes on scroll
          disableMutationObserver: false, // Disables automatic mutations' detections
          debounceDelay: 50,        // Delay on resize
          throttleDelay: 99,        // Delay on scroll
          disable: false            // Conditions to disable AOS
        });
        
        console.log('AOS initialized successfully');
      } catch (error) {
        console.error('Error initializing AOS:', error);
      }
    } else {
      // If AOS is not loaded yet, wait and try again
      console.warn('AOS not loaded yet, retrying...');
      setTimeout(() => {
        this.initializeAOS();
      }, 100);
    }
  }

  refresh(): void {
    if (isPlatformBrowser(this.platformId)) {
      if (typeof AOS !== 'undefined') {
        try {
          AOS.refresh();
          console.log('AOS refreshed');
        } catch (error) {
          console.error('Error refreshing AOS:', error);
        }
      } else {
        console.warn('AOS not available for refresh');
      }
    }
  }

  refreshAfterDelay(delay: number = 100): void {
    if (isPlatformBrowser(this.platformId)) {
      setTimeout(() => {
        this.refresh();
      }, delay);
    }
  }

  // Method to reinitialize AOS completely
  reinitialize(): void {
    if (isPlatformBrowser(this.platformId)) {
      if (typeof AOS !== 'undefined') {
        try {
          AOS.refreshHard(); // Reinitialize everything
          console.log('AOS reinitialized');
        } catch (error) {
          // If refreshHard doesn't exist, use regular refresh
          this.refresh();
        }
      }
    }
  }
}