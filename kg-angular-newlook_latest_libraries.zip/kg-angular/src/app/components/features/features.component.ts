import { Component, Input } from '@angular/core';

interface Feature {
  icon: string;
  title: string;
  description: string;
  animation: string;
}

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.scss']
})
export class FeaturesComponent {
  @Input() features: Feature[] = [
    {
      icon: 'fa-solid fa-address-card',
      title: 'Play, Learn, Grow.',
      description: 'Emphasizing that every moment is a chance to discover something new through play...',
      animation: 'fade-down-right'
    },
    {
      icon: 'fa-regular fa-calendar-check',
      title: 'Imagine, Explore, Discover.',
      description: 'Inviting children to open their minds and embrace the excitement of learning...',
      animation: 'fade-down'
    },
    {
      icon: 'fa-brands fa-buffer',
      title: 'Learning is Fun When You\'re Together.',
      description: 'Reminding us that sharing and collaboration make education a joyful journey...',
      animation: 'fade-down-left'
    },
    {
      icon: 'fa-solid fa-austral-sign',
      title: 'Dream Big, Little One!',
      description: 'Encouraging children to aspire and believe in their own unique abilities...',
      animation: 'fade-up-right'
    },
    {
      icon: 'fa-brands fa-apple',
      title: 'Every Day is a New Adventure.',
      description: 'Highlighting the freshness of learning experiences in kindergarten...',
      animation: 'fade-up'
    },
    {
      icon: 'fa-brands fa-app-store-ios',
      title: 'Together We Explore, Together We Grow.',
      description: 'Emphasizing the community nature of learning and growth in a kindergarten setting...',
      animation: 'fade-up-left'
    }
  ];
}