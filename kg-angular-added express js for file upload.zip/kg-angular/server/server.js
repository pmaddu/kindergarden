const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const sharp = require('sharp');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');

const app = express();
const PORT = process.env.PORT || 3001;

// Configuration
const config = {
  uploadPath: './uploads/gallery',
  assetsPath: '../src/assets/img',
  manifestPath: '../src/assets/gallery-manifest.json',
  maxFileSize: 10 * 1024 * 1024, // 10MB
  allowedFormats: ['jpg', 'jpeg', 'png', 'webp', 'gif'],
  categories: ['Playing', 'Drawing', 'Reading', 'Learning', 'Activities'],
  thumbnailSize: { width: 400, height: 300 },
  imageQuality: 85
};

// Middleware setup
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));

app.use(cors({
  origin: ['http://localhost:4200', 'http://127.0.0.1:4200'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Accept']
}));

app.use(morgan('combined'));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Rate limiting
const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // limit each IP to 10 uploads per windowMs
  message: {
    error: 'Too many upload requests, please try again later.',
    retryAfter: '15 minutes'
  }
});

// Serve static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/assets', express.static(path.join(__dirname, '../src/assets')));

/**
 * Initialize directory structure
 */
async function initializeDirectories() {
  try {
    // Create main upload directory
    await fs.ensureDir(config.uploadPath);
    
    // Create category-specific directories
    for (const category of config.categories) {
      const categoryPath = path.join(config.uploadPath, category.toLowerCase());
      await fs.ensureDir(categoryPath);
      console.log(`?? Created/verified directory: ${categoryPath}`);
    }
    
    // Create thumbnails directory
    await fs.ensureDir(path.join(config.uploadPath, 'thumbnails'));
    
    // Ensure assets directory exists
    await fs.ensureDir(path.dirname(config.assetsPath));
    
    console.log('? All directories initialized successfully');
  } catch (error) {
    console.error('? Failed to initialize directories:', error);
  }
}

/**
 * Configure multer for file uploads
 */
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const category = req.body.category || 'Activities';
    const categoryPath = path.join(config.uploadPath, category.toLowerCase());
    cb(null, categoryPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = uuidv4();
    const ext = path.extname(file.originalname).toLowerCase();
    const baseName = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9-_]/g, '');
    const filename = `${baseName}_${uniqueSuffix}${ext}`;
    cb(null, filename);
  }
});

const fileFilter = (req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
  if (config.allowedFormats.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error(`Invalid file format. Allowed formats: ${config.allowedFormats.join(', ')}`), false);
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: config.maxFileSize,
    files: 5 // Maximum 5 files per request
  },
  fileFilter: fileFilter
});

/**
 * Load current gallery manifest
 */
async function loadGalleryManifest() {
  try {
    const manifestExists = await fs.pathExists(config.manifestPath);
    if (!manifestExists) {
      return {
        version: "1.0",
        lastUpdated: new Date().toISOString(),
        basePath: "assets/img/",
        images: [],
        categories: ["All", ...config.categories],
        settings: {
          autoDetectImages: true,
          supportedFormats: config.allowedFormats,
          lazyLoading: true,
          preloadImages: false
        }
      };
    }
    
    const manifestContent = await fs.readFile(config.manifestPath, 'utf-8');
    return JSON.parse(manifestContent);
  } catch (error) {
    console.error('Error loading manifest:', error);
    return null;
  }
}

/**
 * Save gallery manifest
 */
async function saveGalleryManifest(manifest) {
  try {
    manifest.lastUpdated = new Date().toISOString();
    await fs.writeFile(config.manifestPath, JSON.stringify(manifest, null, 2), 'utf-8');
    console.log('? Gallery manifest updated successfully');
    return true;
  } catch (error) {
    console.error('? Failed to save manifest:', error);
    return false;
  }
}

/**
 * Process uploaded image (resize, optimize)
 */
async function processImage(filePath, category) {
  try {
    const outputPath = filePath.replace(path.extname(filePath), '_processed' + path.extname(filePath));
    
    // Process main image
    await sharp(filePath)
      .resize(1200, 900, {
        fit: 'inside',
        withoutEnlargement: true
      })
      .jpeg({ quality: config.imageQuality })
      .toFile(outputPath);
    
    // Generate thumbnail
    const thumbnailDir = path.join(config.uploadPath, 'thumbnails');
    const thumbnailPath = path.join(thumbnailDir, path.basename(outputPath));
    
    await sharp(filePath)
      .resize(config.thumbnailSize.width, config.thumbnailSize.height, {
        fit: 'cover',
        position: 'center'
      })
      .jpeg({ quality: 70 })
      .toFile(thumbnailPath);
    
    // Replace original with processed version
    await fs.remove(filePath);
    await fs.move(outputPath, filePath);
    
    console.log(`? Image processed successfully: ${path.basename(filePath)}`);
    return {
      originalPath: filePath,
      thumbnailPath: thumbnailPath
    };
  } catch (error) {
    console.error('? Image processing failed:', error);
    throw error;
  }
}

/**
 * Copy processed image to assets folder
 */
async function copyToAssets(sourcePath, category, filename) {
  try {
    const categoryFolder = path.join(path.dirname(config.assetsPath), category.toLowerCase());
    await fs.ensureDir(categoryFolder);
    
    const destinationPath = path.join(categoryFolder, filename);
    await fs.copy(sourcePath, destinationPath);
    
    console.log(`? Image copied to assets: ${destinationPath}`);
    return `assets/img/${category.toLowerCase()}/${filename}`;
  } catch (error) {
    console.error('? Failed to copy to assets:', error);
    throw error;
  }
}

// API Routes

/**
 * GET /api/gallery - Get all gallery images
 */
app.get('/api/gallery', async (req, res) => {
  try {
    const manifest = await loadGalleryManifest();
    if (!manifest) {
      return res.status(500).json({ error: 'Failed to load gallery manifest' });
    }
    
    res.json({
      success: true,
      data: manifest,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error fetching gallery:', error);
    res.status(500).json({ 
      error: 'Failed to fetch gallery images',
      message: error.message 
    });
  }
});

/**
 * GET /api/gallery/categories - Get all categories
 */
app.get('/api/gallery/categories', async (req, res) => {
  try {
    const manifest = await loadGalleryManifest();
    res.json({
      success: true,
      categories: manifest ? manifest.categories : ['All', ...config.categories],
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ 
      error: 'Failed to fetch categories',
      message: error.message 
    });
  }
});

/**
 * GET /api/gallery/category/:category - Get images by category
 */
app.get('/api/gallery/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const manifest = await loadGalleryManifest();
    
    if (!manifest) {
      return res.status(500).json({ error: 'Failed to load gallery manifest' });
    }
    
    const filteredImages = category === 'All' 
      ? manifest.images 
      : manifest.images.filter(img => img.category.toLowerCase() === category.toLowerCase());
    
    res.json({
      success: true,
      category: category,
      count: filteredImages.length,
      images: filteredImages,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error fetching category images:', error);
    res.status(500).json({ 
      error: 'Failed to fetch category images',
      message: error.message 
    });
  }
});

/**
 * POST /api/gallery/upload - Upload new images
 */
app.post('/api/gallery/upload', uploadLimiter, upload.array('images', 5), [
  body('category').isIn(config.categories).withMessage(`Category must be one of: ${config.categories.join(', ')}`),
  body('alt').isLength({ min: 1, max: 200 }).withMessage('Alt text is required and must be less than 200 characters'),
  body('description').optional().isLength({ max: 500 }).withMessage('Description must be less than 500 characters')
], async (req, res) => {
  try {
    // Validation
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: errors.array() 
      });
    }
    
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }
    
    const { category, alt, description } = req.body;
    const uploadedImages = [];
    
    // Load current manifest
    let manifest = await loadGalleryManifest();
    if (!manifest) {
      return res.status(500).json({ error: 'Failed to load gallery manifest' });
    }
    
    // Process each uploaded file
    for (const file of req.files) {
      try {
        // Process image (resize, optimize)
        const processed = await processImage(file.path, category);
        
        // Copy to assets folder
        const assetPath = await copyToAssets(file.path, category, file.filename);
        
        // Create image metadata
        const imageData = {
          filename: file.filename,
          category: category,
          alt: alt || `${category} image`,
          description: description || `Image in ${category} category`,
          originalName: file.originalname,
          size: file.size,
          uploadDate: new Date().toISOString(),
          path: assetPath,
          thumbnailPath: `uploads/gallery/thumbnails/${file.filename}`
        };
        
        // Add to manifest
        manifest.images.push(imageData);
        uploadedImages.push(imageData);
        
        console.log(`? Successfully processed: ${file.filename}`);
      } catch (fileError) {
        console.error(`? Failed to process ${file.filename}:`, fileError);
        // Clean up failed upload
        try {
          await fs.remove(file.path);
        } catch (cleanupError) {
          console.error('Cleanup error:', cleanupError);
        }
      }
    }
    
    // Save updated manifest
    await saveGalleryManifest(manifest);
    
    res.json({
      success: true,
      message: `Successfully uploaded ${uploadedImages.length} image(s)`,
      uploadedImages: uploadedImages,
      category: category,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ 
      error: 'Failed to upload images',
      message: error.message 
    });
  }
});

/**
 * DELETE /api/gallery/image/:filename - Delete an image
 */
app.delete('/api/gallery/image/:filename', async (req, res) => {
  try {
    const { filename } = req.params;
    
    // Load manifest
    const manifest = await loadGalleryManifest();
    if (!manifest) {
      return res.status(500).json({ error: 'Failed to load gallery manifest' });
    }
    
    // Find image in manifest
    const imageIndex = manifest.images.findIndex(img => img.filename === filename);
    if (imageIndex === -1) {
      return res.status(404).json({ error: 'Image not found' });
    }
    
    const imageData = manifest.images[imageIndex];
    
    // Delete files
    try {
      // Delete from category folder
      const categoryPath = path.join(config.uploadPath, imageData.category.toLowerCase(), filename);
      await fs.remove(categoryPath);
      
      // Delete thumbnail
      const thumbnailPath = path.join(config.uploadPath, 'thumbnails', filename);
      await fs.remove(thumbnailPath);
      
      // Delete from assets
      if (imageData.path) {
        const assetPath = path.join(__dirname, '..', 'src', imageData.path);
        await fs.remove(assetPath);
      }
    } catch (fileError) {
      console.warn('Some files could not be deleted:', fileError);
    }
    
    // Remove from manifest
    manifest.images.splice(imageIndex, 1);
    await saveGalleryManifest(manifest);
    
    res.json({
      success: true,
      message: `Image ${filename} deleted successfully`,
      deletedImage: imageData,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ 
      error: 'Failed to delete image',
      message: error.message 
    });
  }
});

/**
 * PUT /api/gallery/image/:filename - Update image metadata
 */
app.put('/api/gallery/image/:filename', [
  body('category').optional().isIn(config.categories),
  body('alt').optional().isLength({ min: 1, max: 200 }),
  body('description').optional().isLength({ max: 500 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: errors.array() 
      });
    }
    
    const { filename } = req.params;
    const updates = req.body;
    
    // Load manifest
    const manifest = await loadGalleryManifest();
    if (!manifest) {
      return res.status(500).json({ error: 'Failed to load gallery manifest' });
    }
    
    // Find and update image
    const imageIndex = manifest.images.findIndex(img => img.filename === filename);
    if (imageIndex === -1) {
      return res.status(404).json({ error: 'Image not found' });
    }
    
    // Update metadata
    const imageData = manifest.images[imageIndex];
    Object.assign(imageData, updates, { 
      updatedDate: new Date().toISOString() 
    });
    
    // If category changed, move file
    if (updates.category && updates.category !== imageData.category) {
      try {
        const oldPath = path.join(config.uploadPath, imageData.category.toLowerCase(), filename);
        const newPath = path.join(config.uploadPath, updates.category.toLowerCase(), filename);
        
        await fs.ensureDir(path.dirname(newPath));
        await fs.move(oldPath, newPath);
        
        console.log(`? Moved image from ${imageData.category} to ${updates.category}`);
      } catch (moveError) {
        console.error('Failed to move image file:', moveError);
      }
    }
    
    await saveGalleryManifest(manifest);
    
    res.json({
      success: true,
      message: 'Image updated successfully',
      updatedImage: imageData,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Update error:', error);
    res.status(500).json({ 
      error: 'Failed to update image',
      message: error.message 
    });
  }
});

/**
 * POST /api/gallery/refresh - Refresh gallery manifest
 */
app.post('/api/gallery/refresh', async (req, res) => {
  try {
    // Scan upload directories and sync with manifest
    const manifest = await loadGalleryManifest();
    if (!manifest) {
      return res.status(500).json({ error: 'Failed to load gallery manifest' });
    }
    
    let foundImages = 0;
    const existingFilenames = new Set(manifest.images.map(img => img.filename));
    
    // Scan category directories
    for (const category of config.categories) {
      const categoryPath = path.join(config.uploadPath, category.toLowerCase());
      
      try {
        const files = await fs.readdir(categoryPath);
        const imageFiles = files.filter(file => {
          const ext = path.extname(file).toLowerCase().replace('.', '');
          return config.allowedFormats.includes(ext);
        });
        
        // Add new images to manifest
        for (const filename of imageFiles) {
          if (!existingFilenames.has(filename)) {
            const stats = await fs.stat(path.join(categoryPath, filename));
            manifest.images.push({
              filename: filename,
              category: category,
              alt: `Auto-discovered ${category} image`,
              description: `Automatically added from ${category} folder`,
              size: stats.size,
              uploadDate: stats.birthtime.toISOString(),
              path: `assets/img/${category.toLowerCase()}/${filename}`,
              thumbnailPath: `uploads/gallery/thumbnails/${filename}`
            });
            foundImages++;
          }
        }
      } catch (dirError) {
        console.warn(`Could not scan directory ${categoryPath}:`, dirError.message);
      }
    }
    
    await saveGalleryManifest(manifest);
    
    res.json({
      success: true,
      message: `Gallery refreshed successfully. Found ${foundImages} new images.`,
      totalImages: manifest.images.length,
      newImages: foundImages,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Refresh error:', error);
    res.status(500).json({ 
      error: 'Failed to refresh gallery',
      message: error.message 
    });
  }
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ 
        error: 'File too large', 
        message: `Maximum file size is ${config.maxFileSize / (1024 * 1024)}MB` 
      });
    }
    if (error.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({ 
        error: 'Too many files', 
        message: 'Maximum 5 files per upload' 
      });
    }
  }
  
  res.status(500).json({ 
    error: 'Internal server error',
    message: error.message 
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ 
    error: 'Endpoint not found',
    message: `Cannot ${req.method} ${req.originalUrl}` 
  });
});

// Initialize and start server
async function startServer() {
  try {
    await initializeDirectories();
    
    app.listen(PORT, () => {
      console.log(`
?? Gallery Server started successfully!
?? Server running on: http://localhost:${PORT}
?? Upload path: ${config.uploadPath}
?? Supported formats: ${config.allowedFormats.join(', ')}
?? Categories: ${config.categories.join(', ')}
? Started at: ${new Date().toLocaleString()}
      `);
    });
  } catch (error) {
    console.error('? Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('?? SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('?? SIGINT received, shutting down gracefully...');
  process.exit(0);
});

startServer();