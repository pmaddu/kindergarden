# ?? Gallery Server Setup Guide

This guide will help you set up the Express.js server for gallery image management with category-based file organization.

## ?? Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Angular CLI (for the frontend)

## ??? Server Setup

### 1. Create Server Directory
```bash
# Navigate to your project root
cd C:\Users\xp.pradeep.maddu\PersonalWork\kindergarten-v1\kindergarten-master\kg-angular

# Create server directory
mkdir server
cd server
```

### 2. Install Server Dependencies
```bash
# Install all server dependencies
npm install express multer cors fs-extra sharp uuid helmet express-rate-limit express-validator morgan

# Install development dependencies
npm install --save-dev nodemon @types/node
```

### 3. Create Directory Structure
```
kg-angular/
??? server/
?   ??? package.json
?   ??? server.js
?   ??? uploads/
?       ??? gallery/
?           ??? playing/
?           ??? drawing/
?           ??? reading/
?           ??? learning/
?           ??? activities/
?           ??? thumbnails/
??? src/
?   ??? assets/
?   ?   ??? img/
?   ?   ?   ??? playing/
?   ?   ?   ??? drawing/
?   ?   ?   ??? reading/
?   ?   ?   ??? learning/
?   ?   ?   ??? activities/
?   ?   ??? gallery-manifest.json
?   ??? ...
```

### 4. Start the Gallery Server
```bash
# Development mode with auto-restart
npm run dev

# Production mode
npm start
```

The server will start on `http://localhost:3001`

## ?? Angular Integration

### 1. Update angular.json for Proxy (Optional)
Add to `angular.json` for development:
```json
{
  "serve": {
    "builder": "@angular-devkit/build-angular:dev-server",
    "options": {
      "proxyConfig": "proxy.conf.json"
    }
  }
}
```

### 2. Create proxy.conf.json (Optional)
```json
{
  "/api/*": {
    "target": "http://localhost:3001",
    "secure": false,
    "logLevel": "debug"
  }
}
```

### 3. Start Angular Development Server
```bash
# In the main project directory
ng serve
```

## ??? Category-Based File Organization

### Folder Structure
The server automatically creates and manages category-based folders:

```
uploads/gallery/
??? playing/          # Kids playing and recreational activities
??? drawing/          # Art classes and creative sessions
??? reading/          # Story time and reading activities
??? learning/         # Educational activities and lessons
??? activities/       # School events and special activities
??? thumbnails/       # Auto-generated thumbnails
```

### Assets Mirror Structure
Images are also copied to the Angular assets folder:
```
src/assets/img/
??? playing/
??? drawing/
??? reading/
??? learning/
??? activities/
```

## ?? API Endpoints

### Gallery Management
- `GET /api/gallery` - Get all images
- `GET /api/gallery/categories` - Get all categories
- `GET /api/gallery/category/:category` - Get images by category
- `POST /api/gallery/upload` - Upload new images
- `PUT /api/gallery/image/:filename` - Update image metadata
- `DELETE /api/gallery/image/:filename` - Delete an image
- `POST /api/gallery/refresh` - Refresh gallery manifest

### Upload Example
```javascript
// FormData for upload
const formData = new FormData();
formData.append('images', file1);
formData.append('images', file2);
formData.append('category', 'Playing');
formData.append('alt', 'Kids playing in the garden');
formData.append('description', 'Children having fun outdoors');

fetch('/api/gallery/upload', {
  method: 'POST',
  body: formData
});
```

## ?? Configuration

### Server Configuration
Edit the config object in `server.js`:
```javascript
const config = {
  uploadPath: './uploads/gallery',
  assetsPath: '../src/assets/img',
  manifestPath: '../src/assets/gallery-manifest.json',
  maxFileSize: 10 * 1024 * 1024, // 10MB
  allowedFormats: ['jpg', 'jpeg', 'png', 'webp', 'gif'],
  categories: ['Playing', 'Drawing', 'Reading', 'Learning', 'Activities'],
  thumbnailSize: { width: 400, height: 300 },
  imageQuality: 85
};
```

### Angular Service Configuration
Update the API base URL in `gallery.service.ts` if needed:
```typescript
private readonly API_BASE_URL = 'http://localhost:3001/api';
```

## ?? Features

### ? Image Upload
- **Multiple file upload** (up to 5 files at once)
- **Category-based organization** (automatic folder creation)
- **Image processing** (resize, optimize, thumbnails)
- **File validation** (type, size, format)
- **Progress tracking** with real-time updates

### ? Image Management
- **View images** by category with filtering
- **Edit metadata** (category, alt text, description)
- **Delete images** with confirmation
- **Automatic manifest updates**

### ? Category Management
- **Automatic folder creation** for each category
- **Dynamic category loading** from manifest
- **Category-specific image counts**
- **Category filtering** in the UI

### ? File Organization
- **Upload folder**: `server/uploads/gallery/{category}/`
- **Assets folder**: `src/assets/img/{category}/`
- **Thumbnails**: `server/uploads/gallery/thumbnails/`
- **Manifest**: `src/assets/gallery-manifest.json`

## ??? Security Features

- **File type validation** (images only)
- **File size limits** (configurable)
- **Rate limiting** (10 uploads per 15 minutes)
- **CORS protection** with specific origins
- **Helmet.js security headers**
- **Input validation** with express-validator

## ?? Frontend Features

### Upload Modal
- **Drag & drop** file selection
- **Multiple file preview**
- **Category selection** dropdown
- **Alt text** and description fields
- **Upload progress** bar
- **Error handling** with user feedback

### Image Management
- **Grid layout** with hover effects
- **Category filtering** buttons
- **Edit modal** for metadata updates
- **Delete confirmation** dialogs
- **Server status** indicator

### Responsive Design
- **Mobile-optimized** touch interfaces
- **Responsive grid** layout
- **Touch-friendly** buttons and modals
- **Progressive enhancement**

## ?? Usage Instructions

### For End Users

#### Upload Images:
1. Click **"Upload Images"** button
2. Select one or more image files
3. Choose a **category** from dropdown
4. Add **alt text** (required)
5. Add **description** (optional)
6. Click **"Upload Images"**

#### Manage Images:
1. **View**: Click any image to see full size
2. **Edit**: Click edit button on image hover
3. **Delete**: Click delete button with confirmation
4. **Filter**: Use category buttons to filter images

#### Server Management:
- **Green "Online"** badge: Upload/edit/delete available
- **Yellow "Offline"** badge: View-only mode
- **Refresh** button: Rescan for new images

## ?? Troubleshooting

### Common Issues

#### Server Won't Start
- Check if port 3001 is available
- Verify Node.js version (16+)
- Check file permissions for upload directories

#### Upload Fails
- Verify file size (max 10MB per file)
- Check file format (JPG, PNG, WebP, GIF only)
- Ensure server is running and accessible

#### Images Don't Appear
- Check if manifest file exists
- Verify folder permissions
- Try refreshing the gallery

#### CORS Errors
- Verify Angular dev server URL in CORS config
- Check if both servers are running
- Ensure correct API base URL

### Debug Mode
Enable debug logging in server:
```javascript
// Add to server.js
console.log('Debug info:', {
  uploadPath: config.uploadPath,
  assetsPath: config.assetsPath,
  manifestPath: config.manifestPath
});
```

## ?? Performance Tips

### Server Optimization
- Use **sharp** for efficient image processing
- Enable **gzip compression**
- Implement **caching headers**
- Use **CDN** for production

### Frontend Optimization
- Enable **lazy loading** for images
- Use **intersection observer** for better performance
- Implement **virtual scrolling** for large galleries
- **Preload** thumbnails only

## ?? Deployment

### Production Setup
1. Build Angular app: `ng build --configuration production`
2. Set environment variables for production
3. Use PM2 or similar for server process management
4. Configure nginx for static file serving
5. Set up SSL certificates
6. Configure backup strategy for uploaded images

### Environment Variables
```bash
export PORT=3001
export NODE_ENV=production
export UPLOAD_PATH=/var/www/uploads
export ASSETS_PATH=/var/www/html/assets
```

---

## ?? Next Steps

1. **Setup server** following this guide
2. **Test upload functionality** with sample images
3. **Customize categories** as needed for your kindergarten
4. **Add authentication** for production use
5. **Implement backup strategy** for image files
6. **Configure monitoring** and logging

The gallery system is now ready for production use with full CRUD operations and category-based organization! ??