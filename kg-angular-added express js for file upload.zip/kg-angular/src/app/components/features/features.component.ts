import { Component, Input } from '@angular/core';

interface Feature {
  icon: string;
  title: string;
  description: string;
}

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.scss']
})
export class FeaturesComponent {
  @Input() features: Feature[] = [
    {
      icon: 'fa-solid fa-address-card',
      title: 'Play, Learn, Grow.',
      description: 'Emphasizing that every moment is a chance to discover something new through play...'
    },
    {
      icon: 'fa-regular fa-calendar-check',
      title: 'Imagine, Explore, Discover.',
      description: 'Inviting children to open their minds and embrace the excitement of learning...'
    },
    {
      icon: 'fa-brands fa-buffer',
      title: 'Learning is Fun When You\'re Together.',
      description: 'Reminding us that sharing and collaboration make education a joyful journey...'
    },
    {
      icon: 'fa-solid fa-austral-sign',
      title: 'Dream Big, Little One!',
      description: 'Encouraging children to aspire and believe in their own unique abilities...'
    },
    {
      icon: 'fa-brands fa-apple',
      title: 'Every Day is a New Adventure.',
      description: 'Highlighting the freshness of learning experiences in kindergarten...'
    },
    {
      icon: 'fa-brands fa-app-store-ios',
      title: 'Together We Explore, Together We Grow.',
      description: 'Emphasizing the community nature of learning and growth in a kindergarten setting...'
    }
  ];
}