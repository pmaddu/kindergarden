﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { Observable, BehaviorSubject, of, forkJoin } from 'rxjs';
import { map, catchError, tap, filter } from 'rxjs/operators';

// Gallery item interface
export interface GalleryItem {
  id: number;
  image: string;
  category: string;
  alt: string;
  filename: string;
  dateAdded?: Date;
  size?: { width: number; height: number };
  isLoaded?: boolean;
  thumbnailPath?: string;
  description?: string;
  originalName?: string;
  uploadDate?: string;
}

// Upload response interface
export interface UploadResponse {
  success: boolean;
  message: string;
  uploadedImages: any[];
  category: string;
  timestamp: string;
}

// Image metadata interface
export interface ImageMetadata {
  filename: string;
  path: string;
  category: string;
  alt: string;
  priority?: number;
}

// Gallery configuration interface
export interface GalleryConfig {
  basePath: string;
  supportedFormats: string[];
  categories: string[];
  defaultCategory: string;
  autoDetectCategories: boolean;
  lazyLoading: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class GalleryService {
  
  private readonly API_BASE_URL = 'http://localhost:3001/api';
  private readonly DEFAULT_CONFIG: GalleryConfig = {
    basePath: 'assets/img/',
    supportedFormats: ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'],
    categories: ['All', 'Playing', 'Drawing', 'Reading', 'Learning', 'Activities'],
    defaultCategory: 'All',
    autoDetectCategories: true,
    lazyLoading: true
  };

  private galleryItemsSubject = new BehaviorSubject<GalleryItem[]>([]);
  private categoriesSubject = new BehaviorSubject<string[]>(['All']);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  private errorSubject = new BehaviorSubject<string | null>(null);
  private uploadProgressSubject = new BehaviorSubject<number>(0);

  // Public observables
  public galleryItems$ = this.galleryItemsSubject.asObservable();
  public categories$ = this.categoriesSubject.asObservable();
  public loading$ = this.loadingSubject.asObservable();
  public error$ = this.errorSubject.asObservable();
  public uploadProgress$ = this.uploadProgressSubject.asObservable();

  private config: GalleryConfig = { ...this.DEFAULT_CONFIG };
  private imageCache = new Map<string, HTMLImageElement>();

  constructor(private http: HttpClient) {
    this.initializeDefaultImages();
  }

  /**
   * Initialize with default static images as fallback
   */
  private initializeDefaultImages(): void {
    const defaultImages: GalleryItem[] = [
      { id: 1, image: 'assets/img/portfolio-1.jpg', category: 'Playing', alt: 'Kids Playing', filename: 'portfolio-1.jpg', isLoaded: false },
      { id: 2, image: 'assets/img/portfolio-2.jpg', category: 'Drawing', alt: 'Art Class', filename: 'portfolio-2.jpg', isLoaded: false },
      { id: 3, image: 'assets/img/portfolio-3.jpg', category: 'Reading', alt: 'Story Time', filename: 'portfolio-3.jpg', isLoaded: false },
      { id: 4, image: 'assets/img/portfolio-4.jpg', category: 'Playing', alt: 'Outdoor Activities', filename: 'portfolio-4.jpg', isLoaded: false },
      { id: 5, image: 'assets/img/portfolio-5.jpg', category: 'Drawing', alt: 'Creative Art', filename: 'portfolio-5.jpg', isLoaded: false },
      { id: 6, image: 'assets/img/portfolio-6.jpg', category: 'Reading', alt: 'Learning Together', filename: 'portfolio-6.jpg', isLoaded: false },
      { id: 7, image: 'assets/img/header.png', category: 'Learning', alt: 'School Header', filename: 'header.png', isLoaded: false },
      { id: 8, image: 'assets/img/about-2.jpg', category: 'Activities', alt: 'About School', filename: 'about-2.jpg', isLoaded: false }
    ];

    // Only add default images if no images are currently loaded
    if (this.galleryItemsSubject.value.length === 0) {
      this.galleryItemsSubject.next(defaultImages);
      this.updateCategories(defaultImages);
      console.log('🖼️ Initialized with default fallback images');
    }
  }

  /**
   * Update gallery configuration
   */
  updateConfig(newConfig: Partial<GalleryConfig>): void {
    this.config = { ...this.config, ...newConfig };
    console.log('🔧 Gallery config updated:', this.config);
  }

  /**
   * Load images from server API
   */
  loadDynamicImages(): Observable<GalleryItem[]> {
    this.loadingSubject.next(true);
    this.errorSubject.next(null);

    console.log('🖼️ Loading images from server API...');

    return this.http.get<any>(`${this.API_BASE_URL}/gallery`).pipe(
      map(response => {
        if (!response.success) {
          throw new Error(response.error || 'Failed to load gallery');
        }

        console.log('✅ Loaded manifest from server with', response.data.images.length, 'images');
        
        // Update categories from server response
        if (response.data.categories) {
          this.categoriesSubject.next(response.data.categories);
        }
        
        return response.data.images.map((imageData: any, index: number) => ({
          id: index + 1,
          image: imageData.path || `${response.data.basePath || this.config.basePath}${imageData.filename}`,
          category: imageData.category,
          alt: imageData.alt,
          filename: imageData.filename,
          dateAdded: new Date(imageData.uploadDate || imageData.dateAdded || Date.now()),
          isLoaded: false,
          thumbnailPath: imageData.thumbnailPath,
          description: imageData.description,
          originalName: imageData.originalName,
          uploadDate: imageData.uploadDate
        } as GalleryItem));
      }),
      catchError(() => {
        console.log('🔄 Server API not available, falling back to local manifest...');
        return this.loadFromLocalManifest();
      }),
      tap(items => {
        console.log(`✅ Total ${items.length} images loaded`);
        this.galleryItemsSubject.next(items);
        this.updateCategories(items);
        this.preloadImages(items);
      }),
      catchError(error => {
        console.error('❌ Failed to load dynamic images:', error);
        this.errorSubject.next('Failed to load images. Using default gallery.');
        const defaultImages = this.galleryItemsSubject.value;
        return of(defaultImages);
      }),
      tap(() => this.loadingSubject.next(false))
    );
  }

  /**
   * Load from local manifest as fallback
   */
  private loadFromLocalManifest(): Observable<GalleryItem[]> {
    return this.http.get<any>('assets/gallery-manifest.json').pipe(
      map(manifest => {
        return manifest.images.map((imageData: any, index: number) => ({
          id: index + 1,
          image: `${manifest.basePath || this.config.basePath}${imageData.filename}`,
          category: imageData.category,
          alt: imageData.alt,
          filename: imageData.filename,
          dateAdded: new Date(manifest.lastUpdated || Date.now()),
          isLoaded: false,
          description: imageData.description
        } as GalleryItem));
      }),
      catchError(() => {
        // Final fallback to default images
        return of(this.galleryItemsSubject.value);
      })
    );
  }

  /**
   * Upload images to server
   */
  uploadImages(files: FileList, category: string, alt: string, description?: string): Observable<UploadResponse> {
    this.uploadProgressSubject.next(0);
    
    const formData = new FormData();
    
    // Add files to FormData
    for (let i = 0; i < files.length; i++) {
      formData.append('images', files[i]);
    }
    
    // Add metadata
    formData.append('category', category);
    formData.append('alt', alt);
    if (description) {
      formData.append('description', description);
    }

    console.log(`📤 Uploading ${files.length} image(s) to category: ${category}`);

    return this.http.post<UploadResponse>(`${this.API_BASE_URL}/gallery/upload`, formData, {
      reportProgress: true,
      observe: 'events'
    }).pipe(
      map((event: any) => {
        if (event.type === HttpEventType.Response) {
          this.uploadProgressSubject.next(100);
          return event.body;
        } else if (event.type === HttpEventType.UploadProgress && event.total) {
          const progress = Math.round(100 * event.loaded / event.total);
          this.uploadProgressSubject.next(progress);
        }
        return null;
      }),
      filter((response: UploadResponse | null): response is UploadResponse => response !== null),
      tap((response: UploadResponse) => {
        if (response.success) {
          console.log(`✅ Successfully uploaded ${response.uploadedImages.length} images`);
          // Refresh gallery after successful upload
          this.loadDynamicImages().subscribe();
        }
      }),
      catchError(error => {
        console.error('❌ Upload failed:', error);
        this.uploadProgressSubject.next(0);
        throw error;
      })
    );
  }

  /**
   * Delete image from server
   */
  deleteImage(filename: string): Observable<any> {
    console.log(`🗑️ Deleting image: ${filename}`);
    
    return this.http.delete<any>(`${this.API_BASE_URL}/gallery/image/${filename}`).pipe(
      tap(response => {
        if (response.success) {
          console.log(`✅ Successfully deleted: ${filename}`);
          // Refresh gallery after successful deletion
          this.loadDynamicImages().subscribe();
        }
      }),
      catchError(error => {
        console.error('❌ Delete failed:', error);
        throw error;
      })
    );
  }

  /**
   * Update image metadata on server
   */
  updateImageMetadata(filename: string, updates: Partial<GalleryItem>): Observable<any> {
    console.log(`✏️ Updating image metadata: ${filename}`);
    
    return this.http.put<any>(`${this.API_BASE_URL}/gallery/image/${filename}`, updates).pipe(
      tap(response => {
        if (response.success) {
          console.log(`✅ Successfully updated: ${filename}`);
          // Refresh gallery after successful update
          this.loadDynamicImages().subscribe();
        }
      }),
      catchError(error => {
        console.error('❌ Update failed:', error);
        throw error;
      })
    );
  }

  /**
   * Get images by category from server
   */
  getImagesByCategory(category: string): Observable<GalleryItem[]> {
    return this.http.get<any>(`${this.API_BASE_URL}/gallery/category/${category}`).pipe(
      map(response => {
        if (!response.success) {
          throw new Error(response.error);
        }
        
        return response.images.map((imageData: any, index: number) => ({
          id: index + 1,
          image: imageData.path,
          category: imageData.category,
          alt: imageData.alt,
          filename: imageData.filename,
          dateAdded: new Date(imageData.uploadDate || Date.now()),
          isLoaded: false,
          thumbnailPath: imageData.thumbnailPath,
          description: imageData.description
        } as GalleryItem));
      }),
      catchError(error => {
        console.error('❌ Failed to fetch category images:', error);
        // Fallback to local filtering
        return this.galleryItems$.pipe(
          map(items => {
            if (category === 'All') return items;
            return items.filter(item => item.category === category);
          })
        );
      })
    );
  }

  /**
   * Refresh gallery from server
   */
  refreshGalleryFromServer(): Observable<any> {
    console.log('🔄 Refreshing gallery from server...');
    
    return this.http.post<any>(`${this.API_BASE_URL}/gallery/refresh`, {}).pipe(
      tap(response => {
        if (response.success) {
          console.log(`✅ Server refresh complete: ${response.message}`);
          // Reload gallery after refresh
          this.loadDynamicImages().subscribe();
        }
      }),
      catchError(error => {
        console.error('❌ Server refresh failed:', error);
        // Fallback to local refresh
        return this.loadDynamicImages();
      })
    );
  }

  /**
   * Check if server is available
   */
  checkServerStatus(): Observable<boolean> {
    return this.http.get<any>(`${this.API_BASE_URL}/gallery/categories`).pipe(
      map(response => response.success),
      catchError(() => of(false))
    );
  }

  // Existing methods (keeping for backward compatibility)

  /**
   * Update categories based on gallery items
   */
  private updateCategories(items: GalleryItem[]): void {
    const categories = new Set(['All']);
    items.forEach(item => {
      if (item.category && item.category !== 'All') {
        categories.add(item.category);
      }
    });
    this.categoriesSubject.next(Array.from(categories));
  }

  /**
   * Preload images for better performance
   */
  private preloadImages(items: GalleryItem[]): void {
    if (!this.config.lazyLoading) {
      console.log('🚀 Preloading all images...');
      items.forEach(item => this.preloadImage(item));
    }
  }

  /**
   * Preload a single image
   */
  private preloadImage(item: GalleryItem): void {
    if (this.imageCache.has(item.image)) {
      return;
    }

    const img = new Image();
    img.onload = () => {
      console.log(`✅ Preloaded: ${item.filename}`);
      this.imageCache.set(item.image, img);
      item.isLoaded = true;
      item.size = { width: img.naturalWidth, height: img.naturalHeight };
    };
    img.onerror = () => {
      console.warn(`❌ Failed to preload: ${item.filename}`);
    };
    img.src = item.image;
  }

  /**
   * Get filtered items by category
   */
  getItemsByCategory(category: string): Observable<GalleryItem[]> {
    return this.galleryItems$.pipe(
      map(items => {
        if (category === 'All') {
          return items;
        }
        return items.filter(item => item.category === category);
      })
    );
  }

  /**
   * Add new image programmatically (for backward compatibility)
   */
  addImage(imageData: Partial<GalleryItem>): void {
    const currentItems = this.galleryItemsSubject.value;
    const newItem: GalleryItem = {
      id: Math.max(...currentItems.map(item => item.id), 0) + 1,
      image: imageData.image || '',
      category: imageData.category || this.config.defaultCategory,
      alt: imageData.alt || 'Gallery Image',
      filename: imageData.filename || 'unknown',
      dateAdded: new Date(),
      isLoaded: false,
      ...imageData
    };

    const updatedItems = [...currentItems, newItem];
    this.galleryItemsSubject.next(updatedItems);
    this.updateCategories(updatedItems);
    
    if (this.config.lazyLoading) {
      this.preloadImage(newItem);
    }

    console.log('➕ Added new image to gallery:', newItem.filename);
  }

  /**
   * Remove image by ID (for backward compatibility)
   */
  removeImage(id: number): void {
    const currentItems = this.galleryItemsSubject.value;
    const updatedItems = currentItems.filter(item => item.id !== id);
    this.galleryItemsSubject.next(updatedItems);
    this.updateCategories(updatedItems);
    console.log(`🗑️ Removed image with ID: ${id}`);
  }

  /**
   * Refresh gallery (tries server first, then local)
   */
  refreshGallery(): Observable<GalleryItem[]> {
    console.log('🔄 Refreshing gallery...');
    return this.loadDynamicImages();
  }

  /**
   * Get current gallery state
   */
  getCurrentItems(): GalleryItem[] {
    return this.galleryItemsSubject.value;
  }

  /**
   * Get current categories
   */
  getCurrentCategories(): string[] {
    return this.categoriesSubject.value;
  }

  /**
   * Get upload progress
   */
  getUploadProgress(): Observable<number> {
    return this.uploadProgress$;
  }

  /**
   * Reset upload progress
   */
  resetUploadProgress(): void {
    this.uploadProgressSubject.next(0);
  }
}