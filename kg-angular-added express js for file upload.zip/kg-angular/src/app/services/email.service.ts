import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { EmailConfigService } from './email-config.service';

export interface EmailData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface EmailResponse {
  success: boolean;
  message: string;
  timestamp?: Date;
  method?: 'emailjs' | 'formspree' | 'fallback';
  errorType?: 'cors' | 'network' | 'config' | 'rate-limit' | 'unknown';
}

// Error types for better handling
interface EmailJSError {
  status?: number;
  text?: string;
  message?: string;
  name?: string;
}

// Extend window interface for EmailJS
declare global {
  interface Window {
    emailjs: any;
  }
}

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  private readonly FALLBACK_EMAIL = 'pradeep.maddu496@gmail.com';
  private emailjsLoaded = false;
  private retryCount = 0;
  private readonly MAX_RETRIES = 2;

  constructor(
    private http: HttpClient,
    private configService: EmailConfigService
  ) { }

  /**
   * Send email using HTTP service (Formspree fallback)
   * @param emailData - The email data to send
   * @returns Observable with email response
   */
  sendEmail(emailData: EmailData): Observable<EmailResponse> {
    const config = this.configService.getConfig();
    
    if (!config.formspree?.enabled || !config.formspree.endpoint) {
      return throwError(() => ({
        success: false,
        message: 'Formspree service is not configured.',
        timestamp: new Date(),
        method: 'formspree',
        errorType: 'config'
      } as EmailResponse));
    }

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });

    const payload = {
      name: emailData.name,
      email: emailData.email,
      subject: emailData.subject,
      message: emailData.message,
      _replyto: emailData.email,
      _subject: `New message from ${emailData.name} - ${emailData.subject}`
    };

    return this.http.post<any>(config.formspree.endpoint, payload, { headers })
      .pipe(
        map(response => ({
          success: true,
          message: 'Email sent successfully! We will get back to you soon.',
          timestamp: new Date(),
          method: 'formspree'
        } as EmailResponse)),
        catchError(error => {
          console.error('Formspree service error:', error);
          
          let errorType: EmailResponse['errorType'] = 'unknown';
          let errorMessage = 'Failed to send email via Formspree.';

          if (error.status === 0) {
            errorType = 'network';
            errorMessage = 'Network error. Please check your internet connection.';
          } else if (error.status === 429) {
            errorType = 'rate-limit';
            errorMessage = 'Too many requests. Please wait a moment before trying again.';
          }

          return throwError(() => ({
            success: false,
            message: errorMessage,
            timestamp: new Date(),
            method: 'formspree',
            errorType
          } as EmailResponse));
        })
      );
  }

  /**
   * Send email using EmailJS service with enhanced CORS error handling
   * @param emailData - The email data to send
   * @returns Observable with email response
   */
  sendEmailViaEmailJS(emailData: EmailData): Observable<EmailResponse> {
    const config = this.configService.getConfig();
    
    if (!config.emailjs?.enabled) {
      return throwError(() => ({
        success: false,
        message: 'EmailJS service is not configured.',
        timestamp: new Date(),
        method: 'emailjs',
        errorType: 'config'
      } as EmailResponse));
    }

    return new Observable(observer => {
      this.loadEmailJS()
        .then(() => {
          this.sendWithEmailJSEnhanced(config.emailjs!, emailData, observer);
        })
        .catch(error => {
          console.error('Failed to load EmailJS library:', error);
          observer.error({
            success: false,
            message: 'Failed to load EmailJS library. This might be due to network restrictions or ad blockers.',
            timestamp: new Date(),
            method: 'emailjs',
            errorType: 'network'
          } as EmailResponse);
        });
    });
  }

  /**
   * Load EmailJS library with enhanced error handling
   * @returns Promise<void>
   */
  private loadEmailJS(): Promise<void> {
    return new Promise((resolve, reject) => {
      // Check if EmailJS is already loaded
      if (window.emailjs || this.emailjsLoaded) {
        resolve();
        return;
      }

      // Add timeout for loading
      const loadTimeout = setTimeout(() => {
        reject(new Error('EmailJS library load timeout - network or CORS issue'));
      }, 10000); // 10 second timeout

      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';
      script.async = true;
      script.crossOrigin = 'anonymous';
      
      script.onload = () => {
        clearTimeout(loadTimeout);
        this.emailjsLoaded = true;
        console.log('EmailJS library loaded successfully');
        
        // Additional check to ensure EmailJS is properly initialized
        if (window.emailjs) {
          resolve();
        } else {
          reject(new Error('EmailJS loaded but not available on window object'));
        }
      };
      
      script.onerror = (error) => {
        clearTimeout(loadTimeout);
        console.error('Failed to load EmailJS library:', error);
        reject(new Error('EmailJS library failed to load - possible CORS or network issue'));
      };
      
      document.head.appendChild(script);
    });
  }

  /**
   * Enhanced EmailJS sending with comprehensive error handling
   */
  private sendWithEmailJSEnhanced(config: any, emailData: EmailData, observer: any): void {
    try {
      // Initialize EmailJS with public key
      if (!window.emailjs) {
        throw new Error('EmailJS library not available');
      }

      window.emailjs.init(config.publicKey);

      const templateParams = {
        from_name: emailData.name,
        from_email: emailData.email,
        subject: emailData.subject,
        message: emailData.message,
        to_email: this.FALLBACK_EMAIL,
        reply_to: emailData.email,
        timestamp: new Date().toLocaleString(),
        user_agent: navigator.userAgent.substring(0, 100)
      };

      console.log('Sending email with EmailJS...', {
        serviceId: config.serviceId,
        templateId: config.templateId,
        attempt: this.retryCount + 1
      });

      // Add timeout for EmailJS send operation
      const sendTimeout = setTimeout(() => {
        observer.error({
          success: false,
          message: 'EmailJS request timeout - this might be due to CORS policy or network issues.',
          timestamp: new Date(),
          method: 'emailjs',
          errorType: 'network'
        } as EmailResponse);
      }, 15000); // 15 second timeout

      window.emailjs.send(config.serviceId, config.templateId, templateParams)
        .then((response: any) => {
          clearTimeout(sendTimeout);
          console.log('EmailJS Success:', response);
          this.retryCount = 0; // Reset retry count on success
          
          observer.next({
            success: true,
            message: `Thank you ${emailData.name}! Your message has been sent successfully. We'll get back to you soon.`,
            timestamp: new Date(),
            method: 'emailjs'
          } as EmailResponse);
          observer.complete();
        })
        .catch((error: EmailJSError) => {
          clearTimeout(sendTimeout);
          console.error('EmailJS Error:', error);
          
          const errorResponse = this.handleEmailJSError(error, emailData);
          observer.error(errorResponse);
        });

    } catch (error) {
      console.error('EmailJS Setup Error:', error);
      observer.error({
        success: false,
        message: 'EmailJS configuration error or service unavailable.',
        timestamp: new Date(),
        method: 'emailjs',
        errorType: 'config'
      } as EmailResponse);
    }
  }

  /**
   * Handle specific EmailJS errors with proper categorization
   */
  private handleEmailJSError(error: EmailJSError, emailData: EmailData): EmailResponse {
    let errorMessage = 'Failed to send email via EmailJS.';
    let errorType: EmailResponse['errorType'] = 'unknown';

    // Handle different types of errors
    if (error.name === 'TypeError' || error.message?.includes('Failed to fetch')) {
      // This usually indicates CORS or network issues
      errorType = 'cors';
      errorMessage = 'Unable to reach EmailJS service. This might be due to browser security restrictions or network connectivity issues.';
    } else if (error.status === 400 || error.text?.includes('400')) {
      errorType = 'config';
      errorMessage = 'Invalid email configuration. Please check your EmailJS service ID, template ID, and public key.';
    } else if (error.status === 403 || error.text?.includes('403')) {
      errorType = 'config';
      errorMessage = 'EmailJS service access denied. Please verify your credentials and service permissions.';
    } else if (error.status === 429 || error.text?.includes('429')) {
      errorType = 'rate-limit';
      errorMessage = 'Too many emails sent. Please wait a moment before trying again.';
    } else if (error.status === 0 || !error.status) {
      // Status 0 typically means CORS or network issue
      errorType = 'cors';
      errorMessage = 'Network error or CORS policy blocking the request. The email service may be restricted by your browser or network.';
    }

    return {
      success: false,
      message: errorMessage,
      timestamp: new Date(),
      method: 'emailjs',
      errorType
    };
  }

  /**
   * Enhanced fallback method with better error handling
   * @param emailData - The email data
   */
  openEmailClient(emailData: EmailData): void {
    try {
      const subject = encodeURIComponent(`${emailData.subject}`);
      const body = encodeURIComponent(`
Dear Aacharya Team,

Name: ${emailData.name}
Email: ${emailData.email}
Subject: ${emailData.subject}

Message:
${emailData.message}

---
Sent via Aacharya Kindergarten Contact Form
Time: ${new Date().toLocaleString()}
Reason: ${this.retryCount > 0 ? 'EmailJS service unavailable' : 'User requested email client'}

Best regards,
${emailData.name}
      `);

      const mailtoUrl = `mailto:${this.FALLBACK_EMAIL}?subject=${subject}&body=${body}`;
      
      console.log('Opening email client with mailto URL');
      window.location.href = mailtoUrl;
      
    } catch (error) {
      console.error('Failed to open email client:', error);
      throw new Error('Unable to open email client');
    }
  }

  /**
   * Smart email sending with automatic fallback handling
   * @param emailData - Email data to send
   * @returns Promise with result
   */
  sendEmailWithSmartFallback(emailData: EmailData): Promise<EmailResponse> {
    return new Promise((resolve, reject) => {
      // Try EmailJS first
      this.sendEmailViaEmailJS(emailData).subscribe({
        next: (response) => {
          resolve(response);
        },
        error: (emailjsError: EmailResponse) => {
          console.warn('EmailJS failed:', emailjsError);
          
          // If it's a CORS or network error, try fallback immediately
          if (emailjsError.errorType === 'cors' || emailjsError.errorType === 'network') {
            try {
              this.openEmailClient(emailData);
              resolve({
                success: true,
                message: 'EmailJS was blocked, but your default email client has been opened with your message.',
                timestamp: new Date(),
                method: 'fallback'
              });
            } catch (fallbackError) {
              reject({
                success: false,
                message: 'Both EmailJS and email client methods failed. Please contact us directly.',
                timestamp: new Date(),
                method: 'fallback',
                errorType: 'unknown'
              });
            }
          } else {
            // For other errors, reject with the original error
            reject(emailjsError);
          }
        }
      });
    });
  }

  /**
   * Check if EmailJS is accessible (for proactive CORS detection)
   * @returns Promise<boolean>
   */
  async checkEmailJSAccessibility(): Promise<boolean> {
    try {
      await this.loadEmailJS();
      const config = this.configService.getConfig();
      
      if (config.emailjs?.enabled) {
        window.emailjs.init(config.emailjs.publicKey);
        return true;
      }
      return false;
    } catch (error) {
      console.warn('EmailJS accessibility check failed:', error);
      return false;
    }
  }

  /**
   * Get available email methods
   * @returns Array of available methods
   */
  getAvailableMethods(): string[] {
    const config = this.configService.getConfig();
    const methods: string[] = [];

    if (config.emailjs?.enabled) methods.push('emailjs');
    if (config.formspree?.enabled) methods.push('formspree');
    if (config.fallback?.enabled) methods.push('fallback');

    return methods;
  }

  /**
   * Get primary email method
   * @returns string - Primary method name
   */
  getPrimaryMethod(): string {
    return this.configService.getPrimaryMethod();
  }

  /**
   * Test EmailJS configuration with CORS detection
   * @returns Promise<boolean>
   */
  async testEmailJSConfig(): Promise<boolean> {
    try {
      const config = this.configService.getConfig();
      if (!config.emailjs?.enabled) {
        return false;
      }

      const isAccessible = await this.checkEmailJSAccessibility();
      if (!isAccessible) {
        console.warn('EmailJS is configured but not accessible - possible CORS issue');
        return false;
      }

      return true;
    } catch (error) {
      console.error('EmailJS test failed:', error);
      return false;
    }
  }

  /**
   * Validate email format
   * @param email - Email to validate
   * @returns boolean
   */
  validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Sanitize input data
   * @param data - Data to sanitize
   * @returns Sanitized data
   */
  sanitizeEmailData(data: EmailData): EmailData {
    return {
      name: this.sanitizeString(data.name),
      email: this.sanitizeString(data.email).toLowerCase(),
      subject: this.sanitizeString(data.subject),
      message: this.sanitizeString(data.message)
    };
  }

  /**
   * Basic string sanitization
   * @param str - String to sanitize
   * @returns Sanitized string
   */
  private sanitizeString(str: string): string {
    return str.trim()
              .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
              .replace(/[<>]/g, '') // Remove < and > characters
              .substring(0, 1000); // Limit length
  }

  /**
   * Reset retry counter (useful for testing)
   */
  resetRetryCount(): void {
    this.retryCount = 0;
  }

  /**
   * Get connection status information
   * @returns Object with connection details
   */
  getConnectionStatus(): { online: boolean; emailjsLoaded: boolean; retryCount: number } {
    return {
      online: navigator.onLine,
      emailjsLoaded: this.emailjsLoaded,
      retryCount: this.retryCount
    };
  }
}