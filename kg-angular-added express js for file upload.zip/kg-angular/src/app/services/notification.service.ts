import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface NotificationData {
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  duration?: number;
  timestamp?: Date;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private notificationSubject = new BehaviorSubject<NotificationData | null>(null);
  private timeoutId: any;

  constructor() { }

  /**
   * Get notification observable
   * @returns Observable of notification data
   */
  getNotification(): Observable<NotificationData | null> {
    return this.notificationSubject.asObservable();
  }

  /**
   * Show success notification
   * @param message - Success message
   * @param duration - Duration in milliseconds (default: 5000)
   */
  showSuccess(message: string, duration: number = 5000): void {
    this.showNotification({
      message,
      type: 'success',
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show error notification
   * @param message - Error message
   * @param duration - Duration in milliseconds (default: 7000)
   */
  showError(message: string, duration: number = 7000): void {
    this.showNotification({
      message,
      type: 'error',
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show warning notification
   * @param message - Warning message
   * @param duration - Duration in milliseconds (default: 6000)
   */
  showWarning(message: string, duration: number = 6000): void {
    this.showNotification({
      message,
      type: 'warning',
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show info notification
   * @param message - Info message
   * @param duration - Duration in milliseconds (default: 4000)
   */
  showInfo(message: string, duration: number = 4000): void {
    this.showNotification({
      message,
      type: 'info',
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show notification
   * @param notification - Notification data
   */
  private showNotification(notification: NotificationData): void {
    // Clear any existing timeout
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }

    // Emit the notification
    this.notificationSubject.next(notification);

    // Auto-hide after specified duration
    if (notification.duration && notification.duration > 0) {
      this.timeoutId = setTimeout(() => {
        this.hideNotification();
      }, notification.duration);
    }
  }

  /**
   * Hide current notification
   */
  hideNotification(): void {
    this.notificationSubject.next(null);
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }

  /**
   * Clear all notifications
   */
  clear(): void {
    this.hideNotification();
  }
}