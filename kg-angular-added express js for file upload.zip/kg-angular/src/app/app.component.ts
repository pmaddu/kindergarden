import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Aacharya - Kindergarten';

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Handle route changes if needed for other functionality
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        // Route changed - can add other logic here if needed
        console.log('Route changed to:', event.url);
      }
    });
  }
}