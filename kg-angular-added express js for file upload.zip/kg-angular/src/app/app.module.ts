import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './pages/home/home.component';
import { AboutComponent } from './pages/about/about.component';
import { ClassesComponent } from './pages/classes/classes.component';
import { GalleryComponent } from './pages/gallery/gallery.component';
import { ContactComponent } from './pages/contact/contact.component';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { FeaturesComponent } from './components/features/features.component';
import { NotificationComponent } from './components/notification/notification.component';

// Pipes
import { FilterPipe } from './pipes/filter.pipe';

// Services
import { EmailService } from './services/email.service';
import { NotificationService } from './services/notification.service';
import { EmailConfigService } from './services/email-config.service';
import { GalleryService } from './services/gallery.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AboutComponent,
    ClassesComponent,
    GalleryComponent,
    ContactComponent,
    BreadcrumbComponent,
    FeaturesComponent,
    NotificationComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    EmailService,
    NotificationService,
    EmailConfigService,
    GalleryService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }