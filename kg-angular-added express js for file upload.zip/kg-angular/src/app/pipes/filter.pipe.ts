import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  transform(items: any[], property: string, value: any): any[] {
    if (!items || !property || value === undefined || value === null) {
      return items;
    }

    return items.filter(item => {
      if (item && item[property]) {
        return item[property].toString().toLowerCase().includes(value.toString().toLowerCase());
      }
      return false;
    });
  }
}