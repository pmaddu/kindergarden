﻿import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { GalleryService, GalleryItem } from '../../services/gallery.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.scss']
})
export class GalleryComponent implements OnInit, OnDestroy {
  activeCategory = 'All';
  isModalOpen = false;
  modalImageSrc = '';
  modalImageAlt = '';
  
  // Upload modal states
  isUploadModalOpen = false;
  isUploading = false;
  uploadProgress = 0;
  
  // Upload form data
  selectedFiles: FileList | null = null;
  uploadCategory = 'Playing';
  uploadAlt = '';
  uploadDescription = '';
  
  // Edit modal states
  isEditModalOpen = false;
  editingItem: GalleryItem | null = null;
  editFormData = {
    category: '',
    alt: '',
    description: ''
  };
  
  // Dynamic properties from service
  categories: string[] = ['All'];
  galleryItems: GalleryItem[] = [];
  filteredItems: GalleryItem[] = [];
  
  // Loading and error states
  isLoading = false;
  error: string | null = null;
  uploadError: string | null = null;
  
  // Server status
  serverAvailable = false;
  
  // Total image count for display
  totalImages = 0;
  
  // File input reference
  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;
  
  private destroy$ = new Subject<void>();

  constructor(private galleryService: GalleryService) {}

  ngOnInit(): void {
    this.initializeGallery();
    this.subscribeToGalleryUpdates();
    this.checkServerStatus();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Initialize gallery with dynamic loading
   */
  initializeGallery(): void {
    console.log('🎨 Initializing dynamic gallery...');
    
    // Load images dynamically
    this.galleryService.loadDynamicImages()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (items) => {
          console.log(`✅ Gallery initialized with ${items.length} images`);
          this.totalImages = items.length;
        },
        error: (error) => {
          console.error('❌ Failed to initialize gallery:', error);
          this.error = 'Failed to load gallery images';
        }
      });
  }

  /**
   * Subscribe to gallery service updates
   */
  private subscribeToGalleryUpdates(): void {
    // Subscribe to gallery items
    this.galleryService.galleryItems$
      .pipe(takeUntil(this.destroy$))
      .subscribe(items => {
        this.galleryItems = items;
        this.filteredItems = [...items];
        this.totalImages = items.length;
        
        // If a category is selected, filter items
        if (this.activeCategory !== 'All') {
          this.filterGallery(this.activeCategory);
        }
      });

    // Subscribe to categories
    this.galleryService.categories$
      .pipe(takeUntil(this.destroy$))
      .subscribe(categories => {
        this.categories = categories;
      });

    // Subscribe to loading state
    this.galleryService.loading$
      .pipe(takeUntil(this.destroy$))
      .subscribe(loading => {
        this.isLoading = loading;
      });

    // Subscribe to error state
    this.galleryService.error$
      .pipe(takeUntil(this.destroy$))
      .subscribe(error => {
        this.error = error;
      });

    // Subscribe to upload progress
    this.galleryService.uploadProgress$
      .pipe(takeUntil(this.destroy$))
      .subscribe(progress => {
        this.uploadProgress = progress;
      });
  }

  /**
   * Check if server is available
   */
  checkServerStatus(): void {
    this.galleryService.checkServerStatus()
      .pipe(takeUntil(this.destroy$))
      .subscribe(available => {
        this.serverAvailable = available;
        if (!available) {
          console.warn('⚠️ Gallery server not available. Upload functionality disabled.');
        }
      });
  }

  /**
   * Filter gallery by category
   */
  filterGallery(category: string): void {
    console.log(`🔍 Filtering gallery by category: ${category}`);
    
    this.activeCategory = category;
    
    if (category === 'All') {
      this.filteredItems = [...this.galleryItems];
    } else {
      this.filteredItems = this.galleryItems.filter(item => item.category === category);
    }
    
    console.log(`📊 Showing ${this.filteredItems.length} items in category: ${category}`);
  }

  /**
   * Open image modal
   */
  openModal(imageSrc: string, imageAlt: string): void {
    this.modalImageSrc = imageSrc;
    this.modalImageAlt = imageAlt;
    this.isModalOpen = true;
    document.body.style.overflow = 'hidden';
    
    console.log(`🖼️ Opening modal for: ${imageAlt}`);
  }

  /**
   * Close image modal
   */
  closeModal(): void {
    this.isModalOpen = false;
    document.body.style.overflow = 'auto';
    this.modalImageSrc = '';
    this.modalImageAlt = '';
  }

  /**
   * Open upload modal
   */
  openUploadModal(): void {
    if (!this.serverAvailable) {
      alert('Upload server is not available. Please try again later.');
      return;
    }
    
    this.isUploadModalOpen = true;
    this.uploadError = null;
    this.selectedFiles = null;
    this.uploadAlt = '';
    this.uploadDescription = '';
    this.uploadCategory = 'Playing';
    document.body.style.overflow = 'hidden';
  }

  /**
   * Close upload modal
   */
  closeUploadModal(): void {
    this.isUploadModalOpen = false;
    document.body.style.overflow = 'auto';
    this.selectedFiles = null;
    this.uploadError = null;
    this.galleryService.resetUploadProgress();
    
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  /**
   * Handle file selection
   */
  onFileSelected(event: any): void {
    const files = event.target.files as FileList;
    
    if (files && files.length > 0) {
      // Validate file types
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif'];
      const maxSize = 10 * 1024 * 1024; // 10MB
      
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        if (!allowedTypes.includes(file.type)) {
          this.uploadError = `Invalid file type: ${file.name}. Allowed types: JPG, PNG, WebP, GIF`;
          return;
        }
        
        if (file.size > maxSize) {
          this.uploadError = `File too large: ${file.name}. Maximum size: 10MB`;
          return;
        }
      }
      
      this.selectedFiles = files;
      this.uploadError = null;
      console.log(`📁 Selected ${files.length} file(s) for upload`);
    }
  }

  /**
   * Upload selected images
   */
  uploadImages(): void {
    if (!this.selectedFiles || this.selectedFiles.length === 0) {
      this.uploadError = 'Please select at least one image';
      return;
    }
    
    if (!this.uploadAlt.trim()) {
      this.uploadError = 'Please provide alt text for the images';
      return;
    }
    
    this.isUploading = true;
    this.uploadError = null;
    
    this.galleryService.uploadImages(
      this.selectedFiles,
      this.uploadCategory,
      this.uploadAlt.trim(),
      this.uploadDescription.trim() || undefined
    ).pipe(takeUntil(this.destroy$))
    .subscribe({
      next: (response) => {
        if (response && response.success) {
          console.log('✅ Upload successful:', response);
          this.closeUploadModal();
          // Show success message
          alert(`Successfully uploaded ${response.uploadedImages.length} image(s) to ${response.category} category!`);
        }
      },
      error: (error) => {
        console.error('❌ Upload failed:', error);
        this.uploadError = error.error?.message || error.message || 'Upload failed. Please try again.';
        this.isUploading = false;
      },
      complete: () => {
        this.isUploading = false;
      }
    });
  }

  /**
   * Open edit modal for image
   */
  openEditModal(item: GalleryItem, event: Event): void {
    event.stopPropagation(); // Prevent opening image modal
    
    if (!this.serverAvailable) {
      alert('Edit server is not available. Please try again later.');
      return;
    }
    
    this.editingItem = item;
    this.editFormData = {
      category: item.category,
      alt: item.alt,
      description: item.description || ''
    };
    
    this.isEditModalOpen = true;
    document.body.style.overflow = 'hidden';
  }

  /**
   * Close edit modal
   */
  closeEditModal(): void {
    this.isEditModalOpen = false;
    document.body.style.overflow = 'auto';
    this.editingItem = null;
  }

  /**
   * Update image metadata
   */
  updateImageMetadata(): void {
    if (!this.editingItem) return;
    
    const updates = {
      category: this.editFormData.category,
      alt: this.editFormData.alt.trim(),
      description: this.editFormData.description.trim()
    };
    
    this.galleryService.updateImageMetadata(this.editingItem.filename, updates)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          if (response.success) {
            console.log('✅ Image updated successfully');
            this.closeEditModal();
            alert('Image updated successfully!');
          }
        },
        error: (error) => {
          console.error('❌ Update failed:', error);
          alert(error.error?.message || 'Update failed. Please try again.');
        }
      });
  }

  /**
   * Delete image
   */
  deleteImage(item: GalleryItem, event: Event): void {
    event.stopPropagation(); // Prevent opening image modal
    
    if (!this.serverAvailable) {
      alert('Delete server is not available. Please try again later.');
      return;
    }
    
    const confirmDelete = confirm(`Are you sure you want to delete "${item.alt}"? This action cannot be undone.`);
    
    if (confirmDelete) {
      this.galleryService.deleteImage(item.filename)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (response) => {
            if (response.success) {
              console.log('✅ Image deleted successfully');
              alert('Image deleted successfully!');
            }
          },
          error: (error) => {
            console.error('❌ Delete failed:', error);
            alert(error.error?.message || 'Delete failed. Please try again.');
          }
        });
    }
  }

  /**
   * Refresh gallery (reload images from assets)
   */
  refreshGallery(): void {
    console.log('🔄 Manual gallery refresh triggered');
    
    if (this.serverAvailable) {
      // Try server refresh first
      this.galleryService.refreshGalleryFromServer()
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (response) => {
            console.log('✅ Server refresh completed');
            this.activeCategory = 'All';
          },
          error: (error) => {
            console.error('❌ Server refresh failed, trying local refresh');
            this.localRefresh();
          }
        });
    } else {
      this.localRefresh();
    }
  }

  /**
   * Local refresh fallback
   */
  private localRefresh(): void {
    this.galleryService.refreshGallery()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (items) => {
          console.log(`✅ Local refresh completed with ${items.length} images`);
          this.activeCategory = 'All';
        },
        error: (error) => {
          console.error('❌ Failed to refresh gallery:', error);
          this.error = 'Failed to refresh gallery';
        }
      });
  }

  /**
   * Handle image loading errors
   */
  onImageError(event: any, item: GalleryItem): void {
    console.warn(`❌ Failed to load image: ${item.filename}`);
    
    // Use a base64 placeholder image instead of referencing a potentially missing file
    const placeholderDataUrl = 'data:image/svg+xml;base64,' + btoa(`
      <svg width="400" height="300" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300">
        <rect width="400" height="300" fill="#f8f9fa"/>
        <rect x="160" y="120" width="80" height="60" rx="8" fill="#dee2e6"/>
        <circle cx="180" cy="140" r="8" fill="#6c757d"/>
        <path d="M170 155 L190 145 L210 160 L200 170 L180 165 Z" fill="#6c757d"/>
        <text x="200" y="200" text-anchor="middle" fill="#6c757d" font-family="Arial" font-size="14">
          Image not found
        </text>
        <text x="200" y="220" text-anchor="middle" fill="#adb5bd" font-family="Arial" font-size="12">
          ${item.filename}
        </text>
      </svg>
    `);
    
    event.target.src = placeholderDataUrl;
    event.target.classList.add('image-error');
    
    // Mark as failed to load
    item.isLoaded = false;
  }

  /**
   * Handle successful image loading
   */
  onImageLoad(event: any, item: GalleryItem): void {
    console.log(`✅ Successfully loaded: ${item.filename}`);
    item.isLoaded = true;
    
    // Add fade-in animation class
    event.target.classList.add('loaded');
  }

  /**
   * Get image count for current category
   */
  getCurrentCategoryCount(): number {
    return this.filteredItems.length;
  }

  /**
   * Check if gallery is empty
   */
  isGalleryEmpty(): boolean {
    return this.galleryItems.length === 0 && !this.isLoading;
  }

  /**
   * Get loading progress (if needed for UI)
   */
  getLoadingProgress(): number {
    if (this.galleryItems.length === 0) return 0;
    const loadedCount = this.galleryItems.filter(item => item.isLoaded).length;
    return Math.round((loadedCount / this.galleryItems.length) * 100);
  }

  /**
   * Track by function for ngFor performance
   */
  trackByItem(index: number, item: GalleryItem): number {
    return item.id;
  }

  /**
   * Track by function for categories
   */
  trackByCategory(index: number, category: string): string {
    return category;
  }

  /**
   * Get filtered items by category (helper method for template)
   */
  getFilteredItemsByCategory(items: GalleryItem[], category: string): GalleryItem[] {
    if (!items || !category || category === 'All') {
      return items || [];
    }
    return items.filter(item => item.category === category);
  }

  /**
   * Get count of images for a specific category
   */
  getCategoryCount(category: string): number {
    if (category === 'All') {
      return this.galleryItems.length;
    }
    return this.galleryItems.filter(item => item.category === category).length;
  }

  /**
   * Get all unique categories from gallery items
   */
  getUniqueCategories(): string[] {
    const categories = new Set<string>(['All']);
    this.galleryItems.forEach(item => {
      if (item.category && item.category !== 'All') {
        categories.add(item.category);
      }
    });
    return Array.from(categories);
  }

  /**
   * Check if category has any images
   */
  categoryHasImages(category: string): boolean {
    if (category === 'All') {
      return this.galleryItems.length > 0;
    }
    return this.galleryItems.some(item => item.category === category);
  }

  /**
   * Get category icon based on category name
   */
  getCategoryIcon(category: string): string {
    const iconMap: { [key: string]: string } = {
      'All': 'fa-images',
      'Playing': 'fa-running',
      'Drawing': 'fa-palette',
      'Reading': 'fa-book-open',
      'Learning': 'fa-graduation-cap',
      'Activities': 'fa-calendar-alt'
    };
    return iconMap[category] || 'fa-image';
  }

  /**
   * Get category description
   */
  getCategoryDescription(category: string): string {
    const descriptions: { [key: string]: string } = {
      'All': 'All images from our gallery',
      'Playing': 'Children enjoying playtime and recreational activities',
      'Drawing': 'Creative art sessions and drawing activities',
      'Reading': 'Story time and reading sessions',
      'Learning': 'Educational activities and learning sessions',
      'Activities': 'Various school events and special activities'
    };
    return descriptions[category] || 'Images in this category';
  }

  /**
   * Get available categories for upload (excluding 'All')
   */
  getUploadCategories(): string[] {
    return this.categories.filter(cat => cat !== 'All');
  }

  /**
   * Format file size for display
   */
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Get selected files as array for template iteration
   */
  getSelectedFilesArray(): File[] {
    if (!this.selectedFiles) return [];
    
    const filesArray: File[] = [];
    for (let i = 0; i < this.selectedFiles.length; i++) {
      filesArray.push(this.selectedFiles[i]);
    }
    return filesArray;
  }

  /**
   * Get total selected file size
   */
  getTotalFileSize(): string {
    if (!this.selectedFiles) return '0 Bytes';
    
    let totalSize = 0;
    for (let i = 0; i < this.selectedFiles.length; i++) {
      totalSize += this.selectedFiles[i].size;
    }
    
    return this.formatFileSize(totalSize);
  }
}
