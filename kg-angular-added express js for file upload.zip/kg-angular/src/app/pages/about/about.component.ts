import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {
  aboutFeatures = [
    {
      icon: 'fa-solid fa-graduation-cap',
      title: 'Play Ground',
      description: 'Safe and well-equipped playground for children to develop physical skills and social interaction...'
    },
    {
      icon: 'fa-solid fa-music',
      title: 'Music and Dance',
      description: 'Creative expression through music and dance helps develop rhythm, coordination, and confidence...'
    },
    {
      icon: 'fa-solid fa-palette',
      title: 'Arts and Crafts',
      description: 'Hands-on creative activities that foster imagination, fine motor skills, and artistic expression...'
    },
    {
      icon: 'fa-solid fa-bus',
      title: 'Safe Transportation',
      description: 'Reliable and secure transportation service with trained staff to ensure children\'s safety...'
    },
    {
      icon: 'fa-solid fa-apple-alt',
      title: 'Healthy Food',
      description: 'Nutritious meals and snacks prepared with care to support children\'s healthy growth and development...'
    },
    {
      icon: 'fa-solid fa-map-marked-alt',
      title: 'Educational Tours',
      description: 'Learning adventures outside the classroom to broaden horizons and create memorable experiences...'
    }
  ];

  teachers = [
    {
      name: 'Sarah Johnson',
      role: 'Principal',
      image: 'assets/img/team-1.jpg'
    },
    {
      name: 'Emily Davis',
      role: 'Lead Teacher',
      image: 'assets/img/team-2.jpg'
    },
    {
      name: 'Jessica Wilson',
      role: 'Art Teacher',
      image: 'assets/img/team-3.jpg'
    },
    {
      name: 'Michael Brown',
      role: 'Physical Education',
      image: 'assets/img/team-4.jpg'
    }
  ];

  constructor() {}

  ngOnInit(): void {}
}