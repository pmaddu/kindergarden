import { Component, OnInit } from '@angular/core';

interface ClassInfo {
  name: string;
  image: string;
  description: string;
  ageRange: string;
  seats: number;
  time: string;
  fee: string;
}

@Component({
  selector: 'app-classes',
  templateUrl: './classes.component.html',
  styleUrls: ['./classes.component.scss']
})
export class ClassesComponent implements OnInit {
  booking = {
    name: '',
    email: '',
    selectedClass: ''
  };

  classes: ClassInfo[] = [
    {
      name: 'Drawing Class',
      image: 'assets/img/class-1.jpg',
      description: 'Creative art classes that help develop fine motor skills, creativity, and self-expression through various drawing techniques and mediums.',
      ageRange: '3 - 6 Years',
      seats: 40,
      time: '08:00 - 10:00',
      fee: 'Rs.2900 / Month'
    },
    {
      name: 'Language Learning',
      image: 'assets/img/class-2.jpg',
      description: 'Interactive language sessions focusing on vocabulary building, communication skills, and early literacy development through fun activities.',
      ageRange: '3 - 6 Years',
      seats: 35,
      time: '10:30 - 12:30',
      fee: 'Rs.3200 / Month'
    },
    {
      name: 'Basic Science',
      image: 'assets/img/class-3.jpg',
      description: 'Hands-on science exploration introducing basic concepts through experiments, observation, and discovery-based learning.',
      ageRange: '4 - 6 Years',
      seats: 30,
      time: '14:00 - 16:00',
      fee: 'Rs.3500 / Month'
    }
  ];

  constructor() {}

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.booking.name && this.booking.email && this.booking.selectedClass) {
      alert(`Thank you ${this.booking.name}! We'll contact you soon regarding the ${this.booking.selectedClass} enrollment.`);
      this.booking = { name: '', email: '', selectedClass: '' };
    }
  }
}