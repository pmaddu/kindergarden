# Email Service Integration - Setup Guide

This project includes a comprehensive email service system with multiple sending methods and user-friendly notifications.

## ?? Features

- **Multiple Email Services**: Formspree, EmailJS, and Email Client fallback
- **Smart Fallback**: Automatically falls back to email client if primary service fails
- **User Notifications**: Toast-style notifications with success/error feedback
- **Form Validation**: Comprehensive client-side validation with error messages
- **Mobile Responsive**: Optimized for all device sizes
- **Accessibility**: WCAG compliant with keyboard navigation and screen reader support

## ?? Email Service Configuration

### Method 1: Formspree (Recommended for beginners)

1. Go to [Formspree.io](https://formspree.io) and create a free account
2. Create a new form and get your Form ID (e.g., `xvgprkgl`)
3. Update `src/app/services/email-config.service.ts`:
   ```typescript
   formspree: {
     enabled: true, // Change to true
     formId: 'your-actual-form-id', // Replace with your form ID
     endpoint: 'https://formspree.io/f/your-actual-form-id'
   }
   ```

### Method 2: EmailJS (More advanced)

1. Go to [EmailJS.com](https://www.emailjs.com) and create an account
2. Create an email service (Gmail, Outlook, etc.)
3. Create an email template with these variables:
   - `{{from_name}}`
   - `{{from_email}}`
   - `{{subject}}`
   - `{{message}}`
   - `{{to_email}}`
4. Get your Service ID, Template ID, and Public Key
5. Update `src/app/services/email-config.service.ts`:
   ```typescript
   emailjs: {
     enabled: true, // Change to true
     serviceId: 'your_service_id',
     templateId: 'your_template_id', 
     publicKey: 'your_public_key'
   }
   ```

### Method 3: Email Client Fallback (Always Available)

This method opens the user's default email client with a pre-filled message. No additional setup required - it works out of the box!

## ??? Installation & Usage

1. The services are already integrated in the contact component
2. Configure your preferred email service using the instructions above
3. Test the contact form at `/contact`

## ?? Notification System

The application includes a comprehensive notification system:

- **Success**: Green notifications for successful operations
- **Error**: Red notifications for errors  
- **Warning**: Orange notifications for warnings
- **Info**: Blue notifications for information

Notifications automatically disappear after a set duration and can be manually closed.

## ?? Mobile Features

- **Touch-friendly**: Large touch targets for mobile devices
- **Responsive**: Adapts to all screen sizes
- **Swipe Support**: (For the home slider)
- **Performance**: Optimized for mobile performance

## ?? Customization

### Email Configuration
Edit `src/app/services/email-config.service.ts` to modify:
- Email service settings
- Recipient email address
- Service priorities

### Notification Styling  
Edit `src/app/components/notification/notification.component.scss` to customize:
- Colors and themes
- Animation styles
- Positioning

### Form Validation
Edit `src/app/pages/contact/contact.component.ts` to modify:
- Validation rules
- Error messages
- Field requirements

## ?? Current Status

- ? Email service architecture created
- ? Notification system implemented
- ? Contact form integration completed
- ? Fallback method (email client) working
- ?? Formspree/EmailJS: Requires your configuration
- ? Form validation and user feedback
- ? Mobile responsiveness
- ? Accessibility features

## ?? Next Steps

1. Choose and configure your preferred email service (Formspree or EmailJS)
2. Test the contact form functionality
3. Customize styling to match your brand
4. Add any additional form fields if needed

## ?? Troubleshooting

### Contact Form Not Sending
1. Check browser console for errors
2. Verify email service configuration
3. Test with fallback method (email client)
4. Check network connectivity

### Notifications Not Showing
1. Ensure `<app-notification></app-notification>` is in app.component.html
2. Check CSS z-index conflicts
3. Verify NotificationService is injected properly

### Form Validation Issues
1. Check Angular FormsModule is imported
2. Verify form field names match component properties
3. Test with browser developer tools

## ?? Tips

- Start with the fallback method to test the form
- Formspree is easier for beginners
- EmailJS gives you more control but requires more setup
- Always test on mobile devices
- Use browser developer tools to debug issues

---

Need help? Check the code comments or create an issue in the repository!