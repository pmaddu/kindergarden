import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  isSubmitting = false;
  
  formData = {
    name: '',
    email: '',
    subject: '',
    message: ''
  };

  constructor() {}

  ngOnInit(): void {}

  onSubmit(form: NgForm) {
    if (form.valid) {
      this.isSubmitting = true;
      
      // Simulate form submission
      setTimeout(() => {
        alert(`Thank you ${this.formData.name}! Your message has been sent. We'll get back to you soon.`);
        this.formData = { name: '', email: '', subject: '', message: '' };
        form.resetForm();
        this.isSubmitting = false;
      }, 2000);
    }
  }
}