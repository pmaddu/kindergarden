﻿const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const sharp = require('sharp');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');

const app = express();
const PORT = process.env.PORT || 3001;

// Configuration
const config = {
  uploadPath: './uploads/gallery',
  assetsPath: '../src/assets/img',
  manifestPath: '../src/assets/gallery-manifest.json',
  maxFileSize: 10 * 1024 * 1024, // 10MB
  allowedFormats: ['jpg', 'jpeg', 'png', 'webp', 'gif'],
  categories: ['Playing', 'Drawing', 'Reading', 'Learning', 'Activities'],
  thumbnailSize: { width: 400, height: 300 },
  imageQuality: 85
};

// Middleware setup
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));

app.use(cors({
  origin: ['http://localhost:4200', 'http://127.0.0.1:4200'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Accept']
}));

app.use(morgan('combined'));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Rate limiting
const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // limit each IP to 10 uploads per windowMs
  message: {
    error: 'Too many upload requests, please try again later.',
    retryAfter: '15 minutes'
  }
});

// Serve static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/assets', express.static(path.join(__dirname, '../src/assets')));

/**
 * Initialize directory structure
 */
async function initializeDirectories() {
  try {
    // Create main upload directory
    await fs.ensureDir(config.uploadPath);
    
    // Create category-specific directories
    for (const category of config.categories) {
      const categoryPath = path.join(config.uploadPath, category.toLowerCase());
      await fs.ensureDir(categoryPath);
      console.log(`?? Created/verified directory: ${categoryPath}`);
    }
    
    // Create thumbnails directory
    await fs.ensureDir(path.join(config.uploadPath, 'thumbnails'));
    
    // Ensure assets directory exists
    await fs.ensureDir(path.dirname(config.assetsPath));
    
    console.log('? All directories initialized successfully');
  } catch (error) {
    console.error('? Failed to initialize directories:', error);
  }
}

/**
 * Configure multer for file uploads with proper category handling
 */
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    try {
      console.log('🔍 Multer destination - req.body:', req.body);
      console.log('🔍 File info:', { originalname: file.originalname, fieldname: file.fieldname });
      
      // Extract category from request body
      let category = req.body.category;
      
      // If category is not available yet (timing issue with multipart parsing), 
      // we need to parse it manually or use a default
      if (!category) {
        console.log('⚠️ Category not found in req.body, checking for manual parsing...');
        
        // For multipart forms, the text fields might not be parsed yet
        // Let's try to extract it from the raw body if available
        if (req.body && typeof req.body === 'object') {
          category = req.body.category;
        }
        
        // If still no category, default to 'Activities' temporarily
        // This will be corrected in the upload handler
        if (!category) {
          category = 'Activities';
          console.log('⚠️ Using fallback category: Activities');
        }
      }
      
      console.log(`📂 Setting destination for category: ${category}`);
      
      // Ensure the category directory exists
      const categoryPath = path.join(config.uploadPath, category.toLowerCase());
      await fs.ensureDir(categoryPath);
      
      console.log(`✅ Category directory ready: ${categoryPath}`);
      cb(null, categoryPath);
      
    } catch (error) {
      console.error('❌ Error in multer destination:', error);
      // Fallback to activities folder if there's an error
      const fallbackPath = path.join(config.uploadPath, 'activities');
      await fs.ensureDir(fallbackPath);
      cb(null, fallbackPath);
    }
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = uuidv4();
    const ext = path.extname(file.originalname).toLowerCase();
    const baseName = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9-_]/g, '');
    const filename = `${baseName}_${uniqueSuffix}${ext}`;
    console.log(`📄 Generated filename: ${filename}`);
    cb(null, filename);
  }
});

const fileFilter = (req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
  if (config.allowedFormats.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error(`Invalid file format. Allowed formats: ${config.allowedFormats.join(', ')}`), false);
  }
};

// Enhanced multer configuration with better error handling
const upload = multer({
  storage: storage,
  limits: {
    fileSize: config.maxFileSize,
    files: 5 // Maximum 5 files per request
  },
  fileFilter: fileFilter
}).array('images', 5);

// Create a custom upload middleware to handle the category parsing issue
const handleUpload = (req, res, next) => {
  console.log('🚀 Starting upload process...');
  console.log('📋 Request body before multer:', req.body);
  
  upload(req, res, async (err) => {
    if (err) {
      console.error('❌ Multer error:', err);
      if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(400).json({ 
            error: 'File too large', 
            message: `Maximum file size is ${config.maxFileSize / (1024 * 1024)}MB` 
          });
        }
        if (err.code === 'LIMIT_FILE_COUNT') {
          return res.status(400).json({ 
            error: 'Too many files', 
            message: 'Maximum 5 files per upload' 
          });
        }
      }
      return res.status(400).json({ 
        error: 'Upload failed', 
        message: err.message 
      });
    }
    
    console.log('📋 Request body after multer:', req.body);
    console.log('📁 Files received:', req.files?.length || 0);
    
    // If files were uploaded to wrong directory due to timing issue, move them
    if (req.files && req.files.length > 0 && req.body.category) {
      const correctCategory = req.body.category;
      console.log(`🔧 Verifying files are in correct category folder: ${correctCategory}`);
      
      for (const file of req.files) {
        const currentPath = file.path;
        const expectedPath = path.join(config.uploadPath, correctCategory.toLowerCase(), file.filename);
        
        console.log('🔍 File paths:', {
          current: currentPath,
          expected: expectedPath
        });
        
        // Check if file is in wrong directory
        if (currentPath !== expectedPath) {
          try {
            console.log(`📦 Moving file from ${currentPath} to ${expectedPath}`);
            
            // Ensure correct directory exists
            await fs.ensureDir(path.dirname(expectedPath));
            
            // Move the file
            await fs.move(currentPath, expectedPath);
            
            // Update the file object
            file.path = expectedPath;
            file.destination = path.dirname(expectedPath);
            
            console.log(`✅ Successfully moved file to correct category folder`);
          } catch (moveError) {
            console.error(`❌ Failed to move file to correct category:`, moveError);
          }
        }
      }
    }
    
    next();
  });
};

/**
 * Load current gallery manifest
 */
async function loadGalleryManifest() {
  try {
    const manifestExists = await fs.pathExists(config.manifestPath);
    if (!manifestExists) {
      return {
        version: "1.0",
        lastUpdated: new Date().toISOString(),
        basePath: "assets/img/",
        images: [],
        categories: ["All", ...config.categories],
        settings: {
          autoDetectImages: true,
          supportedFormats: config.allowedFormats,
          lazyLoading: true,
          preloadImages: false
        }
      };
    }
    
    const manifestContent = await fs.readFile(config.manifestPath, 'utf-8');
    return JSON.parse(manifestContent);
  } catch (error) {
    console.error('Error loading manifest:', error);
    return null;
  }
}

/**
 * Save gallery manifest
 */
async function saveGalleryManifest(manifest) {
  try {
    manifest.lastUpdated = new Date().toISOString();
    await fs.writeFile(config.manifestPath, JSON.stringify(manifest, null, 2), 'utf-8');
    console.log('? Gallery manifest updated successfully');
    return true;
  } catch (error) {
    console.error('? Failed to save manifest:', error);
    return false;
  }
}

/**
 * Process uploaded image (resize, optimize)
 */
async function processImage(filePath, category) {
  try {
    const outputPath = filePath.replace(path.extname(filePath), '_processed' + path.extname(filePath));
    
    // Process main image
    await sharp(filePath)
      .resize(1200, 900, {
        fit: 'inside',
        withoutEnlargement: true
      })
      .jpeg({ quality: config.imageQuality })
      .toFile(outputPath);
    
    // Generate thumbnail
    const thumbnailDir = path.join(config.uploadPath, 'thumbnails');
    const thumbnailPath = path.join(thumbnailDir, path.basename(outputPath));
    
    await sharp(filePath)
      .resize(config.thumbnailSize.width, config.thumbnailSize.height, {
        fit: 'cover',
        position: 'center'
      })
      .jpeg({ quality: 70 })
      .toFile(thumbnailPath);
    
    // Replace original with processed version
    await fs.remove(filePath);
    await fs.move(outputPath, filePath);
    
    console.log(`? Image processed successfully: ${path.basename(filePath)}`);
    return {
      originalPath: filePath,
      thumbnailPath: thumbnailPath
    };
  } catch (error) {
    console.error('? Image processing failed:', error);
    throw error;
  }
}

// API Routes

/**
 * GET /api/gallery - Get all gallery images from uploads folder
 */
app.get('/api/gallery', async (req, res) => {
  try {
    console.log('?? GET /api/gallery - Scanning uploads directory...');
    
    const includeContent = req.query.includeContent === 'true';
    console.log(`?? Include image content: ${includeContent}`);
    
    const galleryData = includeContent 
      ? await scanUploadsDirectoryWithContent() 
      : await scanUploadsDirectory();
    
    res.json({
      success: true,
      data: galleryData,
      source: 'uploads',
      contentIncluded: includeContent,
      timestamp: new Date().toISOString()
    });
    
    console.log(`? Served ${galleryData.images.length} images from uploads directory`);
  } catch (error) {
    console.error('? Error fetching gallery from uploads:', error);
    res.status(500).json({ 
      error: 'Failed to fetch gallery images from server',
      message: error.message 
    });
  }
});

/**
 * GET /api/gallery/categories - Get all categories from uploads folder
 */
app.get('/api/gallery/categories', async (req, res) => {
  try {
    console.log('?? GET /api/gallery/categories - Scanning uploads directory...');
    
    const galleryData = await scanUploadsDirectory();
    
    res.json({
      success: true,
      categories: galleryData.categories,
      source: 'uploads',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('? Error fetching categories from uploads:', error);
    res.status(500).json({ 
      error: 'Failed to fetch categories from server',
      message: error.message 
    });
  }
});

/**
 * GET /api/gallery/category/:category - Get images by category from uploads folder
 */
app.get('/api/gallery/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const includeContent = req.query.includeContent === 'true';
    console.log(`?? GET /api/gallery/category/${category} - Scanning uploads directory ${includeContent ? 'WITH content' : 'WITHOUT content'}...`);
    
    const galleryData = includeContent 
      ? await scanUploadsDirectoryWithContent() 
      : await scanUploadsDirectory();
    
    const filteredImages = category === 'All' 
      ? galleryData.images 
      : galleryData.images.filter(img => img.category.toLowerCase() === category.toLowerCase());
    
    res.json({
      success: true,
      category: category,
      count: filteredImages.length,
      images: filteredImages,
      source: 'uploads',
      contentIncluded: includeContent,
      timestamp: new Date().toISOString()
    });
    
    console.log(`? Served ${filteredImages.length} images for category: ${category} ${includeContent ? 'WITH content' : 'WITHOUT content'}`);
  } catch (error) {
    console.error('? Error fetching category images from uploads:', error);
    res.status(500).json({ 
      error: 'Failed to fetch category images from server',
      message: error.message 
    });
  }
});

/**
 * POST /api/gallery/upload - Upload new images with dynamic category validation
 */
app.post('/api/gallery/upload', uploadLimiter, handleUpload, [
  body('category').isLength({ min: 1, max: 50 }).withMessage('Category is required and must be less than 50 characters')
], async (req, res) => {
  try {
    // Basic validation
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: errors.array() 
      });
    }
    
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }
    
    const { category } = req.body;
    
    // Get available categories dynamically
    const availableCategories = await scanUploadsDirectoryForCategories();
    
    // Check if category exists, if not create it
    if (!availableCategories.includes(category)) {
      console.log(`?? Category "${category}" doesn't exist, creating it...`);
      const categoryPath = path.join(config.uploadPath, category.toLowerCase());
      await fs.ensureDir(categoryPath);
      console.log(`? Created new category directory: ${categoryPath}`);
    }
    
    const uploadedImages = [];
    
    console.log(`?? Processing ${req.files.length} file(s) for ${category} category...`);
    
    // Process each uploaded file
    for (const file of req.files) {
      try {
        console.log(`?? Processing: ${file.filename}`);
        
        // Process image (resize, optimize)
        const processed = await processImage(file.path, category);
        
        // Create image metadata (stored in file system structure only)
        const imageData = {
          filename: file.filename,
          category: category,
          alt: `${category} image`,
          description: `Image in ${category} category`,
          originalName: file.originalname,
          size: file.size,
          uploadDate: new Date().toISOString(),
          path: `uploads/gallery/${category.toLowerCase()}/${file.filename}`,
          thumbnailPath: `uploads/gallery/thumbnails/${file.filename}`
        };
        
        uploadedImages.push(imageData);
        console.log(`? Successfully processed: ${file.filename}`);
      } catch (fileError) {
        console.error(`? Failed to process ${file.filename}:`, fileError);
        // Clean up failed upload
        try {
          await fs.remove(file.path);
        } catch (cleanupError) {
          console.error('Cleanup error:', cleanupError);
        }
      }
    }
    
    // Get updated categories after upload
    const updatedCategories = await scanUploadsDirectoryForCategories();
    
    res.json({
      success: true,
      message: `Successfully uploaded ${uploadedImages.length} image(s) to ${category} category`,
      uploadedImages: uploadedImages,
      category: category,
      availableCategories: updatedCategories,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ 
      error: 'Failed to upload images',
      message: error.message 
    });
  }
});

/**
 * DELETE /api/gallery/image/:filename - Delete an image from uploads folder
 */
app.delete('/api/gallery/image/:filename', async (req, res) => {
  try {
    const { filename } = req.params;
    console.log(`??? Deleting image: ${filename}`);
    
    // Scan uploads directory to find the image
    const galleryData = await scanUploadsDirectory();
    const imageData = galleryData.images.find(img => img.filename === filename);
    
    if (!imageData) {
      return res.status(404).json({ error: 'Image not found in uploads' });
    }
    
    // Delete files from uploads directory
    try {
      // Delete from category folder
      const categoryPath = path.join(config.uploadPath, imageData.category.toLowerCase(), filename);
      await fs.remove(categoryPath);
      console.log(`? Deleted main file: ${categoryPath}`);
      
      // Delete thumbnail
      const thumbnailPath = path.join(config.uploadPath, 'thumbnails', filename);
      await fs.remove(thumbnailPath);
      console.log(`? Deleted thumbnail: ${thumbnailPath}`);
      
    } catch (fileError) {
      console.warn('?? Some files could not be deleted:', fileError.message);
    }
    
    res.json({
      success: true,
      message: `Image ${filename} deleted successfully`,
      deletedImage: imageData,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('? Delete error:', error);
    res.status(500).json({ 
      error: 'Failed to delete image',
      message: error.message 
    });
  }
});

app.put('/api/gallery/image/:filename', [
  body('category').optional().isIn(config.categories),
  body('alt').optional().isLength({ min: 1, max: 200 }),
  body('description').optional().isLength({ max: 500 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: errors.array() 
      });
    }
    
    const { filename } = req.params;
    const updates = req.body;
    
    // Load manifest
    const manifest = await loadGalleryManifest();
    if (!manifest) {
      return res.status(500).json({ error: 'Failed to load gallery manifest' });
    }
    
    // Find and update image
    const imageIndex = manifest.images.findIndex(img => img.filename === filename);
    if (imageIndex === -1) {
      return res.status(404).json({ error: 'Image not found' });
    }
    
    // Update metadata
    const imageData = manifest.images[imageIndex];
    Object.assign(imageData, updates, { 
      updatedDate: new Date().toISOString() 
    });
    
    // If category changed, move file
    if (updates.category && updates.category !== imageData.category) {
      try {
        const oldPath = path.join(config.uploadPath, imageData.category.toLowerCase(), filename);
        const newPath = path.join(config.uploadPath, updates.category.toLowerCase(), filename);
        
        await fs.ensureDir(path.dirname(newPath));
        await fs.move(oldPath, newPath);
        
        console.log(`? Moved image from ${imageData.category} to ${updates.category}`);
      } catch (moveError) {
        console.error('Failed to move image file:', moveError);
      }
    }
    
    await saveGalleryManifest(manifest);
    
    res.json({
      success: true,
      message: 'Image updated successfully',
      updatedImage: imageData,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Update error:', error);
    res.status(500).json({ 
      error: 'Failed to update image',
      message: error.message 
    });
  }
});

/**
 * POST /api/gallery/refresh - Refresh gallery by scanning uploads directory
 */
app.post('/api/gallery/refresh', async (req, res) => {
  try {
    console.log('?? Refreshing gallery by scanning uploads directory...');
    
    // Simply scan the uploads directory
    const galleryData = await scanUploadsDirectory();
    
    res.json({
      success: true,
      message: `Gallery refreshed successfully from uploads directory.`,
      totalImages: galleryData.images.length,
      categories: galleryData.categories,
      source: 'uploads',
      timestamp: new Date().toISOString()
    });
    
    console.log(`? Refresh complete: Found ${galleryData.images.length} images in uploads directory`);
    
  } catch (error) {
    console.error('? Refresh error:', error);
    res.status(500).json({ 
      error: 'Failed to refresh gallery',
      message: error.message 
    });
  }
});

/**
 * POST /api/gallery/categories - Create a new category (folder)
 */
app.post('/api/gallery/categories', [
  body('categoryName').isLength({ min: 1, max: 50 }).matches(/^[a-zA-Z0-9\s-_]+$/).withMessage('Category name must be 1-50 characters and contain only letters, numbers, spaces, hyphens, and underscores')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: errors.array() 
      });
    }
    
    const { categoryName } = req.body;
    console.log(`?? Creating new category: ${categoryName}`);
    
    // Sanitize category name
    const sanitizedName = categoryName.trim().replace(/\s+/g, ' '); // Clean up spaces
    const folderName = sanitizedName.toLowerCase().replace(/\s+/g, '_'); // Convert to folder name
    
    // Create category directory
    const categoryPath = path.join(config.uploadPath, folderName);
    
    try {
      await fs.ensureDir(categoryPath);
      console.log(`? Created category directory: ${categoryPath}`);
      
      // Return updated categories list
      const discoveredCategories = await scanUploadsDirectoryForCategories();
      
      res.json({
        success: true,
        message: `Category "${sanitizedName}" created successfully`,
        categoryName: sanitizedName,
        folderName: folderName,
        categories: discoveredCategories,
        timestamp: new Date().toISOString()
      });
      
    } catch (createError) {
      console.error('? Failed to create category directory:', createError);
      res.status(500).json({
        error: 'Failed to create category directory',
        message: createError.message
      });
    }
    
  } catch (error) {
    console.error('? Create category error:', error);
    res.status(500).json({ 
      error: 'Failed to create category',
      message: error.message 
    });
  }
});

/**
 * GET /api/gallery/categories/available - Get all available categories from folders
 */
app.get('/api/gallery/categories/available', async (req, res) => {
  try {
    console.log('?? GET /api/gallery/categories/available - Getting available categories...');
    
    const discoveredCategories = await scanUploadsDirectoryForCategories();
    
    res.json({
      success: true,
      categories: discoveredCategories,
      totalCategories: discoveredCategories.length,
      source: 'dynamic_folders',
      timestamp: new Date().toISOString()
    });
    
    console.log(`? Served ${discoveredCategories.length} available categories`);
  } catch (error) {
    console.error('? Error fetching available categories:', error);
    res.status(500).json({ 
      error: 'Failed to fetch available categories',
      message: error.message 
    });
  }
});

/**
 * Scan uploads directory and build gallery data (independent of manifest)
 */
async function scanUploadsDirectory() {
  try {
    // First, discover available categories from actual folders
    const discoveredCategories = await scanUploadsDirectoryForCategories();
    
    const galleryData = {
      version: "1.0",
      lastUpdated: new Date().toISOString(),
      basePath: "uploads/gallery/",
      images: [],
      categories: ["All", ...discoveredCategories], // Dynamic categories
      settings: {
        autoDetectImages: true,
        supportedFormats: config.allowedFormats,
        lazyLoading: true,
        preloadImages: false
      }
    };

    console.log('?? Scanning uploads directory for images...');
    console.log(`??? Using categories: ${discoveredCategories.join(', ')}`);

    // Scan category directories in uploads (using discovered categories)
    for (const category of discoveredCategories) {
      const categoryPath = path.join(config.uploadPath, category.toLowerCase());
      
      try {
        // Check if directory exists
        const dirExists = await fs.pathExists(categoryPath);
        if (!dirExists) {
          console.log(`?? Category directory does not exist: ${categoryPath}, skipping...`);
          continue;
        }
        
        const files = await fs.readdir(categoryPath);
        const imageFiles = files.filter(file => {
          const ext = path.extname(file).toLowerCase().replace('.', '');
          return config.allowedFormats.includes(ext);
        });

        console.log(`?? Found ${imageFiles.length} images in ${category} category`);

        // Add each image to gallery data
        for (const filename of imageFiles) {
          try {
            const filePath = path.join(categoryPath, filename);
            const stats = await fs.stat(filePath);
            
            const imageData = {
              filename: filename,
              category: category,
              alt: `${category} image`,
              description: `Image from ${category} category`,
              size: stats.size,
              uploadDate: stats.birthtime.toISOString(),
              path: `uploads/gallery/${category.toLowerCase()}/${filename}`,
              thumbnailPath: `uploads/gallery/thumbnails/${filename}`
            };

            galleryData.images.push(imageData);
          } catch (fileError) {
            console.warn(`?? Could not process file ${filename}:`, fileError.message);
          }
        }
      } catch (dirError) {
        console.warn(`?? Could not scan directory ${categoryPath}:`, dirError.message);
      }
    }

    console.log(`? Scanned uploads directory: ${galleryData.images.length} images found across ${discoveredCategories.length} categories`);
    return galleryData;
  } catch (error) {
    console.error('? Failed to scan uploads directory:', error);
    return {
      version: "1.0",
      lastUpdated: new Date().toISOString(),
      basePath: "uploads/gallery/",
      images: [],
      categories: ["All", ...config.categories], // Fallback to default
      settings: {
        autoDetectImages: true,
        supportedFormats: config.allowedFormats,
        lazyLoading: true,
        preloadImages: false
      }
    };
  }
}

/**
 * Scan uploads directory and discover categories dynamically
 */
async function scanUploadsDirectoryForCategories() {
  try {
    console.log('?? Scanning uploads directory for category folders...');
    
    const uploadPath = config.uploadPath;
    await fs.ensureDir(uploadPath);
    
    const items = await fs.readdir(uploadPath, { withFileTypes: true });
    const discoveredCategories = [];
    
    // Find all directories (excluding thumbnails)
    for (const item of items) {
      if (item.isDirectory() && item.name !== 'thumbnails') {
        // Convert folder name to proper category name (capitalize first letter)
        const categoryName = item.name.charAt(0).toUpperCase() + item.name.slice(1).toLowerCase();
        discoveredCategories.push(categoryName);
        console.log(`?? Found category folder: ${item.name} -> ${categoryName}`);
      }
    }
    
    // If no categories found, use default ones
    if (discoveredCategories.length === 0) {
      console.log('?? No category folders found, using default categories');
      return config.categories;
    }
    
    console.log(`? Discovered ${discoveredCategories.length} categories:`, discoveredCategories);
    return discoveredCategories;
    
  } catch (error) {
    console.error('? Failed to scan for categories:', error);
    return config.categories; // Fallback to default
  }
}

/**
 * Scan uploads directory and include image content as base64
 */
async function scanUploadsDirectoryWithContent() {
  try {
    const galleryData = {
      version: "1.0",
      lastUpdated: new Date().toISOString(),
      basePath: "uploads/gallery/",
      images: [],
      categories: ["All", ...config.categories],
      settings: {
        autoDetectImages: true,
        supportedFormats: config.allowedFormats,
        lazyLoading: true,
        preloadImages: false
      }
    };

    console.log('?? Scanning uploads directory for images with content...');

    // Scan category directories in uploads
    for (const category of config.categories) {
      const categoryPath = path.join(config.uploadPath, category.toLowerCase());
      
      try {
        // Ensure directory exists
        await fs.ensureDir(categoryPath);
        
        const files = await fs.readdir(categoryPath);
        const imageFiles = files.filter(file => {
          const ext = path.extname(file).toLowerCase().replace('.', '');
          return config.allowedFormats.includes(ext);
        });

        console.log(`?? Found ${imageFiles.length} images in ${category} category`);

        // Add each image to gallery data
        for (const filename of imageFiles) {
          try {
            const filePath = path.join(categoryPath, filename);
            const stats = await fs.stat(filePath);
            
            // Read image content as base64
            const { content: base64Content, mimeType } = await readImageAsBase64(filePath, filename);
            
            const imageData = {
              filename: filename,
              category: category,
              alt: `${category} image`,
              description: `Image from ${category} category`,
              size: stats.size,
              uploadDate: stats.birthtime.toISOString(),
              path: `uploads/gallery/${category.toLowerCase()}/${filename}`,
              thumbnailPath: `uploads/gallery/thumbnails/${filename}`,
              content: base64Content,
              mimeType: mimeType
            };

            galleryData.images.push(imageData);
          } catch (fileError) {
            console.warn(`?? Could not process file ${filename}:`, fileError.message);
          }
        }
      } catch (dirError) {
        console.warn(`?? Could not scan directory ${categoryPath}:`, dirError.message);
      }
    }

    console.log(`? Scanned uploads directory: ${galleryData.images.length} images found`);
    return galleryData;
  } catch (error) {
    console.error('? Failed to scan uploads directory:', error);
    return {
      version: "1.0",
      lastUpdated: new Date().toISOString(),
      basePath: "uploads/gallery/",
      images: [],
      categories: ["All", ...config.categories],
      settings: {
        autoDetectImages: true,
        supportedFormats: config.allowedFormats,
        lazyLoading: true,
        preloadImages: false
      }
    };
  }
}

/**
 * Read image file and convert to base64 with format information
 */
async function readImageAsBase64(filePath, filename) {
  try {
    // Check if file exists
    const fileExists = await fs.pathExists(filePath);
    if (!fileExists) {
      console.warn(`?? Image file not found: ${filePath}`);
      return {
        content: null,
        format: 'unknown',
        mimeType: 'application/octet-stream',
        error: 'File not found'
      };
    }

    // Read file as buffer
    const imageBuffer = await fs.readFile(filePath);
    
    // Get file extension and determine format
    const ext = path.extname(filename).toLowerCase().replace('.', '');
    const format = ext || 'jpg';
    
    // Determine MIME type
    const mimeTypeMap = {
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg', 
      'png': 'image/png',
      'webp': 'image/webp',
      'gif': 'image/gif',
      'svg': 'image/svg+xml'
    };
    
    const mimeType = mimeTypeMap[format] || 'image/jpeg';
    
    // Convert to base64
    const base64Content = imageBuffer.toString('base64');
    
    // Create data URL
    const dataUrl = `data:${mimeType};base64,${base64Content}`;
    
    console.log(`? Read image ${filename} (${format.toUpperCase()}, ${(imageBuffer.length / 1024).toFixed(1)}KB)`);
    
    return {
      content: base64Content,
      dataUrl: dataUrl,
      format: format.toUpperCase(),
      mimeType: mimeType,
      size: imageBuffer.length,
      error: null
    };
    
  } catch (error) {
    console.error(`? Failed to read image ${filename}:`, error.message);
    return {
      content: null,
      dataUrl: null,
      format: 'unknown',
      mimeType: 'application/octet-stream',
      size: 0,
      error: error.message
    };
  }
}

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ 
        error: 'File too large', 
        message: `Maximum file size is ${config.maxFileSize / (1024 * 1024)}MB` 
      });
    }
    if (error.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({ 
        error: 'Too many files', 
        message: 'Maximum 5 files per upload' 
      });
    }
  }
  
  res.status(500).json({ 
    error: 'Internal server error',
    message: error.message 
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ 
    error: 'Endpoint not found',
    message: `Cannot ${req.method} ${req.originalUrl}` 
  });
});

// Initialize and start server
async function startServer() {
  try {
    await initializeDirectories();
    
    app.listen(PORT, () => {
      console.log(`
?? Gallery Server started successfully!
?? Server running on: http://localhost:${PORT}
?? Upload path: ${config.uploadPath}
?? Supported formats: ${config.allowedFormats.join(', ')}
?? Categories: ${config.categories.join(', ')}
? Started at: ${new Date().toLocaleString()}
      `);
    });
  } catch (error) {
    console.error('? Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('?? SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('?? SIGINT received, shutting down gracefully...');
  process.exit(0);
});

startServer();

/**
 * GET /api/gallery/image/:filename/content - Get specific image content
 */
app.get('/api/gallery/image/:filename/content', async (req, res) => {
  try {
    const { filename } = req.params;
    console.log(`??? GET /api/gallery/image/${filename}/content - Reading image content...`);
    
    // Find the image in uploads directory
    const galleryData = await scanUploadsDirectory();
    const imageData = galleryData.images.find(img => img.filename === filename);
    
    if (!imageData) {
      return res.status(404).json({ 
        success: false,
        error: 'Image not found in uploads',
        filename: filename
      });
    }
    
    // Read image content
    const filePath = path.join(config.uploadPath, imageData.category.toLowerCase(), filename);
    const imageContent = await readImageAsBase64(filePath, filename);
    
    // Read thumbnail content
    const thumbnailPath = path.join(config.uploadPath, 'thumbnails', filename);
    const thumbnailContent = await readImageAsBase64(thumbnailPath, filename);
    
    res.json({
      success: true,
      filename: filename,
      category: imageData.category,
      alt: imageData.alt,
      description: imageData.description,
      
      // Main image content
      imageContent: {
        data: imageContent.content,
        dataUrl: imageContent.dataUrl,
        format: imageContent.format,
        mimeType: imageContent.mimeType,
        contentSize: imageContent.size,
        error: imageContent.error
      },
      
      // Thumbnail content
      thumbnailContent: {
        data: thumbnailContent.content,
        dataUrl: thumbnailContent.dataUrl,
        format: thumbnailContent.format,
        mimeType: thumbnailContent.mimeType,
        contentSize: thumbnailContent.size,
        error: thumbnailContent.error
      },
      
      timestamp: new Date().toISOString()
    });
    
    console.log(`? Served content for ${filename} (${imageContent.format}, ${(imageContent.size / 1024).toFixed(1)}KB)`);
    
  } catch (error) {
    console.error('? Error fetching image content:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch image content',
      message: error.message 
    });
  }
});