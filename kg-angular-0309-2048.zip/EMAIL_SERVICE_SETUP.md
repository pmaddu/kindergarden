# Email Service Integration - Setup Guide

This project includes a comprehensive email service system with multiple sending methods and user-friendly notifications.

## ?? Features

- **Multiple Email Services**: Formspree and EmailJS
- **Modern EmailJS Integration**: Uses `@emailjs/browser` library with CORS handling
- **CORS Solutions**: Multiple approaches to handle development CORS issues
- **User Notifications**: Toast-style notifications with success/error feedback
- **Form Validation**: Comprehensive client-side validation with error messages
- **Mobile Responsive**: Optimized for all device sizes
- **Accessibility**: WCAG compliant with keyboard navigation and screen reader support

## ?? Installation

Before using the email services, install the required EmailJS package:

```bash
npm install @emailjs/browser
```

## ?? CORS Issue Solutions

### **Common CORS Error:**
```
Access to fetch at 'https://api.emailjs.com/api/v1.0/email/send' from origin 'http://localhost:4200' has been blocked by CORS policy
```

### **Solution 1: Use Angular Proxy (Recommended for Development)**

1. **Start development server with proxy:**
```bash
npm run start
# or
ng serve --proxy-config proxy.conf.json
```

2. **Proxy configuration is already set up in `proxy.conf.json`**

### **Solution 2: Production Deployment**
CORS issues typically don't occur in production. Deploy your app to:
- Netlify
- Vercel
- Firebase Hosting
- GitHub Pages
- Your own server

### **Solution 3: EmailJS Dashboard Configuration**
1. Go to your EmailJS dashboard
2. Navigate to "Integration" settings
3. Add your domain to the allowed origins:
   - `http://localhost:4200` (for development)
   - Your production domain
4. Save the settings

### **Solution 4: Use Formspree as Fallback**
If EmailJS continues to have CORS issues, enable Formspree:
```typescript
formspree: {
  enabled: true,
  formId: 'your-formspree-form-id',
  endpoint: 'https://formspree.io/f/your-formspree-form-id'
}
```

## ?? Email Service Configuration

### Method 1: EmailJS (Recommended - with CORS handling)

1. Go to [EmailJS.com](https://www.emailjs.com) and create an account
2. Create an email service (Gmail, Outlook, etc.)
3. Create an email template with these variables:
   - `{{from_name}}`
   - `{{from_email}}`
   - `{{subject}}`
   - `{{message}}`
   - `{{to_email}}`
4. **Configure CORS settings:**
   - Add `http://localhost:4200` to allowed origins
   - Add your production domain
5. Get your Service ID, Template ID, and Public Key
6. Update `src/app/services/email-config.service.ts`:
   ```typescript
   emailjs: {
     enabled: true,
     serviceId: 'your_service_id',
     templateId: 'your_template_id', 
     publicKey: 'your_public_key'
   }
   ```

### Method 2: Formspree (Alternative - No CORS issues)

1. Go to [Formspree.io](https://formspree.io) and create a free account
2. Create a new form and get your Form ID
3. Update `src/app/services/email-config.service.ts`:
   ```typescript
   formspree: {
     enabled: true,
     formId: 'your-actual-form-id',
     endpoint: 'https://formspree.io/f/your-actual-form-id'
   }
   ```

## ? Development Commands

```bash
# Install dependencies
npm install

# Start with proxy (solves CORS)
npm run start
# or
ng serve --proxy-config proxy.conf.json

# Start without proxy (may have CORS issues)
ng serve

# Build for production
ng build

# Test build locally
ng build && npx http-server dist/kindergarden
```

## ?? EmailJS Implementation Features

### Enhanced CORS Handling
- Automatic CORS error detection
- Retry logic with alternative methods
- Proxy support for development
- Helpful error messages with solutions

### Modern Library Integration
- Uses `@emailjs/browser` npm package
- Proper TypeScript support with typed responses
- Better error handling and status codes
- Rate limiting support

### Security Features
- Input sanitization to prevent XSS attacks
- Spam detection and filtering
- Rate limiting to prevent abuse
- Secure template parameter handling

## ?? Notification System

The application includes a comprehensive notification system:

- **Success**: Green notifications for successful operations
- **Error**: Red notifications with specific CORS solutions
- **Warning**: Orange notifications for warnings
- **Info**: Blue notifications for information

## ?? Mobile Features

- **Touch-friendly**: Large touch targets for mobile devices
- **Responsive**: Adapts to all screen sizes
- **Performance**: Optimized for mobile performance

## ?? Customization

### Email Configuration
Edit `src/app/services/email-config.service.ts` to modify:
- Email service settings
- Recipient email address
- Service priorities

### Proxy Configuration
Edit `proxy.conf.json` to modify:
- Proxy routes
- CORS headers
- Target URLs

## ? Current Status

- ? Email service architecture created
- ? Modern EmailJS integration with `@emailjs/browser`
- ? **CORS handling implemented**
- ? **Proxy configuration ready**
- ? **Enhanced error messages**
- ? Notification system implemented
- ? Contact form integration completed
- ?? Formspree/EmailJS: Requires your configuration
- ? Form validation and user feedback
- ? Mobile responsiveness
- ? Accessibility features
- ? TypeScript support with proper types

## ?? Troubleshooting CORS Issues

### Issue: "CORS policy blocked the request"

**Immediate Solutions:**
1. **Use proxy (Development):**
   ```bash
   ng serve --proxy-config proxy.conf.json
   ```

2. **Check EmailJS dashboard:**
   - Verify domain is whitelisted
   - Add `http://localhost:4200` to allowed origins

3. **Test in production:**
   - Deploy to any hosting service
   - CORS issues typically resolve automatically

4. **Switch to Formspree:**
   - No CORS issues
   - Works immediately

### Issue: "Failed to fetch"

**Solutions:**
1. Check internet connection
2. Verify EmailJS service is running
3. Try alternative email service (Formspree)
4. Check browser developer tools for specific errors

### Issue: "EmailJS service unavailable"

**Solutions:**
1. Check EmailJS status page
2. Verify configuration (service ID, template ID, public key)
3. Try again in a few minutes
4. Use Formspree as backup

## ?? Testing CORS Solutions

### Test EmailJS Configuration:
```typescript
// In your component or service
async testConfiguration() {
  try {
    const isConfigured = await this.emailService.testEmailJSConfig();
    console.log('EmailJS configured:', isConfigured);
    
    // Send a test email
    const testResult = await this.emailService.sendTestEmail();
    console.log('Test email result:', testResult);
  } catch (error) {
    console.error('Configuration test failed:', error);
    // Check error type
    if (error.errorType === 'cors') {
      console.log('CORS issue detected - use proxy or deploy to production');
    }
  }
}
```

### Test Proxy Configuration:
1. Start server with proxy: `ng serve --proxy-config proxy.conf.json`
2. Open browser developer tools
3. Try sending an email
4. Check Network tab for requests to `/api/emailjs/`

## ?? Production Deployment Tips

1. **Build for production:**
   ```bash
   ng build --configuration production
   ```

2. **Deploy to hosting service:**
   - CORS issues automatically resolve
   - No proxy configuration needed
   - EmailJS works directly

3. **Update EmailJS domain whitelist:**
   - Add your production domain
   - Remove localhost if not needed

---

**Need help with CORS issues?** 
1. Try the proxy solution first
2. Check EmailJS dashboard settings
3. Test in production environment
4. Use Formspree as alternative