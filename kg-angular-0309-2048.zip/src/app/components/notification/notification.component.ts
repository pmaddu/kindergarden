import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { NotificationService, NotificationData, NotificationAction } from '../../services/notification.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit, OnDestroy {
  
  notification: NotificationData | null = null;
  private subscription: Subscription = new Subscription();

  constructor(private notificationService: NotificationService) { }

  ngOnInit(): void {
    this.subscription = this.notificationService.getNotification()
      .subscribe(notification => {
        this.notification = notification;
      });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  closeNotification(): void {
    this.notificationService.hideNotification();
  }

  executeAction(action: NotificationAction): void {
    action.action();
  }

  getIconClass(): string {
    switch (this.notification?.type) {
      case 'success':
        return 'fas fa-check-circle';
      case 'error':
        return 'fas fa-exclamation-circle';
      case 'warning':
        return 'fas fa-exclamation-triangle';
      case 'confirm':
        return 'fas fa-question-circle';
      case 'info':
      default:
        return 'fas fa-info-circle';
    }
  }

  getNotificationClass(): string {
    const baseClass = 'alert alert-dismissible fade show';
    switch (this.notification?.type) {
      case 'success':
        return `${baseClass} alert-success`;
      case 'error':
        return `${baseClass} alert-danger`;
      case 'warning':
        return `${baseClass} alert-warning`;
      case 'confirm':
        return `${baseClass} alert-primary`;
      case 'info':
      default:
        return `${baseClass} alert-info`;
    }
  }

  getActionButtonClass(action: NotificationAction): string {
    const baseClass = 'btn btn-sm ms-2';
    switch (action.type) {
      case 'primary':
        return `${baseClass} btn-primary`;
      case 'danger':
        return `${baseClass} btn-danger`;
      case 'secondary':
      default:
        return `${baseClass} btn-secondary`;
    }
  }

  hasActions(): boolean {
    return !!(this.notification?.actions && this.notification.actions.length > 0);
  }

  isConfirmationType(): boolean {
    return this.notification?.type === 'confirm';
  }
}