import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { EmailConfigService } from './email-config.service';
import emailjs, { type EmailJSResponseStatus } from '@emailjs/browser';

export interface EmailData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface EmailResponse {
  success: boolean;
  message: string;
  timestamp?: Date;
  method?: 'emailjs' | 'formspree';
  errorType?: 'cors' | 'network' | 'config' | 'rate-limit' | 'unknown';
}

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  private readonly RECIPIENT_EMAIL = 'pradeep.maddu496@gmail.com';
  private emailjsInitialized = false;
  private retryCount = 0;
  private readonly MAX_RETRIES = 3;

  constructor(
    private http: HttpClient,
    private configService: EmailConfigService
  ) { }

  /**
   * Send email using HTTP service (Formspree)
   * @param emailData - The email data to send
   * @returns Observable with email response
   */
  sendEmail(emailData: EmailData): Observable<EmailResponse> {
    const config = this.configService.getConfig();
    
    if (!config.formspree?.enabled || !config.formspree.endpoint) {
      return throwError(() => ({
        success: false,
        message: 'Formspree service is not configured.',
        timestamp: new Date(),
        method: 'formspree',
        errorType: 'config'
      } as EmailResponse));
    }

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });

    const payload = {
      name: emailData.name,
      email: emailData.email,
      subject: emailData.subject,
      message: emailData.message,
      _replyto: emailData.email,
      _subject: `New message from ${emailData.name} - ${emailData.subject}`
    };

    return this.http.post<any>(config.formspree.endpoint, payload, { headers })
      .pipe(
        map(response => ({
          success: true,
          message: 'Email sent successfully! We will get back to you soon.',
          timestamp: new Date(),
          method: 'formspree'
        } as EmailResponse)),
        catchError(error => {
          console.error('Formspree service error:', error);
          
          let errorType: EmailResponse['errorType'] = 'unknown';
          let errorMessage = 'Failed to send email via Formspree.';

          if (error.status === 0) {
            errorType = 'network';
            errorMessage = 'Network error. Please check your internet connection.';
          } else if (error.status === 429) {
            errorType = 'rate-limit';
            errorMessage = 'Too many requests. Please wait a moment before trying again.';
          }

          return throwError(() => ({
            success: false,
            message: errorMessage,
            timestamp: new Date(),
            method: 'formspree',
            errorType
          } as EmailResponse));
        })
      );
  }

  /**
   * Send email using EmailJS service with enhanced CORS handling
   * @param emailData - The email data to send
   * @returns Observable with email response
   */
  sendEmailViaEmailJS(emailData: EmailData): Observable<EmailResponse> {
    const config = this.configService.getConfig();
    
    if (!config.emailjs?.enabled) {
      return throwError(() => ({
        success: false,
        message: 'EmailJS service is not configured.',
        timestamp: new Date(),
        method: 'emailjs',
        errorType: 'config'
      } as EmailResponse));
    }

    return new Observable(observer => {
      this.initializeEmailJS(config.emailjs!)
        .then(() => {
          this.sendWithEmailJSEnhanced(config.emailjs!, emailData, observer);
        })
        .catch(error => {
          console.error('Failed to initialize EmailJS:', error);
          observer.error({
            success: false,
            message: 'Failed to initialize EmailJS service. Please check your configuration.',
            timestamp: new Date(),
            method: 'emailjs',
            errorType: 'config'
          } as EmailResponse);
        });
    });
  }

  /**
   * Initialize EmailJS with enhanced configuration for CORS handling
   * @param config - EmailJS configuration
   * @returns Promise<void>
   */
  private async initializeEmailJS(config: any): Promise<void> {
    try {
      if (!this.emailjsInitialized) {
        // Enhanced initialization with CORS handling
        emailjs.init({
          publicKey: config.publicKey,
          // Rate limiting to prevent spam
          limitRate: {
            id: 'app',
            throttle: 10000, // 10 seconds between requests
          },
          // Additional options for better CORS handling
          blockHeadless: true,
          blockList: {
            list: ['foo@emailjs.com', 'bar@emailjs.com'],
            watchVariable: 'userEmail',
          },
        });
        this.emailjsInitialized = true;
        console.log('EmailJS initialized successfully with enhanced CORS handling');
      }
    } catch (error) {
      console.error('EmailJS initialization error:', error);
      throw new Error('Failed to initialize EmailJS');
    }
  }

  /**
   * Enhanced EmailJS sending with CORS retry logic
   * @param config - EmailJS configuration
   * @param emailData - Email data
   * @param observer - Observable observer
   */
    private async sendWithEmailJSEnhanced(config: any, emailData: EmailData, observer: any): Promise<void> {
        const templateParams = {
            from_name: emailData.name,
            from_email: emailData.email,
            subject: emailData.subject,
            message: emailData.message,
            to_email: this.RECIPIENT_EMAIL,
            reply_to: emailData.email,
            timestamp: new Date().toLocaleString(),
            user_agent: navigator.userAgent.substring(0, 100)
        };
    try {
      

      console.log('Sending email with EmailJS (attempt ' + (this.retryCount + 1) + ')...', {
        serviceId: config.serviceId,
        templateId: config.templateId,
        retryCount: this.retryCount
      });

      // Method 1: Try using EmailJS SDK (preferred)
      await this.sendViaEmailJSSDK(config, templateParams, observer);

    } catch (error: any) {
      console.warn('EmailJS SDK failed, checking for CORS issue:', error);
      
      // Check if it's a CORS error
      if (this.isCORSError(error)) {
        console.log('CORS error detected, trying alternative method...');
        
        // Method 2: Try using direct HTTP call with proxy (if available)
        if (this.retryCount < this.MAX_RETRIES) {
          this.retryCount++;
          await this.sendViaHTTPProxy(config, templateParams, observer);
        } else {
          // Method 3: Provide helpful error message with solutions
          observer.error(this.createCORSErrorResponse(emailData));
        }
      } else {
        const errorResponse = this.handleEmailJSError(error);
        observer.error(errorResponse);
      }
    }
  }

  /**
   * Send via EmailJS SDK
   */
  private async sendViaEmailJSSDK(config: any, templateParams: any, observer: any): Promise<void> {
    try {
      const response: EmailJSResponseStatus = await emailjs.send(
        config.serviceId,
        config.templateId,
        templateParams
      );

      console.log('EmailJS SDK Success:', response);
      this.retryCount = 0; // Reset retry count on success
      
      observer.next({
        success: true,
        message: `Thank you ${templateParams.from_name}! Your message has been sent successfully. We'll get back to you soon.`,
        timestamp: new Date(),
        method: 'emailjs'
      } as EmailResponse);
      observer.complete();
    } catch (error) {
      throw error; // Re-throw to be handled by parent
    }
  }

  /**
   * Alternative method using HTTP proxy for CORS bypass
   */
  private async sendViaHTTPProxy(config: any, templateParams: any, observer: any): Promise<void> {
    try {
      const payload = {
        service_id: config.serviceId,
        template_id: config.templateId,
        user_id: config.publicKey,
        template_params: templateParams
      };

      // Use proxy endpoint if available
      const proxyEndpoint = '/api/emailjs/email/send';
      const directEndpoint = 'https://api.emailjs.com/api/v1.0/email/send';
      
      const endpoint = this.isProxyAvailable() ? proxyEndpoint : directEndpoint;

      console.log('Trying HTTP method with endpoint:', endpoint);

      const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'allow'
      });

      const response = await this.http.post(endpoint, payload, { headers }).toPromise();

      console.log('EmailJS HTTP Success:', response);
      this.retryCount = 0; // Reset retry count on success
      
      observer.next({
        success: true,
        message: `Thank you ${templateParams.from_name}! Your message has been sent successfully via HTTP method.`,
        timestamp: new Date(),
        method: 'emailjs'
      } as EmailResponse);
      observer.complete();

    } catch (error: any) {
      console.error('HTTP method also failed:', error);
      
      if (this.isCORSError(error)) {
        observer.error(this.createCORSErrorResponse({ name: templateParams.from_name }));
      } else {
        observer.error(this.handleEmailJSError(error));
      }
    }
  }

  /**
   * Check if error is CORS related
   */
  private isCORSError(error: any): boolean {
    return (
      error.status === 0 ||
      error.name === 'TypeError' ||
      error.message?.includes('Failed to fetch') ||
      error.message?.includes('CORS') ||
      error.message?.includes('cors') ||
      (error.status === undefined && error.message?.includes('network'))
    );
  }

  /**
   * Check if proxy is available
   */
  private isProxyAvailable(): boolean {
    // Check if we're in development mode and proxy is configured
    return window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
  }

  /**
   * Create CORS specific error response with solutions
   */
  private createCORSErrorResponse(emailData: any): EmailResponse {
    return {
      success: false,
      message: `CORS Error: Unable to send email directly due to browser security restrictions. 
      
Solutions:
1. Use development server with proxy: 'ng serve --proxy-config proxy.conf.json'
2. Deploy to production (CORS issues don't occur in production)
3. Configure your EmailJS service with proper CORS headers
4. Use alternative email service (Formspree)

Contact us directly at: ${this.RECIPIENT_EMAIL}`,
      timestamp: new Date(),
      method: 'emailjs',
      errorType: 'cors'
    };
  }

  /**
   * Handle specific EmailJS errors with enhanced CORS detection
   */
  private handleEmailJSError(error: any): EmailResponse {
    let errorMessage = 'Failed to send email via EmailJS.';
    let errorType: EmailResponse['errorType'] = 'unknown';

    // Enhanced CORS detection
    if (this.isCORSError(error)) {
      errorType = 'cors';
      errorMessage = `CORS Error: Browser blocked the request to EmailJS API. 
      
This is common in development. Solutions:
1. Use proxy: 'ng serve --proxy-config proxy.conf.json'
2. Deploy to production where CORS is handled properly
3. Check EmailJS dashboard for CORS settings
4. Verify your domain is whitelisted in EmailJS`;
    } else if (error.status !== undefined) {
      switch (error.status) {
        case 400:
          errorType = 'config';
          errorMessage = 'Invalid email configuration. Please verify your EmailJS service ID, template ID, and public key.';
          break;
        case 401:
        case 403:
          errorType = 'config';
          errorMessage = 'EmailJS service access denied. Please verify your credentials and service permissions.';
          break;
        case 429:
          errorType = 'rate-limit';
          errorMessage = 'Too many emails sent. Please wait a moment before trying again.';
          break;
        case 500:
        case 502:
        case 503:
          errorType = 'network';
          errorMessage = 'EmailJS service is temporarily unavailable. Please try again later.';
          break;
        default:
          errorType = 'unknown';
          errorMessage = `EmailJS error (${error.status}): ${error.text || 'Unknown error'}`;
      }
    }

    return {
      success: false,
      message: errorMessage,
      timestamp: new Date(),
      method: 'emailjs',
      errorType
    };
  }

  /**
   * Check if EmailJS is accessible and properly configured
   * @returns Promise<boolean>
   */
  async checkEmailJSAccessibility(): Promise<boolean> {
    try {
      const config = this.configService.getConfig();
      
      if (!config.emailjs?.enabled || !config.emailjs.publicKey || !config.emailjs.serviceId || !config.emailjs.templateId) {
        console.warn('EmailJS configuration is incomplete');
        return false;
      }

      await this.initializeEmailJS(config.emailjs);
      return true;
    } catch (error) {
      console.warn('EmailJS accessibility check failed:', error);
      return false;
    }
  }

  /**
   * Get available email methods
   * @returns Array of available methods
   */
  getAvailableMethods(): string[] {
    const config = this.configService.getConfig();
    const methods: string[] = [];

    if (config.emailjs?.enabled) methods.push('emailjs');
    if (config.formspree?.enabled) methods.push('formspree');

    return methods;
  }

  /**
   * Get primary email method
   * @returns string - Primary method name
   */
  getPrimaryMethod(): string {
    return this.configService.getPrimaryMethod();
  }

  /**
   * Test EmailJS configuration with CORS detection
   * @returns Promise<boolean>
   */
  async testEmailJSConfig(): Promise<boolean> {
    try {
      const config = this.configService.getConfig();
      if (!config.emailjs?.enabled) {
        return false;
      }

      const isAccessible = await this.checkEmailJSAccessibility();
      return isAccessible;
    } catch (error) {
      console.error('EmailJS config test failed:', error);
      return false;
    }
  }

  /**
   * Send a test email to verify configuration
   * @returns Promise<EmailResponse>
   */
  async sendTestEmail(): Promise<EmailResponse> {
    const testEmailData: EmailData = {
      name: 'Test User',
      email: 'test@example.com',
      subject: 'EmailJS Configuration Test',
      message: 'This is a test email to verify EmailJS configuration is working properly.'
    };

    return new Promise((resolve, reject) => {
      this.sendEmailViaEmailJS(testEmailData).subscribe({
        next: (response) => resolve(response),
        error: (error) => reject(error)
      });
    });
  }

  /**
   * Validate email format
   * @param email - Email to validate
   * @returns boolean
   */
  validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Sanitize input data
   * @param data - Data to sanitize
   * @returns Sanitized data
   */
  sanitizeEmailData(data: EmailData): EmailData {
    return {
      name: this.sanitizeString(data.name),
      email: this.sanitizeString(data.email).toLowerCase(),
      subject: this.sanitizeString(data.subject),
      message: this.sanitizeString(data.message)
    };
  }

  /**
   * Basic string sanitization
   * @param str - String to sanitize
   * @returns Sanitized string
   */
  private sanitizeString(str: string): string {
    return str.trim()
              .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
              .replace(/[<>]/g, '') // Remove < and > characters
              .substring(0, 1000); // Limit length
  }

  /**
   * Reset retry counter (useful for testing)
   */
  resetRetryCount(): void {
    this.retryCount = 0;
  }

  /**
   * Get connection status information
   * @returns Object with connection details
   */
  getConnectionStatus(): { online: boolean; emailjsInitialized: boolean; retryCount: number } {
    return {
      online: navigator.onLine,
      emailjsInitialized: this.emailjsInitialized,
      retryCount: this.retryCount
    };
  }

  /**
   * Reset EmailJS initialization (useful for testing different configurations)
   */
  resetEmailJSInitialization(): void {
    this.emailjsInitialized = false;
  }
}