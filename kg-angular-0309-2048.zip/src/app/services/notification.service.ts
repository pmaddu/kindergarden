import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface NotificationData {
  message: string;
  type: 'success' | 'error' | 'warning' | 'info' | 'confirm';
  duration?: number;
  timestamp?: Date;
  actions?: NotificationAction[];
}

export interface NotificationAction {
  label: string;
  action: () => void;
  type?: 'primary' | 'secondary' | 'danger';
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private notificationSubject = new BehaviorSubject<NotificationData | null>(null);
  private timeoutId: any;

  constructor() { }

  /**
   * Get notification observable
   * @returns Observable of notification data
   */
  getNotification(): Observable<NotificationData | null> {
    return this.notificationSubject.asObservable();
  }

  /**
   * Show success notification
   * @param message - Success message
   * @param duration - Duration in milliseconds (default: 5000)
   */
  showSuccess(message: string, duration: number = 5000): void {
    this.showNotification({
      message,
      type: 'success',
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show error notification
   * @param message - Error message
   * @param duration - Duration in milliseconds (default: 7000)
   */
  showError(message: string, duration: number = 7000): void {
    this.showNotification({
      message,
      type: 'error',
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show warning notification
   * @param message - Warning message
   * @param duration - Duration in milliseconds (default: 6000)
   */
  showWarning(message: string, duration: number = 6000): void {
    this.showNotification({
      message,
      type: 'warning',
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show info notification
   * @param message - Info message
   * @param duration - Duration in milliseconds (default: 4000)
   */
  showInfo(message: string, duration: number = 4000): void {
    this.showNotification({
      message,
      type: 'info',
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show confirmation dialog
   * @param message - Confirmation message
   * @param confirmAction - Action to execute on confirmation
   * @param cancelAction - Action to execute on cancellation (optional)
   * @param confirmText - Text for confirm button (default: 'Confirm')
   * @param cancelText - Text for cancel button (default: 'Cancel')
   */
  showConfirmation(
    message: string, 
    confirmAction: () => void, 
    cancelAction?: () => void,
    confirmText: string = 'Confirm',
    cancelText: string = 'Cancel'
  ): void {
    const actions: NotificationAction[] = [
      {
        label: cancelText,
        action: () => {
          this.hideNotification();
          if (cancelAction) {
            cancelAction();
          }
        },
        type: 'secondary'
      },
      {
        label: confirmText,
        action: () => {
          this.hideNotification();
          confirmAction();
        },
        type: 'danger'
      }
    ];

    this.showNotification({
      message,
      type: 'confirm',
      actions,
      timestamp: new Date()
    });
  }

  /**
   * Show upload progress notification
   * @param message - Progress message
   * @param progress - Progress percentage (0-100)
   */
  showProgress(message: string, progress: number): void {
    this.showNotification({
      message: `${message} (${progress}%)`,
      type: 'info',
      timestamp: new Date()
    });
  }

  /**
   * Show notification with custom actions
   * @param message - Notification message
   * @param type - Notification type
   * @param actions - Custom actions
   * @param duration - Duration in milliseconds (optional for custom actions)
   */
  showWithActions(
    message: string, 
    type: 'success' | 'error' | 'warning' | 'info',
    actions: NotificationAction[],
    duration?: number
  ): void {
    this.showNotification({
      message,
      type,
      actions,
      duration,
      timestamp: new Date()
    });
  }

  /**
   * Show notification
   * @param notification - Notification data
   */
  private showNotification(notification: NotificationData): void {
    // Clear any existing timeout
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }

    // Emit the notification
    this.notificationSubject.next(notification);

    // Auto-hide after specified duration (only if no actions and duration is set)
    if (notification.duration && notification.duration > 0 && !notification.actions) {
      this.timeoutId = setTimeout(() => {
        this.hideNotification();
      }, notification.duration);
    }
  }

  /**
   * Hide current notification
   */
  hideNotification(): void {
    this.notificationSubject.next(null);
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }

  /**
   * Clear all notifications
   */
  clear(): void {
    this.hideNotification();
  }

  /**
   * Utility method to replace window.alert()
   * @param message - Alert message
   */
  alert(message: string): void {
    this.showInfo(message, 0); // No auto-hide for alerts
  }

  /**
   * Utility method to replace window.confirm()
   * @param message - Confirmation message
   * @returns Promise that resolves to boolean
   */
  confirm(message: string): Promise<boolean> {
    return new Promise((resolve) => {
      this.showConfirmation(
        message,
        () => resolve(true),  // Confirm action
        () => resolve(false)  // Cancel action
      );
    });
  }
}