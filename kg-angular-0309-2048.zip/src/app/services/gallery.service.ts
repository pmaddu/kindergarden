﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { Observable, BehaviorSubject, of, forkJoin, interval, switchMap, startWith } from 'rxjs';
import { map, catchError, tap, filter, timeout } from 'rxjs/operators';

// Gallery item interface
export interface GalleryItem {
  id: number;
  image: string;
  category: string;
  alt: string;
  filename: string;
  dateAdded?: Date;
  size?: { width: number; height: number };
  isLoaded?: boolean;
  thumbnailPath?: string;
  description?: string;
  originalName?: string;
  uploadDate?: string;
}

// Upload response interface
export interface UploadResponse {
  success: boolean;
  message: string;
  uploadedImages: any[];
  category: string;
  timestamp: string;
}

// Gallery configuration interface
export interface GalleryConfig {
  basePath: string;
  supportedFormats: string[];
  categories: string[];
  defaultCategory: string;
  autoDetectCategories: boolean;
  lazyLoading: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class GalleryService {
  
  private readonly API_BASE_URL = 'http://localhost:3001/api';
  private readonly DEFAULT_CONFIG: GalleryConfig = {
    basePath: 'assets/img/',
    supportedFormats: ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'],
    categories: ['All', 'Playing', 'Drawing', 'Reading', 'Learning', 'Activities'],
    defaultCategory: 'All',
    autoDetectCategories: true,
    lazyLoading: true
  };

  private galleryItemsSubject = new BehaviorSubject<GalleryItem[]>([]);
  private categoriesSubject = new BehaviorSubject<string[]>(['All']);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  private errorSubject = new BehaviorSubject<string | null>(null);
    private uploadProgressSubject = new BehaviorSubject<number>(0);
    //private serviceAvailableSubject = new BehaviorSubject<boolean>(false);

  // Public observables
  public galleryItems$ = this.galleryItemsSubject.asObservable();
  public categories$ = this.categoriesSubject.asObservable();
  public loading$ = this.loadingSubject.asObservable();
  public error$ = this.errorSubject.asObservable();
    public uploadProgress$ = this.uploadProgressSubject.asObservable();
    //public serviceAvailable$ = this.serviceAvailableSubject.asObservable();


  private config: GalleryConfig = { ...this.DEFAULT_CONFIG };
  private imageCache = new Map<string, HTMLImageElement>();

  constructor(private http: HttpClient) {
    this.initializeDefaultImages();
  }

  /**
   * Initialize with default static images as fallback
   */
  private initializeDefaultImages(): void {
    const defaultImages: GalleryItem[] = [
      { id: 1, image: 'assets/img/portfolio-1.jpg', category: 'Playing', alt: 'Kids Playing', filename: 'portfolio-1.jpg', isLoaded: false },
      { id: 2, image: 'assets/img/portfolio-2.jpg', category: 'Drawing', alt: 'Art Class', filename: 'portfolio-2.jpg', isLoaded: false },
      { id: 3, image: 'assets/img/portfolio-3.jpg', category: 'Reading', alt: 'Story Time', filename: 'portfolio-3.jpg', isLoaded: false },
      { id: 4, image: 'assets/img/portfolio-4.jpg', category: 'Playing', alt: 'Outdoor Activities', filename: 'portfolio-4.jpg', isLoaded: false },
      { id: 5, image: 'assets/img/portfolio-5.jpg', category: 'Drawing', alt: 'Creative Art', filename: 'portfolio-5.jpg', isLoaded: false },
      { id: 6, image: 'assets/img/portfolio-6.jpg', category: 'Reading', alt: 'Learning Together', filename: 'portfolio-6.jpg', isLoaded: false },
      { id: 7, image: 'assets/img/header.png', category: 'Learning', alt: 'School Header', filename: 'header.png', isLoaded: false },
      { id: 8, image: 'assets/img/about-2.jpg', category: 'Activities', alt: 'About School', filename: 'about-2.jpg', isLoaded: false }
    ];

    // Only add default images if no images are currently loaded
    if (this.galleryItemsSubject.value.length === 0) {
      this.galleryItemsSubject.next(defaultImages);
        this.updateCategories(defaultImages);
    }
  }

  /**
   * Load images from server API based on server availability
   */
  loadDynamicImages(includeContent: boolean = false): Observable<GalleryItem[]> {
    this.loadingSubject.next(true);
    this.errorSubject.next(null);

    const contentParam = includeContent ? '?includeContent=true' : '';

    return this.http.get<any>(`${this.API_BASE_URL}/gallery${contentParam}`).pipe(
      map(response => {
        if (!response.success) {
          throw new Error(response.error || 'Failed to load gallery');
        }
        
        if (response.data.categories) {
          this.categoriesSubject.next(response.data.categories);
        }
        
        return response.data.images.map((imageData: any, index: number) => {
          const galleryItem: GalleryItem = {
            id: index + 1,
            image: '',
            category: imageData.category,
            alt: imageData.alt,
            filename: imageData.filename,
            dateAdded: new Date(imageData.uploadDate || Date.now()),
            isLoaded: false,
            thumbnailPath: imageData.thumbnailPath,
            description: imageData.description,
            originalName: imageData.originalName,
            uploadDate: imageData.uploadDate
          };

          if (response.contentIncluded && imageData.content && imageData.mimeType) {
            galleryItem.image = `data:${imageData.mimeType};base64,${imageData.content}`;
            galleryItem.isLoaded = true;
          } else {
            galleryItem.image = imageData.path;
          }

          return galleryItem;
        });
      }),
      catchError(() => {
        return this.loadFromLocalManifest();
      }),
      tap((items: GalleryItem[]) => {
        this.galleryItemsSubject.next(items);
        
        if (this.config.lazyLoading && !includeContent) {
          items.slice(0, 6).forEach((item: GalleryItem) => this.preloadImage(item));
        }
      }),
      catchError(error => {
        this.errorSubject.next('Failed to load images. Using default gallery.');
        
        const currentImages = this.galleryItemsSubject.value;
        if (currentImages.length === 0) {
          this.initializeDefaultImages();
          return of(this.galleryItemsSubject.value);
        }
        return of(currentImages);
      }),
      tap(() => this.loadingSubject.next(false))
    );
  }

  /**
   * Load from local manifest as fallback
   */
  private loadFromLocalManifest(): Observable<GalleryItem[]> {
    return this.http.get<any>('assets/gallery-manifest.json').pipe(
      map(manifest => {
        if (!manifest || !manifest.images) {
          throw new Error('Invalid manifest format');
        }
        
        if (manifest.categories && Array.isArray(manifest.categories)) {
          this.categoriesSubject.next(manifest.categories);
        }
        
        return manifest.images.map((imageData: any, index: number) => {
          let imagePath = '';
          
          if (imageData.path) {
            imagePath = imageData.path;
          } else {
            const basePath = manifest.basePath || this.config.basePath;
            imagePath = `${basePath}${imageData.filename}`;
          }

          const galleryItem: GalleryItem = {
            id: index + 1,
            image: imagePath,
            category: imageData.category || 'Activities',
            alt: imageData.alt || `Gallery image ${index + 1}`,
            filename: imageData.filename,
            dateAdded: imageData.uploadDate ? new Date(imageData.uploadDate) : new Date(manifest.lastUpdated || Date.now()),
            isLoaded: false,
            description: imageData.description,
            thumbnailPath: imageData.thumbnailPath,
            originalName: imageData.originalName,
            uploadDate: imageData.uploadDate
          };

          return galleryItem;
        });
      }),
      catchError(error => {
        const defaultImages = this.galleryItemsSubject.value;
        if (defaultImages.length === 0) {
          this.initializeDefaultImages();
          return of(this.galleryItemsSubject.value);
        }
        return of(defaultImages);
      })
    );
  }

  /**
   * Upload images to server
   */
  uploadImages(files: FileList, category: string): Observable<UploadResponse> {
    this.uploadProgressSubject.next(0);
    
    const formData = new FormData();
    
    // Add files to FormData
    for (let i = 0; i < files.length; i++) {
      formData.append('images', files[i]);
    }
    
    // Add metadata
    formData.append('category', category);

    return this.http.post<UploadResponse>(`${this.API_BASE_URL}/gallery/upload`, formData, {
      reportProgress: true,
      observe: 'events'
    }).pipe(
      map((event: any) => {
        if (event.type === HttpEventType.Response) {
          this.uploadProgressSubject.next(100);
          return event.body;
        } else if (event.type === HttpEventType.UploadProgress && event.total) {
          const progress = Math.round(100 * event.loaded / event.total);
          this.uploadProgressSubject.next(progress);
        }
        return null;
      }),
      filter((response: UploadResponse | null): response is UploadResponse => response !== null),
      tap((response: UploadResponse) => {
        if (response.success) {
          this.loadDynamicImages().subscribe();
        }
      }),
      catchError(error => {
        this.uploadProgressSubject.next(0);
        throw error;
      })
    );
  }

  /**
   * Delete image from server
   */
  deleteImage(filename: string): Observable<any> {
    return this.http.delete<any>(`${this.API_BASE_URL}/gallery/image/${filename}`).pipe(
      tap(response => {
        if (response.success) {
          this.loadDynamicImages().subscribe();
        }
      },
      catchError(error => {
        throw error;
      })
    ));
  }

  /**
   * Update image metadata on server
   */
  updateImageMetadata(filename: string, updates: Partial<GalleryItem>): Observable<any> {
    return this.http.put<any>(`${this.API_BASE_URL}/gallery/image/${filename}`, updates).pipe(
      tap(response => {
        if (response.success) {
          this.loadDynamicImages().subscribe();
        }
      }),
      catchError(error => {
        throw error;
      })
    );
  }

  /**
   * Refresh gallery from server
   */
  refreshGalleryFromServer(includeContent: boolean = false): Observable<any> {
    return this.http.post<any>(`${this.API_BASE_URL}/gallery/refresh`, {}).pipe(
      tap(response => {
        if (response.success) {
          this.loadDynamicImages(includeContent).subscribe();
        }
      }),
      catchError(error => {
        return this.loadDynamicImages(includeContent);
      })
    );
  }

  /**
   * Refresh gallery (main method)
   */
  refreshGallery(includeContent: boolean = false): Observable<GalleryItem[]> {
    return this.loadDynamicImages(includeContent);
  }

  /**
   * Check if server is available - Enhanced with better error handling and logging
   */
    checkServerStatus(): Observable<boolean> {
      //  interval(5000) // Check every 5 seconds
      //      .pipe(
      //          startWith(0), // Trigger immediate check on subscription
      //          switchMap(() => this.http.get<any>(`${this.API_BASE_URL}/gallery/categories`).pipe(
      //map(response => {
      //  // Check multiple conditions to determine server status
      //  const isSuccess = response &&
      //        (response.success === true);
      //  return isSuccess;
      //}),
      //  catchError((error) => of(false))
      //          )))
      //              .subscribe(isAvailable => {
      //                  this.serviceAvailableSubject.next(isAvailable);
        //              });
        return this.http.get<any>(`${this.API_BASE_URL}/gallery/categories`).pipe(
            map(response => {
                // Check multiple conditions to determine server status
                const isSuccess = response &&
                    (response.success === true);
                return isSuccess;
            }),
            catchError((error) => of(false))
        );
  }

  /**
   * Test server connection with detailed diagnostics
   */
  testServerConnection(): Observable<any> {
    const tests = [
      // Test 1: Basic HTTP connection
      this.http.get(`${this.API_BASE_URL}/gallery/categories`).pipe(
        map(response => ({
          test: 'categories_endpoint',
          success: true,
          response: response,
          message: 'Categories endpoint accessible'
        })),
        catchError(error => of({
          test: 'categories_endpoint',
          success: false,
          error: error,
          message: `Categories endpoint failed: ${error.status || 'Network Error'}`
        }))
      ),
      
      // Test 2: Gallery endpoint
      this.http.get(`${this.API_BASE_URL}/gallery`).pipe(
        map(response => ({
          test: 'gallery_endpoint',
          success: true,
          response: response,
          message: 'Gallery endpoint accessible'
        })),
        catchError(error => of({
          test: 'gallery_endpoint',
          success: false,
          error: error,
          message: `Gallery endpoint failed: ${error.status || 'Network Error'}`
        }))
      )
    ];
    
    return forkJoin(tests);
  }

  /**
   * Load images with content embedded (for offline viewing)
   */
  loadImagesWithContent(): Observable<GalleryItem[]> {
    return this.loadDynamicImages(true);
  }

  /**
   * Load images without content (URL-based, for faster loading)
   */
  loadImagesWithoutContent(): Observable<GalleryItem[]> {
    return this.loadDynamicImages(false);
  }

  /**
   * Force load from local manifest (for debugging and testing)
   */
  forceLoadFromManifest(): Observable<GalleryItem[]> {
    this.loadingSubject.next(true);
    this.errorSubject.next(null);
    
    return this.loadFromLocalManifest().pipe(
      tap(items => {
        this.galleryItemsSubject.next(items);
        this.updateCategories(items);
      }),
      tap(() => this.loadingSubject.next(false)),
      catchError(error => {
        this.loadingSubject.next(false);
        this.errorSubject.next('Failed to load from local manifest');
        
        this.initializeDefaultImages();
        return of(this.galleryItemsSubject.value);
      })
    );
  }

  /**
   * Get individual image content from server
   */
  getImageContent(filename: string): Observable<any> {
    return this.http.get<any>(`${this.API_BASE_URL}/gallery/image/${filename}/content`).pipe(
      map(response => {
        if (!response.success) {
          throw new Error(response.error || 'Failed to get image content');
        }
        
        return {
          filename: response.filename,
          category: response.category,
          alt: response.alt,
          description: response.description,
          imageDataUrl: response.imageContent.dataUrl,
          thumbnailDataUrl: response.thumbnailContent.dataUrl,
          format: response.imageContent.format,
          mimeType: response.imageContent.mimeType,
          contentSize: response.imageContent.contentSize
        };
      }),
      catchError(error => {
        throw error;
      })
    );
  }

  /**
   * Load images based on server availability - smart loading strategy
   */
  loadImagesBasedOnServerStatus(serverAvailable: boolean): Observable<GalleryItem[]> {
    if (serverAvailable) {
      return this.loadDynamicImages(true);
    } else {
      return this.loadFromLocalManifest();
    }
  }

  // Utility methods
  private updateCategories(items: GalleryItem[]): void {
    const categories = new Set(['All']);
    items.forEach(item => {
      if (item.category && item.category !== 'All') {
        categories.add(item.category);
      }
    });
    this.categoriesSubject.next(Array.from(categories));
  }

  private preloadImage(item: GalleryItem): void {
    if (this.imageCache.has(item.image)) {
      return;
    }

    const img = new Image();
    img.onload = () => {
      this.imageCache.set(item.image, img);
      item.isLoaded = true;
      item.size = { width: img.naturalWidth, height: img.naturalHeight };
    };
    img.onerror = () => {
      // Image failed to load silently
    };
    img.src = item.image;
  }

  // Getter methods for backward compatibility
  getCurrentItems(): GalleryItem[] {
    return this.galleryItemsSubject.value;
  }

  getCurrentCategories(): string[] {
    return this.categoriesSubject.value;
  }

  getUploadProgress(): Observable<number> {
    return this.uploadProgress$;
  }

  resetUploadProgress(): void {
    this.uploadProgressSubject.next(0);
  }

  /**
   * Update categories from server response
   */
  updateCategoriesFromServer(serverCategories: string[]): void {
    // Ensure 'All' is always first and no duplicates
    const uniqueCategories = Array.from(new Set(['All', ...serverCategories.filter(cat => cat !== 'All')]));
    this.categoriesSubject.next(uniqueCategories);
  }

  /**
   * Get current categories (for debugging)
   */
  debugCategories(): void {
    console.log('Current categories:', this.categoriesSubject.value);
  }
}