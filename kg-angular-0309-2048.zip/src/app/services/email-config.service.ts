import { Injectable } from '@angular/core';

export interface EmailConfiguration {
  formspree?: {
    enabled: boolean;
    formId: string;
    endpoint?: string;
  };
  emailjs?: {
    enabled: boolean;
    serviceId: string;
    templateId: string;
    publicKey: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class EmailConfigService {

  private config: EmailConfiguration = {
    // Formspree configuration (replace with your actual form ID)
    formspree: {
      enabled: false, // Set to true when you have a Formspree form
      formId: 'your-formspree-form-id',
      endpoint: 'https://formspree.io/f/your-formspree-form-id'
    },

    // EmailJS configuration (replace with your actual values) - DEFAULT METHOD
    emailjs: {
      enabled: true, // Set to true - making EmailJS the default
        serviceId: 'service_h4qwbnk', // Replace with your EmailJS service ID
        templateId: 'template_n5ngjbn', // Replace with your EmailJS template ID
        publicKey: 'XodyXwyC5i6OjVQjH' // Replace with your EmailJS public key
    }
  };

  constructor() { }

  /**
   * Get email configuration
   * @returns EmailConfiguration
   */
  getConfig(): EmailConfiguration {
    return { ...this.config };
  }

  /**
   * Update Formspree configuration
   * @param formspreeConfig - Formspree configuration
   */
  setFormspreeConfig(formspreeConfig: EmailConfiguration['formspree']): void {
    if (formspreeConfig) {
      this.config.formspree = { ...formspreeConfig };
    }
  }

  /**
   * Update EmailJS configuration
   * @param emailjsConfig - EmailJS configuration
   */
  setEmailJSConfig(emailjsConfig: EmailConfiguration['emailjs']): void {
    if (emailjsConfig) {
      this.config.emailjs = { ...emailjsConfig };
    }
  }

  /**
   * Get primary email service method - EmailJS is now prioritized
   * @returns string - Primary method name
   */
  getPrimaryMethod(): 'emailjs' | 'formspree' {
    if (this.config.emailjs?.enabled) {
      return 'emailjs'; // EmailJS is now the priority
    } else if (this.config.formspree?.enabled) {
      return 'formspree';
    } else {
      return 'emailjs'; // Default to emailjs even if not configured
    }
  }

  /**
   * Check if any service is configured
   * @returns boolean
   */
  hasConfiguredService(): boolean {
    return !!(this.config.emailjs?.enabled || 
              this.config.formspree?.enabled);
  }

  /**
   * Get setup instructions
   * @returns Setup instructions object
   */
  getSetupInstructions() {
    return {
      emailjs: {
        title: 'EmailJS Setup (Default Method)',
        steps: [
          '1. Go to https://www.emailjs.com and create an account',
          '2. Create an email service (Gmail, Outlook, Yahoo, etc.)',
          '3. Create an email template with these variables:',
          '   - {{from_name}} - Sender name',
          '   - {{from_email}} - Sender email',
          '   - {{subject}} - Email subject',
          '   - {{message}} - Email message',
          '   - {{to_email}} - Recipient email',
          '4. Get your Service ID, Template ID, and Public Key',
          '5. Update the EmailJS configuration in this service',
          '6. Test the contact form'
        ],
        example: {
          serviceId: 'service_aacharya',
          templateId: 'template_contact',
          publicKey: 'your-public-key-here'
        }
      },
      formspree: {
        title: 'Formspree Setup (Alternative)',
        steps: [
          '1. Go to https://formspree.io and create an account',
          '2. Create a new form and get your form ID',
          '3. Update the formId in EmailConfigService',
          '4. Set formspree.enabled to true in the configuration'
        ]
      }
    };
  }
}