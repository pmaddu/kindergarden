import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EmailService, EmailData } from '../../services/email.service';
import { NotificationService } from '../../services/notification.service';
import { EmailConfigService } from '../../services/email-config.service';

// Validation interface for better type safety
interface ValidationErrors {
  name: string[];
  email: string[];
  subject: string[];
  message: string[];
}

// Validation rule interfaces
interface BaseValidationRule {
  required: boolean;
  maxLength?: number;
  minLength?: number;
  pattern?: RegExp;
  messages: {
    required: string;
    maxLength?: string;
    minLength?: string;
    pattern?: string;
  };
}

interface ValidationRules {
  name: BaseValidationRule;
  email: BaseValidationRule;
  subject: BaseValidationRule;
  message: BaseValidationRule;
}

@Component({
    selector: 'app-contact',
    templateUrl: './contact.component.html',
    styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
    isSubmitting = false;
    isValidEmail = true;
    
    // Form data with validation tracking
    formData = {
        name: '',
        email: '',
        subject: '',
        message: ''
    };

    // Validation state tracking
    validationErrors: ValidationErrors = {
        name: [],
        email: [],
        subject: [],
        message: []
    };

    // Validation rules with proper typing
    private validationRules: ValidationRules = {
        name: {
            required: true,
            minLength: 2,
            maxLength: 50,
            pattern: /^[a-zA-Z\s.''-]+$/,
            messages: {
                required: 'Name is required',
                minLength: 'Name must be at least 2 characters',
                maxLength: 'Name cannot exceed 50 characters',
                pattern: 'Please enter a valid name (letters and spaces only)'
            }
        },
        email: {
            required: true,
            maxLength: 100,
            pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
            messages: {
                required: 'Email is required',
                maxLength: 'Email cannot exceed 100 characters',
                pattern: 'Please enter a valid email address'
            }
        },
        subject: {
            required: true,
            minLength: 5,
            maxLength: 100,
            messages: {
                required: 'Subject is required',
                minLength: 'Subject must be at least 5 characters',
                maxLength: 'Subject cannot exceed 100 characters'
            }
        },
        message: {
            required: true,
            minLength: 10,
            maxLength: 1000,
            messages: {
                required: 'Message is required',
                minLength: 'Message must be at least 10 characters',
                maxLength: 'Message cannot exceed 1000 characters'
            }
        }
    };

    constructor(
        private emailService: EmailService,
        private notificationService: NotificationService,
        private configService: EmailConfigService
    ) {}

    ngOnInit(): void {
        const availableMethods = this.emailService.getAvailableMethods();
        const primaryMethod = this.emailService.getPrimaryMethod();
    }

    /**
     * Enhanced form submission with comprehensive validation
     */
    async onSubmit(form: NgForm) {
        // Mark all fields as touched to show validation errors
        this.markFormGroupTouched(form);

        // Perform custom validations
        const customValidationPassed = this.performCustomValidations();

        if (!form.valid || !customValidationPassed) {
            this.handleValidationErrors(form);
            return;
        }

        // Additional security validations
        if (!this.performSecurityValidations()) {
            return;
        }

        this.isSubmitting = true;

        try {
            const emailData: EmailData = this.emailService.sanitizeEmailData(this.formData);
            this.notificationService.showInfo('Sending your message via EmailJS...');

            await this.sendEmail(emailData);
        } catch (error) {
            this.notificationService.showError(
                'Sorry, there was an error sending your message. Please try again or contact us directly.'
            );
            this.isSubmitting = false;
        }
    }

    /**
     * Real-time field validation on input
     */
    onFieldInput(fieldName: keyof typeof this.formData): void {
        this.validateField(fieldName);
        this.updateEmailValidation();
    }

    /**
     * Field validation on blur
     */
    onFieldBlur(fieldName: keyof typeof this.formData): void {
        this.validateField(fieldName);
        this.updateEmailValidation();
        this.performFieldSpecificValidations(fieldName);
    }

    /**
     * Check if the entire form is valid
     */
    isFormValid(): boolean {
        return this.formData.name.trim() !== '' &&
               this.formData.email.trim() !== '' &&
               this.formData.subject.trim() !== '' &&
               this.formData.message.trim() !== '' &&
               this.isValidEmail &&
               this.performCustomValidations();
    }

    /**
     * Check if form is empty
     */
    isFormEmpty(): boolean {
        return !this.formData.name.trim() &&
               !this.formData.email.trim() &&
               !this.formData.subject.trim() &&
               !this.formData.message.trim();
    }

    /**
     * Get character count styling class
     */
    getCharacterCountClass(): string {
        const length = this.formData.message.length;
        if (length < 10) return 'text-warning';
        if (length > 900) return 'text-danger';
        if (length > 800) return 'text-warning';
        return 'text-muted';
    }

    /**
     * Validate individual field with proper type checking
     */
    private validateField(fieldName: keyof typeof this.formData): boolean {
        const value = this.formData[fieldName];
        const rules = this.validationRules[fieldName];
        const errors: string[] = [];

        // Required validation
        if (rules.required && (!value || value.trim() === '')) {
            errors.push(rules.messages.required);
        }

        if (value && value.trim()) {
            // MinLength validation
            if (rules.minLength && value.trim().length < rules.minLength) {
                errors.push(rules.messages.minLength!);
            }

            // MaxLength validation
            if (rules.maxLength && value.length > rules.maxLength) {
                errors.push(rules.messages.maxLength!);
            }

            // Pattern validation
            if (rules.pattern && !rules.pattern.test(value.trim())) {
                errors.push(rules.messages.pattern!);
            }
        }

        this.validationErrors[fieldName] = errors;
        return errors.length === 0;
    }

    /**
     * Update email validation state
     */
    private updateEmailValidation(): void {
        this.isValidEmail = this.emailService.validateEmail(this.formData.email);
    }

    /**
     * Perform all custom validations
     */
    private performCustomValidations(): boolean {
        let isValid = true;

        Object.keys(this.formData).forEach(key => {
            if (!this.validateField(key as keyof typeof this.formData)) {
                isValid = false;
            }
        });

        return isValid && this.isValidEmail;
    }

    /**
     * Perform security validations
     */
    private performSecurityValidations(): boolean {
        // Check for potential spam patterns
        const spamKeywords = ['viagra', 'casino', 'lottery', 'winner', 'congratulations', 'million dollar'];
        const messageText = this.formData.message.toLowerCase();
        
        if (spamKeywords.some(keyword => messageText.includes(keyword))) {
            this.notificationService.showWarning('Your message contains content that may be flagged as spam. Please revise and try again.');
            return false;
        }

        // Check for excessive special characters (potential spam)
        const specialCharMatches = this.formData.message.match(/[!@#$%^&*()+=\[\]{}|;':",./<>?~`]/g);
        const specialCharRatio = specialCharMatches ? specialCharMatches.length / this.formData.message.length : 0;
        
        if (specialCharRatio > 0.3) {
            this.notificationService.showWarning('Your message contains too many special characters. Please use normal text.');
            return false;
        }

        // Check for URL patterns (basic spam prevention)
        const urlPattern = /(https?:\/\/[^\s]+)/g;
        const urls = this.formData.message.match(urlPattern) || [];
        if (urls.length > 2) {
            this.notificationService.showWarning('Please limit the number of links in your message.');
            return false;
        }

        return true;
    }

    /**
     * Perform field-specific validations
     */
    private performFieldSpecificValidations(fieldName: keyof typeof this.formData): void {
        switch (fieldName) {
            case 'name':
                this.validateName();
                break;
            case 'email':
                this.validateEmailField();
                break;
            case 'subject':
                this.validateSubject();
                break;
            case 'message':
                this.validateMessage();
                break;
        }
    }

    /**
     * Enhanced name validation
     */
    private validateName(): void {
        const name = this.formData.name.trim();
        
        // Check for numbers in name
        if (name && /\d/.test(name)) {
            this.notificationService.showWarning('Names should not contain numbers.');
        }

        // Check for reasonable name length
        if (name && name.length > 30) {
            this.notificationService.showInfo('That\'s quite a long name! Please make sure it\'s correct.');
        }
    }

    /**
     * Enhanced email validation
     */
    private validateEmailField(): void {
        const email = this.formData.email.trim();
        
        if (email) {
            // Check for common typos in email domains
            const commonDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com'];
            const emailParts = email.split('@');
            if (emailParts.length === 2) {
                const emailDomain = emailParts[1];
                
                if (emailDomain && !commonDomains.includes(emailDomain.toLowerCase())) {
                }
            }

            // Validate email format
            this.isValidEmail = this.emailService.validateEmail(email);
        }
    }

    /**
     * Enhanced subject validation
     */
    private validateSubject(): void {
        const subject = this.formData.subject.trim();
        
        if (subject && subject.length >= 5) {
            // Check if subject is too generic
            const genericSubjects = ['hello', 'hi', 'inquiry', 'question'];
            if (genericSubjects.some(generic => subject.toLowerCase().includes(generic))) {
            }
        }
    }

    /**
     * Enhanced message validation
     */
    private validateMessage(): void {
        const message = this.formData.message.trim();
        
        if (message && message.length >= 10) {
            // Check message quality
            const words = message.split(' ').filter(word => word.length > 0);
            if (words.length < 3) {
                this.notificationService.showInfo('Consider providing more details in your message for a better response.');
            }
        }
    }

    /**
     * Handle validation errors
     */
    private handleValidationErrors(form: NgForm): void {
        const errorCount = Object.values(this.validationErrors).reduce((count, errors) => count + errors.length, 0);
        
        if (errorCount > 0) {
            this.notificationService.showError(`Please fix ${errorCount} validation error${errorCount > 1 ? 's' : ''} before submitting.`);
        } else if (!form.valid) {
            this.notificationService.showWarning('Please fill in all required fields correctly.');
        }

        // Focus on first invalid field
        this.focusOnFirstInvalidField();
    }

    /**
     * Focus on first invalid field for better UX
     */
    private focusOnFirstInvalidField(): void {
        setTimeout(() => {
            const firstInvalidField = document.querySelector('.form-control.is-invalid') as HTMLElement;
            if (firstInvalidField) {
                firstInvalidField.focus();
                firstInvalidField.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }, 100);
    }

    private async sendEmail(emailData: EmailData): Promise<void> {
        return new Promise((resolve, reject) => {
            this.emailService.sendEmailViaEmailJS(emailData).subscribe({
                next: (response) => {
                    if (response.success) {
                        this.handleSuccessfulSubmission();
                        resolve();
                    } else {
                        reject(new Error(response.message));
                    }
                },
                error: (error) => {
                    reject(error);
                }
            });
        });
    }

    private markFormGroupTouched(form: NgForm): void {
        Object.keys(form.controls).forEach(field => {
            const control = form.control.get(field);
            control?.markAsTouched({ onlySelf: true });
        });
    }

    private handleSuccessfulSubmission(): void {
        this.notificationService.showSuccess(
            `Thank you ${this.formData.name}! Your message has been sent successfully. We'll get back to you soon.`
        );

        this.resetForm();
        this.isSubmitting = false;
    }

    private resetForm(): void {
        this.formData = { name: '', email: '', subject: '', message: '' };
        this.validationErrors = { name: [], email: [], subject: [], message: [] };
        this.isValidEmail = true;
    }

    clearForm(form: NgForm): void {
        this.resetForm();
        form.resetForm();
        this.notificationService.showInfo('Form cleared.');
    }
}