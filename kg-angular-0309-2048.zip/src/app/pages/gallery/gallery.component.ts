﻿import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { GalleryService, GalleryItem } from '../../services/gallery.service';
import { NotificationService } from '../../services/notification.service';
import { Subject, Observable, combineLatest, timeout } from 'rxjs';
import { takeUntil, map, startWith } from 'rxjs/operators';

@Component({
    selector: 'app-gallery',
    templateUrl: './gallery.component.html',
    styleUrls: ['./gallery.component.scss']
})
export class GalleryComponent implements OnInit, OnDestroy {
    activeCategory = 'All';
    isModalOpen = false;

    // Upload modal states
    isUploadModalOpen = false;
    isUploading = false;
    uploadProgress = 0;
    uploadError: string | null = null; 

    // Upload form data
    selectedFiles: FileList | null = null;
    uploadCategory = 'Playing';

    // Edit modal states
    modalImageItem: GalleryItem | null = null;
    editFormData = {
        category: '',
        alt: '',
        description: ''
    };
    serverAvailable = false;
    // File input reference
    @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;

    private destroy$ = new Subject<void>();

    // 🎯 REACTIVE OBSERVABLES FOR ASYNC PIPES
    public galleryItems$: Observable<GalleryItem[]>;
    public categories$: Observable<string[]>;
    public loading$: Observable<boolean>;
    public error$: Observable<string | null>;
    public uploadProgress$: Observable<number>;
    
    // Computed observables
    public filteredItems$: Observable<GalleryItem[]>;
    public uploadCategories$: Observable<string[]>;
    public totalImages$: Observable<number>;
    public currentCategoryCount$: Observable<number>;

    constructor(
        private galleryService: GalleryService,
        private notificationService: NotificationService
    ) {
        // Initialize reactive streams
        this.galleryItems$ = this.galleryService.galleryItems$;
        this.categories$ = this.galleryService.categories$;
        this.loading$ = this.galleryService.loading$;
        this.error$ = this.galleryService.error$;
        this.uploadProgress$ = this.galleryService.uploadProgress$;

        // Computed observables using reactive operators
        this.totalImages$ = this.galleryItems$.pipe(
            map(items => items.length)
        );

        this.uploadCategories$ = this.categories$.pipe(
            map(categories => categories.filter(cat => cat !== 'All')),
            map(uploadCats => uploadCats.length === 0 ? 
                ['Playing', 'Drawing', 'Reading', 'Learning', 'Activities'] : 
                uploadCats
            )
        );

        this.filteredItems$ = combineLatest([
            this.galleryItems$,
            new Subject<string>().pipe(startWith('All'))
        ]).pipe(
            map(([items, activeCategory]) => 
                activeCategory === 'All' ? 
                items : 
                items.filter(item => item.category === activeCategory)
            )
        );

        this.currentCategoryCount$ = this.filteredItems$.pipe(
            map(items => items.length)
        );
    }

    ngOnInit(): void {
        this.checkServerStatus();
        this.initializeGallery();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    /**
     * Initialize gallery with dynamic loading
     */
    initializeGallery(): void {
        this.galleryService.loadImagesBasedOnServerStatus(this.serverAvailable)
            .pipe(takeUntil(this.destroy$))
            .subscribe({                
                error: (error) => {
                    // Error handling - let the service handle errors via error$ observable
                }
            });
    }

    /**
     * Check if server is available
     */
    checkServerStatus(): void {        
        this.galleryService.checkServerStatus()
            .pipe(takeUntil(this.destroy$))
            .subscribe({
                next: (available) => {
                    this.serverAvailable = available;
                },
                error: (error) => {
                    this.serverAvailable = false;
                }
            });
    }

    /**
     * Filter gallery by category - now reactive!
     */
    filterGallery(category: string): void {
        this.activeCategory = category;
        // The filteredItems$ observable will automatically update
        this.updateFilteredItems(category);
    }

    private updateFilteredItems(category: string): void {
        this.filteredItems$ = combineLatest([
            this.galleryItems$,
            new Subject<string>().pipe(startWith(category))
        ]).pipe(
            map(([items, activeCategory]) => 
                activeCategory === 'All' ? 
                items : 
                items.filter(item => item.category === activeCategory)
            )
        );

        this.currentCategoryCount$ = this.filteredItems$.pipe(
            map(items => items.length)
        );
    }

    /**
     * Open upload modal - now reactive!
     */
    openUploadModal(): void {
        if (!this.serverAvailable) {
            this.notificationService.showWarning('Upload server is not available. Please try again later.');
            return;
        }

        this.isUploadModalOpen = true;
        this.uploadError = null;
        this.selectedFiles = null;
        
        // 🎯 REACTIVE APPROACH: Let the async pipe handle category loading
        this.uploadCategories$.pipe(takeUntil(this.destroy$)).subscribe(categories => {
            if (categories.length > 0 && !categories.includes(this.uploadCategory)) {
                this.uploadCategory = categories[0];
            }
        });
        
        document.body.style.overflow = 'hidden';
    }

    /**
     * Open image modal
     */
    openModal(image: GalleryItem): void {
        this.modalImageItem = image;
        this.isModalOpen = true;
        document.body.style.overflow = 'hidden';
    }

    /**
     * Close image modal
     */
    closeModal(): void {
        this.isModalOpen = false;
        document.body.style.overflow = 'auto';
        this.modalImageItem = null;
    }

    /**
     * Close upload modal
     */
    closeUploadModal(): void {
        this.isUploadModalOpen = false;
        document.body.style.overflow = 'auto';
        this.selectedFiles = null;
        this.uploadError = null;
        this.galleryService.resetUploadProgress();

        if (this.fileInput) {
            this.fileInput.nativeElement.value = '';
        }
    }

    /**
     * Handle file selection
     */
    onFileSelected(event: any): void {
        const files = event.target.files as FileList;

        if (files && files.length > 0) {
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif'];
            const maxSize = 10 * 1024 * 1024; // 10MB

            for (let i = 0; i < files.length; i++) {
                const file = files[i];

                if (!allowedTypes.includes(file.type)) {
                    this.uploadError = `Invalid file type: ${file.name}. Allowed types: JPG, PNG, WebP, GIF`;
                    return;
                }

                if (file.size > maxSize) {
                    this.uploadError = `File too large: ${file.name}. Maximum size: 10MB`;
                    return;
                }
            }

            this.selectedFiles = files;
            this.uploadError = null;
        }
    }

    /**
     * Upload selected images
     */
    uploadImages(): void {
        if (!this.selectedFiles || this.selectedFiles.length === 0) {
            this.uploadError = 'Please select at least one image';
            return;
        }

        if (!this.uploadCategory || !this.uploadCategory.trim()) {
            this.uploadError = 'Please select a category';
            return;
        }

        this.isUploading = true;
        this.uploadError = null;

        

        

        this.galleryService.uploadImages(
            this.selectedFiles,
            this.uploadCategory
        ).pipe(takeUntil(this.destroy$))
            .subscribe({
                next: (response) => {
                    if (response && response.success) {
                        console.log('✅ Upload successful:', response);
                        console.log('📁 Uploaded files paths:', response.uploadedImages?.map(img => img.path));
                        this.closeUploadModal();
                        // 🔧 FIX 2: Don't call refreshGallery() - let service handle refresh
                        // this.refreshGallery(); // ❌ REMOVED - causes duplicate refresh
                        this.notificationService.showSuccess(
                            `Successfully uploaded ${response.uploadedImages.length} image(s) to ${response.category} category!`
                        );
                    }
                },
                error: (error) => {
                    console.error('❌ Upload failed:', error);
                    console.error('❌ Error details:', {
                        status: error.status,
                        message: error.message,
                        body: error.error
                    });
                    this.uploadError = error.error?.message || error.message || 'Upload failed. Please try again.';
                    this.notificationService.showError('Upload failed. Please check your files and try again.');
                    this.isUploading = false;
                },
                complete: () => {
                    this.isUploading = false;
                }
            });
    }


    /**
     * Delete image with confirmation
     */
    async deleteImage(item: GalleryItem, event: Event): Promise<void> {
        event.stopPropagation();

        if (!this.serverAvailable) {
            this.notificationService.showWarning('Delete server is not available. Please try again later.');
            return;
        }

        const confirmed = await this.notificationService.confirm(
            `Are you sure you want to delete "${item.alt}"? This action cannot be undone.`
        );

        if (confirmed) {
            this.galleryService.deleteImage(item.filename)
                .pipe(takeUntil(this.destroy$))
                .subscribe({
                    next: (response) => {
                        if (response.success) {
                            this.notificationService.showSuccess('Image deleted successfully!');
                            // Refresh gallery after deletion
                            this.closeModal();
                            this.refreshGallery();
                        }
                    },
                    error: (error) => {
                        this.notificationService.showError(error.error?.message || 'Delete failed. Please try again.');
                    }
                });
        }
    }

    /**
     * Refresh gallery
     */
    refreshGallery(): void {
        if (this.serverAvailable) {
            this.galleryService.refreshGalleryFromServer(true)
                .pipe(takeUntil(this.destroy$))
                .subscribe({
                    next: (response) => {
                        this.activeCategory = 'All';
                        this.notificationService.showSuccess('Gallery refreshed successfully!');
                    },
                    error: (error) => {
                        this.localRefresh();
                    }
                });
        } else {
            this.localRefresh();
        }
    }

    /**
     * Local refresh fallback
     */
    private localRefresh(): void {
        this.galleryService.refreshGallery()
            .pipe(takeUntil(this.destroy$))
            .subscribe({
                next: (items) => {
                    this.activeCategory = 'All';
                    this.notificationService.showInfo('Gallery refreshed from local files.');
                },
                error: (error) => {
                    this.notificationService.showError('Failed to refresh gallery. Please try again.');
                }
            });
    }

    // Utility methods for template
    onImageError(event: any, item: GalleryItem): void {
        const placeholderDataUrl = 'data:image/svg+xml;base64,' + btoa(`
      <svg width="400" height="300" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300">
        <rect width="400" height="300" fill="#f8f9fa"/>
        <rect x="160" y="120" width="80" height="60" rx="8" fill="#dee2e6"/>
        <circle cx="180" cy="140" r="8" fill="#6c757d"/>
        <path d="M170 155 L190 145 L210 160 L200 170 L180 165 Z" fill="#6c757d"/>
        <text x="200" y="200" text-anchor="middle" fill="#6c757d" font-family="Arial" font-size="14">
          Image not found
        </text>
        <text x="200" y="220" text-anchor="middle" fill="#adb5bd" font-family="Arial" font-size="12">
          ${item.filename}
        </text>
      </svg>
    `);

        event.target.src = placeholderDataUrl;
        event.target.classList.add('image-error');
        item.isLoaded = false;
    }

    onImageLoad(event: any, item: GalleryItem): void {
        item.isLoaded = true;
        event.target.classList.add('loaded');
    }

    trackByItem(index: number, item: GalleryItem): number {
        return item.id;
    }

    trackByCategory(index: number, category: string): string {
        return category;
    }

    /**
     * Get count of images for a specific category from items array
     */
    getCategoryCount(category: string, items: GalleryItem[] | null): number {
        if (!items) return 0;
        if (category === 'All') {
            return items.length;
        }
        return items.filter(item => item.category === category).length;
    }

    getCategoryIcon(category: string): string {
        const iconMap: { [key: string]: string } = {
            'All': 'fa-images',
            'Playing': 'fa-running',
            'Drawing': 'fa-palette',
            'Reading': 'fa-book-open',
            'Learning': 'fa-graduation-cap',
            'Activities': 'fa-calendar-alt'
        };
        return iconMap[category] || 'fa-image';
    }

    getCategoryDescription(category: string): string {
        const descriptions: { [key: string]: string } = {
            'All': 'All images from our gallery',
            'Playing': 'Children enjoying playtime and recreational activities',
            'Drawing': 'Creative art sessions and drawing activities',
            'Reading': 'Story time and reading sessions',
            'Learning': 'Educational activities and learning sessions',
            'Activities': 'Various school events and special activities'
        };
        return descriptions[category] || 'Images in this category';
    }

    formatFileSize(bytes: number): string {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    getSelectedFilesArray(): File[] {
        if (!this.selectedFiles) return [];

        const filesArray: File[] = [];
        for (let i = 0; i < this.selectedFiles.length; i++) {
            filesArray.push(this.selectedFiles[i]);
        }
        return filesArray;
    }

    getTotalFileSize(): string {
        if (!this.selectedFiles) return '0 Bytes';

        let totalSize = 0;
        for (let i = 0; i < this.selectedFiles.length; i++) {
            totalSize += this.selectedFiles[i].size;
        }

        return this.formatFileSize(totalSize);
    }
    deleteImageFromModal():void {

    }
    /**
     * Check if upload form is valid
     */
    isFormValid(): boolean {
        return !!(
            this.selectedFiles && 
            this.selectedFiles.length > 0 &&
            this.uploadCategory && 
            this.uploadCategory.trim().length > 0
        );
    }
}
