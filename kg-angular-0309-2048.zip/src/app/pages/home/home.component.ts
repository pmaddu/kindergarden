﻿import { Component, OnInit, OnDestroy } from '@angular/core';

export interface Slide {
  title: string;
  subtitle: string;
  description: string;
  image: string;
  background: string;
}

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy {

    currentSlide = 0;
    autoSlideInterval: any;
    isTransitioning = false;

    // Touch event properties
    private touchStartX: number = 0;
    private touchEndX: number = 0;

    slides: Slide[] = [
        {
            title: 'Kids Learning Center',
            subtitle: 'Little Hands, Big Dreams.',
            description: 'Celebrating the limitless potential in every child. Little Hands, Big Dreams inspires and nurtures young minds in a joyful kindergarten where creativity meets learning. Dedicated educators spark curiosity, ignite imagination, and build strong foundations for future success.',
            image: 'assets/img/header.png',
            background: 'linear-gradient(135deg, #D4A574 0%, #E67E22 100%)'
        },
        {
            title: 'Creative Learning Hub',
            subtitle: 'Imagination Meets Education.',
            description: 'Where young minds flourish through creative play and structured learning. Our innovative approach combines fun activities with educational excellence, ensuring every child develops confidence, curiosity, and a lifelong love for learning.',
            image: 'https://images.unsplash.com/photo-1544717297-fa95b6ee9643?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            background: 'linear-gradient(135deg, #8B4513 0%, #A0522D 100%)'
        },
        {
            title: 'Future Leaders Academy',
            subtitle: 'Growing Tomorrow\'s Leaders.',
            description: 'Empowering children to become confident, compassionate, and capable individuals. Through personalized attention and holistic development, we nurture each child\'s unique talents and prepare them for future academic and social success.',
            image: 'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
            background: 'linear-gradient(135deg, #7D8471 0%, #9CAF88 100%)'
        }
    ];

    // Fallback images in case primary images fail to load
    private fallbackImages = [
        'assets/img/header.png', // Slide 1 - always use local
        'https://via.placeholder.com/800x600/FF6B6B/FFFFFF?text=Creative+Learning', // Slide 2 fallback
        'https://via.placeholder.com/800x600/9CAF88/FFFFFF?text=Future+Leaders' // Slide 3 fallback
    ];

    constructor() { }

    ngOnInit(): void {
        this.startAutoSlide();
        this.preloadImages();
        
        // Debug: Log slide information
        console.log('🎯 Home Slider Initialized with', this.slides.length, 'slides:');
        this.slides.forEach((slide, index) => {
            console.log(`Slide ${index + 1}:`, {
                title: slide.title,
                subtitle: slide.subtitle,
                image: slide.image,
                background: slide.background
            });
        });
    }

    ngOnDestroy(): void {
        this.stopAutoSlide();
    }

    /**
     * TrackBy function for ngFor to improve performance and ensure proper rendering
     */
    trackBySlide(index: number, slide: Slide): string {
        return slide.title + index;
    }

    /**
     * Add visual feedback for rollover transitions
     */
    private addRolloverTransition(): void {
        const sliderTrack = document.querySelector('.slider-track');
        if (sliderTrack) {
            sliderTrack.classList.add('rollover-transition');
            setTimeout(() => {
                sliderTrack.classList.remove('rollover-transition');
            }, 600);
        }
    }

    /**
     * Get current slide data for debugging
     */
    getCurrentSlideData(): Slide {
        return this.slides[this.currentSlide];
    }

    /**
     * Get total number of slides
     */
    getTotalSlides(): number {
        return this.slides.length;
    }

    /**
     * Check if we're on the first slide
     */
    isFirstSlide(): boolean {
        return this.currentSlide === 0;
    }

    /**
     * Check if we're on the last slide
     */
    isLastSlide(): boolean {
        return this.currentSlide === this.slides.length - 1;
    }

    /**
     * Get current slide number (1-based for display purposes)
     */
    getCurrentSlideNumber(): number {
        return this.currentSlide + 1;
    }

    /**
     * Enhanced slide navigation with automatic rollover functionality and visual feedback
     */
    nextSlide(): void {
        if (this.isTransitioning) return;

        this.isTransitioning = true;
        const previousSlide = this.currentSlide;
        const wasLastSlide = this.isLastSlide();
        
        // Automatic rollover: go to first slide when reaching the end
        this.currentSlide = (this.currentSlide + 1) % this.slides.length;
        
        console.log(`🎬 Slide transition: ${previousSlide + 1} → ${this.currentSlide + 1} (${this.slides[this.currentSlide].title})`);
        
        // Add rollover indication and visual feedback
        if (wasLastSlide && this.currentSlide === 0) {
            console.log(`🔄 Automatic rollover: Reached end of slides, rolling back to first slide`);
            this.addRolloverTransition();
        }

        setTimeout(() => {
            this.isTransitioning = false;
        }, 800);
    }

    /**
     * Enhanced previous slide navigation with rollover functionality
     */
    prevSlide(): void {
        if (this.isTransitioning) return;

        this.isTransitioning = true;
        const previousSlide = this.currentSlide;
        
        // Rollover: go to last slide when at the beginning
        this.currentSlide = this.currentSlide === 0 ? this.slides.length - 1 : this.currentSlide - 1;
        
        console.log(`🎬 Slide transition: ${previousSlide + 1} → ${this.currentSlide + 1} (${this.slides[this.currentSlide].title})`);
        
        // Add rollover indication in console
        if (previousSlide === 0 && this.currentSlide === this.slides.length - 1) {
            console.log(`🔄 Reverse rollover: Reached beginning of slides, rolling to last slide`);
        }

        setTimeout(() => {
            this.isTransitioning = false;
        }, 800);
    }

    /**
     * Enhanced direct slide navigation with bounds checking
     */
    goToSlide(index: number): void {
        // Ensure the index is within valid bounds
        if (this.isTransitioning || index === this.currentSlide || index < 0 || index >= this.slides.length) return;

        this.isTransitioning = true;
        const previousSlide = this.currentSlide;
        this.currentSlide = index;
        
        console.log(`🎯 Direct slide navigation: ${previousSlide + 1} → ${this.currentSlide + 1} (${this.slides[this.currentSlide].title})`);

        setTimeout(() => {
            this.isTransitioning = false;
        }, 800);
    }

    /**
     * Enhanced auto-slide with rollover functionality
     */
    private startAutoSlide(): void {
        this.autoSlideInterval = setInterval(() => {
            console.log(`⏰ Auto-slide triggered: Currently on slide ${this.getCurrentSlideNumber()}/${this.getTotalSlides()}`);
            this.nextSlide(); // This will automatically rollover when reaching the end
        }, 6000); // Change slide every 6 seconds
    }

    private stopAutoSlide(): void {
        if (this.autoSlideInterval) {
            clearInterval(this.autoSlideInterval);
        }
    }

    /**
     * Preload images for better performance and handle errors
     */
    private preloadImages(): void {
        console.log('Preloading slider images...');

        this.slides.forEach((slide, index) => {
            if (slide.image.startsWith('http')) {
                const img = new Image();
                img.crossOrigin = 'anonymous';

                img.onload = () => {
                    console.log(`✅ Image ${index + 1} (${slide.title}) loaded successfully`);
                };

                img.onerror = () => {
                    console.warn(`❌ Failed to load image for slide ${index + 1} (${slide.title}). Using fallback.`);

                    // Try fallback image
                    if (index < this.fallbackImages.length) {
                        slide.image = this.fallbackImages[index];
                        console.log(`🔄 Using fallback image for slide ${index + 1}: ${slide.image}`);
                    } else {
                        slide.image = 'assets/img/header.png';
                        console.log(`🔄 Using default fallback for slide ${index + 1}`);
                    }
                };

                img.src = slide.image;
            } else {
                console.log(`📁 Slide ${index + 1} (${slide.title}) using local image: ${slide.image}`);
            }
        });
    }

    onMouseEnter(): void {
        this.stopAutoSlide();
    }

    onMouseLeave(): void {
        this.startAutoSlide();
    }

    // Touch event handlers for mobile swipe support
    onTouchStart(event: TouchEvent): void {
        this.touchStartX = event.changedTouches[0].screenX;
        this.stopAutoSlide();
    }

    onTouchEnd(event: TouchEvent): void {
        this.touchEndX = event.changedTouches[0].screenX;
        this.handleSwipe();
        this.startAutoSlide();
    }

    private handleSwipe(): void {
        const swipeThreshold = 50;
        const swipeDistance = this.touchStartX - this.touchEndX;

        if (Math.abs(swipeDistance) > swipeThreshold) {
            if (swipeDistance > 0) {
                // Swiped left - go to next slide
                this.nextSlide();
            } else {
                // Swiped right - go to previous slide
                this.prevSlide();
            }
        }
    }

    /**
     * Handle image loading errors gracefully with better fallbacks
     */
    onImageError(event: any, slideIndex: number): void {
        console.warn(`Image failed to load for slide ${slideIndex + 1}, trying fallback`);

        // Try fallback image first
        if (slideIndex < this.fallbackImages.length && event.target.src !== this.fallbackImages[slideIndex]) {
            event.target.src = this.fallbackImages[slideIndex];
            this.slides[slideIndex].image = this.fallbackImages[slideIndex];
        } else {
            // Use default header image as final fallback
            event.target.src = 'assets/img/header.png';
            this.slides[slideIndex].image = 'assets/img/header.png';
        }
    }

    /**
     * Handle successful image loading
     */
    onImageLoad(event: any, slideIndex: number): void {
        console.log(`Image loaded successfully for slide ${slideIndex + 1}`);
        event.target.classList.add('loaded');

        // Remove loading state
        const imageContainer = event.target.closest('.image');
        if (imageContainer) {
            imageContainer.classList.remove('loading');
        }
    }
}