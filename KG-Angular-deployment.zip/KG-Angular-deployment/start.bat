@echo off
echo Starting Aacharya Kindergarten Application...
cd server
echo Installing server dependencies...
npm install --production
echo Starting Express.js server...
start /B npm start
echo Starting file server for Angular...
cd ../dist/kindergarden
start /B npx http-server -p 4200 -c-1
echo Application started!
echo Angular: http://localhost:4200
echo API Server: http://localhost:3001
pause