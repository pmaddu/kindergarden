
        // <script
        //     src='https://oweb.zohowebstatic.com/sites/oweb/js/r/whatsapp-widget-generator.js'
        //     async
        //     onLoad="widget_whatsappButton({
        //         buttonName: 'Start Chat',
        //         brandImageUrl: '',
        //         brandName: 'Aacharya',
        //         brandStatusText: 'Typically replies within a day',
        //         buttonSize: 'large',
        //         buttonPosition: 'bottom-right',
        //         phoneNumber: '7411406696',
        //         welcomeMessage: 'Welcome to Aacharya!',
        //         prefillMessages: 'I am looking for:',
        //         replyOptions: 'Play School,Chess,Tuition,Abacus,Robotics'
        //     })"
        // >
        // </script>

        // <script async src='https://d2mpatx37cqexb.cloudfront.net/delightchat-whatsapp-widget/embeds/embed.min.js'></script>
        // <script async src='https://d2mpatx37cqexb.cloudfront.net/delightchat-whatsapp-widget/embeds/embed.min.js'></script>
        // <script>
        //   var wa_btnSetting = {"btnColor":"#16BE45","ctaText":"WhatsApp Us","cornerRadius":40,"marginBottom":20,"marginLeft":20,"marginRight":20,"btnPosition":"right","whatsAppNumber":"917411405424","welcomeMessage":"Hi There, Welcome to Aacharya!","zIndex":999999,"btnColorScheme":"light"};
        //   var wa_widgetSetting = {"title":"Aacharya","subTitle":"Typically replies in a day","headerBackgroundColor":"#FBFFC8","headerColorScheme":"dark","greetingText":"Hi there! \nHow can I help you?","ctaText":"Start Chat","btnColor":"#1A1A1A","cornerRadius":40,"welcomeMessage":"Hello","btnColorScheme":"light","brandImage":"https://uploads-ssl.webflow.com/5f68a65cd5188c058e27c898/6204c4267b92625c9770f687_whatsapp-chat-widget-dummy-logo.png","darkHeaderColorScheme":{"title":"#333333","subTitle":"#4F4F4F"}};  
        //   window.onload = () => {
        //     _waEmbed(wa_btnSetting, wa_widgetSetting);
        //   };
        // </script>

       const src='https://oweb.zohowebstatic.com/sites/oweb/js/r/whatsapp-widget-generator.js';
       onload => widget_whatsappButton({
                buttonName: 'Start Chat',
                brandImageUrl: '',
                brandName: 'Aacharya',
                brandStatusText: 'Typically replies within a day',
                buttonSize: 'large',
                buttonPosition: 'bottom-right',
                phoneNumber: '7411406696',
                welcomeMessage: 'Welcome to Aacharya!',
                prefillMessages: 'I am looking for:',
                replyOptions: 'Play School,Chess,Tuition,Abacus,Robotics'
            });