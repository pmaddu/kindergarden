# kindergarten-website-template

    Aacharya is a preschool website template designed to build websites for kindergarten,
    
    school of early learning, preschool, primary school, elementary school,
    
    junior high school, college, child care center, nursery, and many more.


# Features of kindergarten website template:

    [1] : Built with the latest Bootstrap framework
    
    [2] : Developer friendly and well-commented code
    
    [3] : Very clean and clear design
    
    [4] : Compatible with all major browsers
    
    [5] : Responsive and multi-column layout
    
    [6] : One-page and multi-page template
    
    [7] : Mobile friendly and dropdown navigation bar
    
    [8] : Full-width and responsive hero header
    
    [9] : Responsive testimonial carousel
