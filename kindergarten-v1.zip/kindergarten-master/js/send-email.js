
document.getElementById('sendMessageBtn').addEventListener('click', function(e) {
  e.preventDefault();
  emailjs.send("service_h4qwbnk", "template_n5ngjbn", {
    from_name: document.getElementById('name').value,
    from_email: document.getElementById('email').value,
    subject: document.getElementById('subject').value,
    message: document.getElementById('message').value
  })
  .then(function(response) {
    console.log('Message sent successfully!');
  }, function(error) {
    console.error('Failed to send message. Please try again.');
  });
});